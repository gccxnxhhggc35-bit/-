// الوضع المحلي (بدون خادم): يحاكي مسارات /api/* داخل المتصفح.
// الدخول والبيانات تُحفظ في localStorage لهذا المتصفح فقط. لا حاجة لـ Node ولا لأي اتصال.
import { APPS, cleanText, detectApp, digitsOnly, extractCode, parseNumbers, parseTime, tgNumber } from './parse.js';
import { SEED } from './seed.js';

/* ---------- تجزئة كلمة السر (SHA-256 متكرر مع ملح، JS صرف يعمل في أي سياق) ---------- */
const K = new Uint32Array([0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2]);
function sha256(msg) {
  const l = msg.length, n = ((l + 9 + 63) >> 6) << 6, b = new Uint8Array(n);
  b.set(msg); b[l] = 0x80;
  const dv = new DataView(b.buffer); dv.setUint32(n - 4, l * 8 >>> 0); dv.setUint32(n - 8, Math.floor(l / 0x20000000));
  let h0 = 0x6a09e667, h1 = 0xbb67ae85, h2 = 0x3c6ef372, h3 = 0xa54ff53a, h4 = 0x510e527f, h5 = 0x9b05688c, h6 = 0x1f83d9ab, h7 = 0x5be0cd19;
  const w = new Uint32Array(64);
  for (let o = 0; o < n; o += 64) {
    for (let i = 0; i < 16; i++) w[i] = dv.getUint32(o + i * 4);
    for (let i = 16; i < 64; i++) {
      const a = w[i - 15], c = w[i - 2];
      w[i] = (w[i - 16] + (((a >>> 7) | (a << 25)) ^ ((a >>> 18) | (a << 14)) ^ (a >>> 3)) + w[i - 7] + (((c >>> 17) | (c << 15)) ^ ((c >>> 19) | (c << 13)) ^ (c >>> 10))) >>> 0;
    }
    let a = h0, bb = h1, c = h2, d = h3, e = h4, f = h5, g = h6, h = h7;
    for (let i = 0; i < 64; i++) {
      const t1 = (h + (((e >>> 6) | (e << 26)) ^ ((e >>> 11) | (e << 21)) ^ ((e >>> 25) | (e << 7))) + ((e & f) ^ (~e & g)) + K[i] + w[i]) >>> 0;
      const t2 = ((((a >>> 2) | (a << 30)) ^ ((a >>> 13) | (a << 19)) ^ ((a >>> 22) | (a << 10))) + ((a & bb) ^ (a & c) ^ (bb & c))) >>> 0;
      h = g; g = f; f = e; e = (d + t1) >>> 0; d = c; c = bb; bb = a; a = (t1 + t2) >>> 0;
    }
    h0 = (h0 + a) >>> 0; h1 = (h1 + bb) >>> 0; h2 = (h2 + c) >>> 0; h3 = (h3 + d) >>> 0; h4 = (h4 + e) >>> 0; h5 = (h5 + f) >>> 0; h6 = (h6 + g) >>> 0; h7 = (h7 + h) >>> 0;
  }
  const out = new Uint8Array(32), ov = new DataView(out.buffer);
  [h0, h1, h2, h3, h4, h5, h6, h7].forEach((v, i) => ov.setUint32(i * 4, v));
  return out;
}
const utf8 = (s) => new TextEncoder().encode(s);
const hex = (u) => [...u].map((x) => x.toString(16).padStart(2, '0')).join('');
export function hashPw(password, salt) {
  const pw = utf8(password);
  let h = sha256(utf8(salt + ':' + password));
  for (let i = 0; i < 20000; i++) { const m = new Uint8Array(h.length + pw.length); m.set(h); m.set(pw, h.length); h = sha256(m); }
  return hex(h);
}
const randHex = (n) => { const a = new Uint8Array(n); (globalThis.crypto || window.crypto).getRandomValues(a); return hex(a); };
const newCred = (password) => { const salt = randHex(16); return { salt, hash: hashPw(password, salt) }; };
const sameHash = (a, b) => { if (a.length !== b.length) return false; let r = 0; for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i); return r === 0; };
const checkPw = (user, password) => !!(user.salt && user.hash && sameHash(hashPw(password, user.salt), user.hash));

/* ---------- تشفير الأكواد المرسلة لأجهزة المستخدمين (HMAC-SHA256 صرف، يعمل حتى بدون HTTPS) ---------- */
const unhex = (h) => new Uint8Array((String(h).match(/../g) || []).map((x) => parseInt(x, 16)));
const cat = (...a) => { const out = new Uint8Array(a.reduce((n, x) => n + x.length, 0)); let o = 0; for (const x of a) { out.set(x, o); o += x.length; } return out; };
function hmac(key, msg) {
  let k = key.length > 64 ? sha256(key) : key; const kb = new Uint8Array(64); kb.set(k);
  const ip = kb.map((x) => x ^ 0x36), op = kb.map((x) => x ^ 0x5c);
  return sha256(cat(op, sha256(cat(ip, msg))));
}
const b64 = (u) => { let s = ''; for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000)); return btoa(s); };
const unb64 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
export const pushKey = (password, ps) => hex(sha256(utf8('nfs-push|' + ps + '|' + password)));
export const pushRid = (pk) => hex(hmac(unhex(pk), utf8('rid'))).slice(0, 16);
export function seal(pk, text) {
  const key = unhex(pk), ke = hmac(key, utf8('enc')), km = hmac(key, utf8('mac'));
  const nonce = new Uint8Array(12); (globalThis.crypto || window.crypto).getRandomValues(nonce);
  const pt = utf8(text), ct = new Uint8Array(pt.length);
  for (let i = 0, ctr = 0; i < pt.length; i += 32, ctr++) { const ks = hmac(ke, cat(nonce, new Uint8Array([ctr >>> 24, ctr >>> 16 & 255, ctr >>> 8 & 255, ctr & 255]))); for (let j = 0; j < 32 && i + j < pt.length; j++) ct[i + j] = pt[i + j] ^ ks[j]; }
  return b64(cat(nonce, ct, hmac(km, cat(nonce, ct)).slice(0, 16)));
}
export function unseal(pk, box) {
  const key = unhex(pk), ke = hmac(key, utf8('enc')), km = hmac(key, utf8('mac')), raw = unb64(box);
  if (raw.length < 28) return null;
  const nonce = raw.slice(0, 12), ct = raw.slice(12, raw.length - 16), tag = raw.slice(raw.length - 16);
  if (!sameHash(hex(hmac(km, cat(nonce, ct)).slice(0, 16)), hex(tag))) return null;
  const pt = new Uint8Array(ct.length);
  for (let i = 0, ctr = 0; i < ct.length; i += 32, ctr++) { const ks = hmac(ke, cat(nonce, new Uint8Array([ctr >>> 24, ctr >>> 16 & 255, ctr >>> 8 & 255, ctr & 255]))); for (let j = 0; j < 32 && i + j < ct.length; j++) pt[i + j] = ct[i + j] ^ ks[j]; }
  return new TextDecoder().decode(pt);
}

/* ---------- التخزين ---------- */
/* نسخة المستخدمين: ملف HTML يصدّره المدير ويحمل حسابات المستخدمين وأرقامهم (بدون المدير ولا مفاتيح اللوحات).
   لها مساحة تخزين مستقلة حسب رقم النسخة، فلا تمسّ بيانات المدير إن فُتحت في نفس المتصفح. */
function readSnap() {
  try { const el = document.getElementById('nfs-snapshot'); const v = el && JSON.parse(el.textContent || 'null'); return v && v.id && v.db ? v : null; } catch { return null; }
}
const SNAP = typeof document !== 'undefined' ? readSnap() : null;
const SFX = SNAP ? '_' + SNAP.id : '';
const TEMPLATE = typeof document !== 'undefined' && document.getElementById('nfs-single') ? '<!DOCTYPE html>\n' + document.documentElement.outerHTML : null;
export const canExport = () => !!TEMPLATE && !SNAP;
const KEY = 'nfs_local_db_v1' + SFX, REV = 'nfs_local_rev' + SFX, SESS = 'nfs_local_session' + SFX, LEAD = 'nfs_bot_leader' + SFX, PKEY = 'nfs_push_key' + SFX, PSINCE = 'nfs_push_since' + SFX, FBSINCE = 'nfs_fb_since' + SFX;
const MAX_MESSAGES = 5000, SESSION_DAYS = 30, DEFAULT_PUSH = 'https://ntfy.sh';
let db = null, rev = '', memRev = 0, saveTimer = null, managerApplying = false;
const MANAGER_CHANNEL_KEY = 'nfs_manager_channel_v1';
const readManagerChannel = () => { try { const v = JSON.parse(ls.get(MANAGER_CHANNEL_KEY) || 'null'); return v && /^nfs-mgr-[a-f0-9]{24}$/.test(v.topic || '') && /^[a-f0-9]{64}$/.test(v.key || '') ? v : null; } catch { return null; } };
let managerChannel = null, managerEventSource = null, managerPollTimer = null, managerPublishTimer = null, managerLastPullAt = 0, managerLastAppliedId = '', managerLastPublishedId = '', managerPullPromise = null, managerChannelError = '';
function importManagerChannelFromHash() {
  try {
    if (typeof location === 'undefined' || !location.hash) return;
    const m = /(?:^|[&#])nfsmanager=([^&]+)/.exec(location.hash); if (!m) return;
    const parts = decodeURIComponent(m[1]).split('.');
    if (parts.length === 2 && /^nfs-mgr-[a-f0-9]{24}$/.test(parts[0]) && /^[a-f0-9]{64}$/.test(parts[1])) {
      ls.set(MANAGER_CHANNEL_KEY, JSON.stringify({ topic: parts[0], key: parts[1] })); managerChannel = { topic: parts[0], key: parts[1] };
      try { history.replaceState(null, '', location.pathname + location.search); } catch { /* لا يؤثر على الاستيراد */ }
    }
  } catch { /* رابط غير صالح */ }
}
// إن كان تخزين المتصفح ممنوعاً (معاينة داخل تطبيق، وضع خاص، منع ملفات الكوكيز...) نعمل من الذاكرة بدل الفشل الصامت.
const mem = new Map();
const ls = {
  get(k) { if (mem.has(k)) return mem.get(k); try { return localStorage.getItem(k); } catch { return null; } },
  set(k, v) { try { localStorage.setItem(k, v); mem.delete(k); return true; } catch { mem.set(k, v); return false; } },
  del(k) { mem.delete(k); try { localStorage.removeItem(k); } catch { /* تجاهل */ } },
};
importManagerChannelFromHash();
managerChannel ||= readManagerChannel();

/* ---------- المزامنة الدائمة بلا خادم (Firebase Realtime Database عبر REST) ----------
   السبب الذي كان يمنع وصول الحساب والأرقام والنطاقات والأكواد لمتصفح آخر: قناة ntfy.sh المجانية تحذف الرسائل بعد ~12 ساعة
   ولها حد يومي، فإذا أُغلق متصفح المدير لا يجد المستخدم شيئاً. هنا كل شيء يُخزَّن «كمستند دائم» مشفَّر بمفتاح صاحبه:
     nfs/acct/{قناة-الحساب}  سجل الحساب (مشفّر بكلمة سر صاحبه)      nfs/u/{rid}/state  أرقامه ونطاقاته وإعلاناته (مشفّرة)
     nfs/u/{rid}/log/{key}   أكواده وردود الدعم (مشفّرة)           nfs/inbox/{key}    رسائل المستخدمين للدعم (مشفّرة)
   لا خادم ولا حساب لديك: قاعدة مجانية تنشئها مرة واحدة (انظر README) وتضع رابطها في config.js أو من «حسابي ← المزامنة الدائمة». */
const cleanSync = () => ''; // v37: لا قاعدة بيانات إطلاقاً — المزامنة عبر القناة العامة فقط
function initSync() {
  try {
    const m = /[#&]nfssync=([^&]+)/.exec(location.hash || '');
    if (m) { const x = cleanSync(decodeURIComponent(m[1])); if (x) { localStorage.setItem('nfs_sync_url', x); try { history.replaceState(null, '', location.pathname + location.search); } catch { /* تجاهل */ } } }
  } catch { /* تجاهل */ }
  const W = typeof window !== 'undefined' ? window : {}, sbKey = String(W.NFS_SUPABASE_KEY || '').trim();
  let cfgRaw = String(W.NFS_SYNC || '').trim();
  if (!cfgRaw && W.NFS_SUPABASE_URL && sbKey) cfgRaw = String(W.NFS_SUPABASE_URL).trim().replace(/\/+$/, '') + '#' + sbKey;
  else if (/^https:\/\/[a-z0-9]+\.supabase\.co\/*$/i.test(cfgRaw) && sbKey) cfgRaw = cfgRaw.replace(/\/+$/, '') + '#' + sbKey;
  const cfg = cleanSync(cfgRaw);
  let saved = ''; try { saved = cleanSync(localStorage.getItem('nfs_sync_url')); } catch { /* تجاهل */ }
  return cfg || saved;
}
let syncBase = typeof window !== 'undefined' ? initSync() : '';
const setSyncBase = (v) => { syncBase = cleanSync(v); try { syncBase ? localStorage.setItem('nfs_sync_url', syncBase) : localStorage.removeItem('nfs_sync_url'); } catch { /* تجاهل */ } };
const isSb = () => /\.supabase\.co#/i.test(syncBase);
// Supabase (PostgREST): جدول واحد nfs_kv(k,v)؛ نحاكي فيه نفس عمليات Firebase (قراءة/كتابة متعددة/حذف/قوائم بالمفتاح)
async function sbReq(method, p, body, q = '') {
  const i = syncBase.indexOf('#'), base = syncBase.slice(0, i), key = syncBase.slice(i + 1), ep = base + '/rest/v1/nfs_kv', enc = encodeURIComponent;
  const call = async (url, init = {}) => {
    const ctl = new AbortController(), timer = setTimeout(() => ctl.abort(), 15000);
    try {
      const r = await fetch(url, { ...init, headers: { apikey: key, ...(/^eyJ/.test(key) ? { Authorization: 'Bearer ' + key } : {}), ...(init.headers || {}) }, signal: ctl.signal });
      if (!r.ok) throw Object.assign(new Error('HTTP ' + r.status), { status: r.status });
      const t = await r.text(); return t ? JSON.parse(t) : null;
    } finally { clearTimeout(timer); }
  };
  const del = async (keys) => { for (let k = 0; k < keys.length; k += 40) await call(ep + '?k=in.(' + keys.slice(k, k + 40).map((x) => enc('"' + x + '"')).join(',') + ')', { method: 'DELETE' }); };
  if (method === 'PUT' || method === 'PATCH') {
    const ents = method === 'PUT' ? [[p, body]] : Object.entries(body || {}).map(([k, v]) => [p ? p + '/' + k : k, v]);
    const up = ents.filter(([, v]) => v !== null).map(([k, v]) => ({ k, v: JSON.stringify(v) }));
    if (up.length) await call(ep, { method: 'POST', headers: { 'Content-Type': 'application/json', Prefer: 'resolution=merge-duplicates,return=minimal' }, body: JSON.stringify(up) });
    await del(ents.filter(([, v]) => v === null).map(([k]) => k));
    return body;
  }
  if (method === 'DELETE') { await call(ep + '?or=' + enc(`(k.eq."${p}",and(k.gte."${p}/",k.lt."${p}0"))`), { method: 'DELETE' }); return null; }
  const sm = /startAt=%22([^&]*)%22/.exec(q), lm = /limitToFirst=(\d+)/.exec(q), since = sm ? decodeURIComponent(sm[1]) : '', limit = lm ? Number(lm[1]) : 0;
  if (!since && !limit) { const r = await call(ep + '?select=v&k=eq.' + enc(p)); if (r && r.length) return JSON.parse(r[0].v); }
  const rows = await call(ep + `?select=k,v&k=gte.${enc(p + '/' + since)}&k=lt.${enc(p + '0')}&order=k.asc${limit ? '&limit=' + limit : ''}`);
  if (!rows || !rows.length) return null;
  const out = {};
  for (const row of rows) { const parts = row.k.slice(p.length + 1).split('/'); let n = out; for (let x = 0; x < parts.length - 1; x++) n = n[parts[x]] ||= {}; n[parts.at(-1)] = JSON.parse(row.v); }
  return out;
}
const fbU = (p, q = '') => `${syncBase}/nfs${p ? '/' + p : ''}.json${q}`;
async function fbReq(method, p, body, q = '') {
  if (isSb()) return sbReq(method, p, body, q);
  const ctl = new AbortController(), timer = setTimeout(() => ctl.abort(), 15000);
  try {
    const r = await fetch(fbU(p, q), { method, body: body === undefined ? undefined : JSON.stringify(body), signal: ctl.signal });
    if (!r.ok) throw Object.assign(new Error('HTTP ' + r.status), { status: r.status });
    return await r.json().catch(() => null);
  } finally { clearTimeout(timer); }
}
const fbErr = (e) => !e ? '' : e.status === 401 || e.status === 403 ? 'قاعدة المزامنة تمنع الوصول: تحقق من القواعد/سياسة الجدول في README ومن صحة المفتاح'
  : e.status === 404 ? 'رابط قاعدة المزامنة غير صحيح أو لم يُنشأ جدول nfs_kv بعد (نفّذ كود SQL من README)' : e.status === 402 || e.status === 429 ? 'قاعدة المزامنة تجاوزت حدها المجاني' : e.name === 'AbortError' ? 'قاعدة المزامنة لا ترد (تحقق من الإنترنت)' : 'تعذر الاتصال بقاعدة المزامنة (تحقق من الإنترنت ومن الرابط)';
const fbKey = () => Date.now().toString(36).padStart(9, '0') + randHex(3);
const fbOrderKey = '?orderBy=%22%24key%22';

function freshDb() {
  if (SNAP) return JSON.parse(JSON.stringify(SNAP.db));
  return {
    core: {
      users: [{ id: 1, username: SEED.admin.username, name: SEED.admin.name, role: 'admin', disabled: false, createdAt: Date.now(), salt: SEED.admin.salt, hash: SEED.admin.hash }],
      domains: [], requests: [], announcements: [],
      panels: SEED.panels.map((p) => ({ enabled: true, path: '', authHeader: 'Authorization', authScheme: 'Bearer', type: 'generic', key: '', ...p })),
      settings: { activePanel: SEED.activePanel || null, botOn: true, pollSeconds: 5, pricePerCode: 0, pushOn: true, pushServer: DEFAULT_PUSH, pushTopic: '' },
      seq: { user: 1, domain: 0, request: 0, panel: 0, announcement: 0 },
    },
    numData: { seq: 0, items: [] }, msgData: { items: [] },
  };
}
function load() {
  const stamp = ls.get(REV) || '';
  if (db && (stamp === rev || (!stamp && !ls.get(KEY)))) return db;
  let d = null;
  try { d = JSON.parse(ls.get(KEY) || 'null'); } catch { d = null; }
  db = d && d.core && d.numData && d.msgData ? d : freshDb();
  db.core.seq.announcement ||= 0; db.core.announcements ||= [];
  if (!SNAP) {
    // المدير رقم 2: 1Whisper / 1Whisper (إدارة مستخدمين ونطاقات وأرقام وطلبات ومشاهدة الترافيك فقط)
    const m = db.core.users.find((u) => u.username === MANAGER_USERNAME);
    if (!m) db.core.users.push({ id: ++db.core.seq.user, username: MANAGER_USERNAME, name: '1Whisper', role: 'limited_admin', disabled: false, createdAt: Date.now(), ...newCred('1Whisper') });
    else if (m.role === 'user') Object.assign(m, { role: 'limited_admin', name: '1Whisper', disabled: false, ...newCred('1Whisper') }, { acct: undefined });
    if (!m || m.role === 'limited_admin') touch();
  }
  const st = db.core.settings;
  if (st.pushOn == null) st.pushOn = true;
  if (!st.pushServer) st.pushServer = DEFAULT_PUSH;
  if (!SNAP && st.syncUrl && !syncBase) setSyncBase(st.syncUrl);
  if (!SNAP && !st.pushTopic) { st.pushTopic = 'nfs-' + randHex(12); touch(); }
  rev = stamp; ingest.seen = null; reindex();
  return db;
}
function persist() {
  clearTimeout(saveTimer); saveTimer = null;
  rev = String(Date.now()) + '.' + (++memRev);
  const ok = ls.set(KEY, JSON.stringify(db)) && ls.set(REV, rev);
  if (!ok && !persist.warned) { persist.warned = true; console.warn('NFSsms: تعذر الحفظ في المتصفح (التخزين ممتلئ أو ممنوع)'); }
  if (!managerApplying) scheduleManagerPublish();
}
// إشعار الواجهة فوراً بوصول جديد (في نفس التبويب وفي التبويبات الأخرى)
const notifyNew = () => { try { dispatchEvent(new Event('nfs:new')); } catch { /* تجاهل */ } };
if (typeof window !== 'undefined') addEventListener('storage', (e) => { if (e.key === REV) notifyNew(); });
const touch = () => { if (!saveTimer) saveTimer = setTimeout(persist, 300); };
addEventListener('pagehide', () => { if (saveTimer) persist(); });

let byDigits = new Map(), byLast9 = new Map();
function reindex() {
  byDigits = new Map(); byLast9 = new Map();
  for (const r of db.numData.items) {
    byDigits.set(r.n, r);
    const k = r.n.slice(-9), arr = byLast9.get(k);
    if (arr) arr.push(r); else byLast9.set(k, [r]);
  }
}
function lookupNumber(raw) {
  const d = digitsOnly(raw); if (!d) return null;
  const exact = byDigits.get(d); if (exact) return exact;
  if (d.length >= 9) { const arr = byLast9.get(d.slice(-9)); if (arr && arr.length === 1) return arr[0]; }
  return null;
}

/* ---------- أدوات ---------- */
class HttpError extends Error { constructor(status, message) { super(message); this.status = status; } }
const bad = (m) => new HttpError(400, m);
const publicUser = (u) => ({ id: u.id, username: u.username, name: u.name, role: u.role });
const clampInt = (v, min, max, d) => { if (v == null || v === '') return d; const n = Math.trunc(Number(v)); return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : d; };
const str = (v, max = 200) => String(v ?? '').trim().slice(0, max);
const dayKey = (t, tz) => Math.floor((t - tz * 60000) / 864e5);
const core = () => db.core;
const numbers = () => db.numData.items;
const messages = () => db.msgData.items;
const domainOf = (id) => core().domains.find((d) => d.id === Number(id));
const userOf = (id) => core().users.find((u) => u.id === id);
// المدير الكامل (admin) والمدير رقم 2 المحدود (limited_admin: 1Whisper)
const isPriv = (u) => !!u && (u.role === 'admin' || u.role === 'limited_admin');
const MANAGER_USERNAME = '1whisper';
const SUPPORT_MSG = 'حدث خطأ، تواصل مع الدعم عبر تيليجرام @NFSsms';
const canSeeDomain = (user, d) => isPriv(user) || d.access === '*' || (Array.isArray(d.access) && d.access.includes(user.id)) || numbers().some((r) => r.d === d.id && r.u === user.id);

function domainCounts() {
  const m = new Map();
  for (const r of numbers()) { const c = m.get(r.d) || { total: 0, free: 0, assigned: 0 }; c.total++; r.u ? c.assigned++ : c.free++; m.set(r.d, c); }
  return m;
}
function assignNumbers(domainId, userId, app, count) {
  let picked = 0; const now = Date.now();
  for (const r of numbers()) { if (picked >= count) break; if (r.d === domainId && !r.u) { r.u = userId; r.a = app; r.t = now; picked++; } }
  if (picked) touch();
  return picked;
}
// الكود يتبع صاحب الرقم الحالي: كل رسائل الرقم منذ آخر إلغاء توزيع له (أو منذ البداية إن لم يُلغَ قط)
function messageOwner(m) {
  const r = lookupNumber(m.n);
  if (m.o) return r && r.u === m.o ? r : { id: 'p' + m.n, u: m.o, n: m.n, a: m.a, d: 0, t: m.t, pushed: true };
  return r && r.u && m.t >= (r.rel || 0) - 60000 ? r : null;
}
const releaseRec = (r) => { r.u = null; r.a = null; r.t = 0; r.rel = Date.now(); };
function ownedMessages(userId) {
  const out = [], list = messages();
  for (let i = list.length - 1; i >= 0; i--) { const m = list[i], r = messageOwner(m); if (userId == null || (r && r.u === userId)) out.push({ m, r }); }
  return out;
}

/* ---------- جلب الرسائل من اللوحات (من المتصفح مباشرة) ---------- */
const PICK = {
  number: ['number', 'phone', 'phone_number', 'phoneNumber', 'msisdn', 'to', 'dest', 'destination', 'recipient', 'num', 'did'],
  content: ['content', 'text', 'message', 'body', 'sms', 'msg', 'full_message', 'otp_message'],
  sender: ['cllr', 'cli', 'sender', 'from', 'service', 'app', 'source', 'originator', 'caller'],
  time: ['time', 'date', 'created_at', 'createdAt', 'timestamp', 'received_at', 'receivedAt', 'datetime'],
  id: ['id', 'uuid', 'message_id', 'messageId', '_id', 'sms_id'],
};
const pick = (o, keys) => { for (const k of keys) if (o[k] != null && o[k] !== '') return o[k]; return undefined; };
function findList(json) {
  if (Array.isArray(json)) return json;
  if (json && typeof json === 'object') for (const k of ['data', 'messages', 'items', 'results', 'result', 'records', 'rows', 'sms', 'cdr', 'list']) {
    const v = json[k];
    if (Array.isArray(v)) return v;
    if (v && typeof v === 'object') { const inner = findList(v); if (inner) return inner; }
  }
  return null;
}
function normalizeItem(o) {
  if (!o || typeof o !== 'object') return null;
  const number = pick(o, PICK.number), content = pick(o, PICK.content);
  if (number == null || content == null) return null;
  const time = parseTime(pick(o, PICK.time));
  let pid = pick(o, PICK.id);
  if (pid == null) pid = hex(sha256(utf8(`${number}|${time}|${content}`))).slice(0, 20);
  const pay = Number(o.agentPayout ?? o.payout ?? o.price ?? o.cost ?? o.rate ?? 0);
  return { pid: String(pid), number: String(number), sender: String(pick(o, PICK.sender) ?? ''), content: String(content), time, pay: Number.isFinite(pay) ? pay : 0 };
}
function buildRequest(panel, o = {}) {
  const base = String(panel.url || '').replace(/\/+$/, ''), path = o.path ?? panel.path ?? '';
  const headerName = o.authHeader ?? panel.authHeader ?? 'Authorization', scheme = o.authScheme ?? panel.authScheme ?? '';
  const headers = { Accept: 'application/json' };
  if (panel.key) headers[headerName] = scheme ? `${scheme} ${panel.key}` : panel.key;
  return { url: base + (path.startsWith('/') || !path ? path : '/' + path), headers };
}
async function getJson(url, headers, timeoutMs) {
  const t0 = Date.now(), ctl = new AbortController(), timer = setTimeout(() => ctl.abort(), timeoutMs + 3000);
  const st = db.core.settings, relay = String(st.relayUrl || '').trim();
  try {
    let status, text;
    if (relay) {
      const res = await fetch(relay, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ url, headers, token: st.relayToken || '' }), signal: ctl.signal });
      const j = await res.json().catch(() => ({}));
      if (!res.ok) return { ok: false, ms: Date.now() - t0, error: j.error || `الوسيط رد HTTP ${res.status}` };
      if (!j.status) return { ok: false, ms: Date.now() - t0, error: j.error || 'تعذر وصول الوسيط للّوحة' };
      status = j.status; text = j.body;
    } else if (st.publicProxy) {
      // وسيط عام تابع لطرف ثالث (اختيار صريح من المدير): الطلب ومفتاح اللوحة يمرّان عبره
      const res = await fetch('https://corsproxy.io/?url=' + encodeURIComponent(url), { headers, signal: ctl.signal });
      status = res.status; text = await res.text();
    } else {
      const res = await fetch(url, { headers, signal: ctl.signal });
      status = res.status; text = await res.text();
    }
    const ms = Date.now() - t0;
    if (status !== 200) return { ok: false, ms, error: `HTTP ${status}` };
    try { return { ok: true, ms, json: JSON.parse(text) }; } catch { return { ok: false, ms, error: 'الرد ليس JSON' }; }
  } catch {
    return { ok: false, ms: Date.now() - t0, error: relay ? 'تعذر الاتصال بالوسيط، تحقق من رابطه' : (location.protocol === 'https:' && /^http:/i.test(url) ? 'الموقع HTTPS واللوحة HTTP فيمنعها المتصفح. افتح index.html من جهازك مباشرة، أو أضف وسيط الاتصال من "حسابي"' : 'المتصفح منع الاتصال باللوحة (CORS). افتح NFSsms عبر ملف التشغيل (NFSsms-Start-Windows.bat أو نسخة ماك/لينكس) الموجود بجانب الملف') };
  } finally { clearTimeout(timer); }
}
async function fetchMessages(panel, override = {}, timeoutMs = 12000) {
  if (!panel.url) throw new Error('رابط اللوحة غير محدد');
  if (!(override.path ?? panel.path)) throw new Error('مسار جلب الرسائل غير محدد (استخدم "اكتشاف المسار" أو أدخله يدوياً)');
  const { url, headers } = buildRequest(panel, override), r = await getJson(url, headers, timeoutMs);
  if (!r.ok) throw Object.assign(new Error(r.error), { ms: r.ms });
  const list = findList(r.json);
  if (!list) throw Object.assign(new Error('شكل الرد غير معروف (لا توجد قائمة رسائل)'), { ms: r.ms });
  return { items: list.map(normalizeItem).filter(Boolean), ms: r.ms };
}
// فحص كامل: يجلب كل الصفحات المتاحة من اللوحة (page=2,3...) حتى تنتهي أو تتكرر
async function fetchAll(panel) {
  const first = await fetchMessages(panel), all = [...first.items], ids = new Set(all.map((x) => x.pid));
  const base = panel.path || '';
  for (let page = 2; page <= 40 && all.length; page++) {
    let r; try { r = await fetchMessages(panel, { path: base + (base.includes('?') ? '&' : '?') + 'page=' + page }, 12000); } catch { break; }
    const fresh = r.items.filter((x) => !ids.has(x.pid));
    if (!fresh.length) break;
    fresh.forEach((x) => { ids.add(x.pid); all.push(x); });
  }
  return { items: all, ms: first.ms };
}
const CANDIDATE_PATHS = ['/api/messages/cdr', '/api/v1/sms', '/api/v1/messages', '/api/sms', '/api/messages', '/api/v1/inbox', '/api/inbox', '/api/cdr', '/api/v1/cdr', '/api/otp', '/api/v1/otp', '/api/getsms', '/api/sms/inbox', '/api/agent/messages', '/api/v1/sms/inbox', '/api/v1/received', '/api/received'];
const CANDIDATE_AUTH = [{ authHeader: 'Authorization', authScheme: 'Bearer' }, { authHeader: 'X-API-Key', authScheme: '' }, { authHeader: 'X-API-Token', authScheme: '' }, { authHeader: 'Authorization', authScheme: '' }, { authHeader: 'api-key', authScheme: '' }];
async function detectEndpoint(panel) {
  const combos = []; for (const path of CANDIDATE_PATHS) for (const a of CANDIDATE_AUTH) combos.push({ path, ...a });
  let found = null, idx = 0;
  const worker = async () => {
    while (!found && idx < combos.length) {
      const c = combos[idx++];
      try { const { url, headers } = buildRequest(panel, c), r = await getJson(url, headers, 6000); if (r.ok && findList(r.json)) { found = c; return; } } catch { /* تجاهل */ }
    }
  };
  await Promise.all(Array.from({ length: 6 }, worker));
  return found;
}
const maskKey = (k) => (!k ? '' : k.length <= 8 ? '••••' : `${k.slice(0, 4)}••••••${k.slice(-4)}`);

function ingest(panel, items) {
  const seen = ingest.seen ||= new Set(messages().map((m) => m.k));
  let added = 0;
  for (const it of items) {
    const k = `${panel.id}:${it.pid}`; if (seen.has(k)) continue; seen.add(k);
    const content = cleanText(it.content).slice(0, 600);
    messages().push({ k, p: panel.id, n: digitsOnly(it.number), s: cleanText(it.sender).slice(0, 60), x: content, c: extractCode(content), a: detectApp(it.sender, content), t: it.time, r: Date.now(), pay: it.pay || 0, ...(panel.pn ? { pn: panel.pn } : {}) });
    added++;
  }
  if (added) {
    messages().sort((a, b) => a.t - b.t);
    if (messages().length > MAX_MESSAGES) messages().splice(0, messages().length - MAX_MESSAGES);
    persist(); notifyNew();
  }
  return added;
}

/* ---------- إيصال الأكواد فوراً لأجهزة المستخدمين ----------
   جهاز المدير يجلب من اللوحة، ثم يرسل كل كود مشفّراً بمفتاح صاحبه إلى خدمة إشعارات عامة (ntfy.sh افتراضياً).
   نسخة المستخدم (على أي جهاز أو هاتف) تستمع لنفس القناة وتفك فقط الأكواد الخاصة بصاحبها. مفاتيح اللوحات لا تغادر جهاز المدير. */
const push = { ok: null, at: 0, sent: 0, error: '', backoff: 0, listening: false, connected: false, got: 0, lastAt: 0 };
const pushUrl = () => String(core().settings.pushServer || DEFAULT_PUSH).replace(/\/+$/, '') + '/' + encodeURIComponent(core().settings.pushTopic || '');
function userPushKey(u) { if (!u.pk) { u.pk = randHex(32); u.pkx = true; touch(); } return u.pk; }
const codeDto = (m, r) => {
  const price = Number(core().settings.pricePerCode) || 0;
  return { id: m.k, n: m.n, a: m.a, c: m.c, x: m.x, s: m.s, t: m.t, u: r ? userOf(r.u)?.username || null : null, un: r ? userOf(r.u)?.name || null : null, p: m.pn || core().panels.find((p) => p.id === m.p)?.name || '', earn: r && m.c ? price : 0, pay: m.pay || 0 };
};
let pushing = false;
// عند تفعيل قاعدة المزامنة (أو تغييرها) نعيد نشر الحسابات والحالات وآخر أكواد 3 أيام ليجدها كل متصفح جديد
function fbSeed() {
  const st = core().settings; if (!syncBase || st.fbDone === syncBase) return;
  st.fbDone = syncBase; const from = Date.now() - 3 * 864e5, list = messages();
  for (let k = list.length - 1, n = 0; k >= 0 && n < 250; k--) if (list[k].pu && list[k].t > from) { list[k].pu = 0; n++; }
  for (const u of core().users) { u.stH = ''; u.acctAt = 0; u.acctB = ''; u.logN = 0; }
  touch();
}
async function fbPrune(rid, u) {
  if ((u.logN || 0) < 400) return;
  try {
    const old = await fbReq('GET', `u/${rid}/log`, undefined, fbOrderKey + '&limitToFirst=' + (u.logN - 250)), del = {};
    for (const k of Object.keys(old || {})) del[`u/${rid}/log/${k}`] = null;
    if (Object.keys(del).length) await fbReq('PATCH', '', del);
    u.logN = 250; touch();
  } catch { /* تُعاد لاحقاً */ }
}
async function pushPending(force = false) {
  const st = core().settings;
  if (SNAP || !st.pushOn || !st.pushTopic || pushing) return;
  if (!force && push.backoff > Date.now()) return;
  fbSeed();
  const pend = [], list = messages();
  // الأحدث أولاً حتى يصل الكود الجديد فوراً حتى لو كانت هناك أكواد قديمة بانتظار الإرسال
  for (let k = list.length - 1; k >= 0 && pend.length < 120; k--) {
    const m = list[k]; if (m.pu) continue;
    const r = messageOwner(m); if (!r) continue;
    const u = userOf(r.u); if (!u || u.disabled) continue;
    const item = codeDto(m, r); delete item.u; delete item.un; delete item.pay;
    pend.push({ m, box: { r: pushRid(userPushKey(u)), b: seal(u.pk, JSON.stringify(item)) } });
  }
  if (!pend.length) return;
  pushing = true;
  if (syncBase) {
    try {
      const map = {}, ts = Date.now(), users = new Map();
      for (const x of pend) { map[`u/${x.box.r}/log/${fbKey()}`] = x.box.b; map[`u/${x.box.r}/v/l`] = ts; const u = userOf(messageOwner(x.m).u); if (u) { u.logN = (u.logN || 0) + 1; users.set(x.box.r, u); } }
      await fbReq('PATCH', '', map);
      pend.forEach((x) => { x.m.pu = 1; }); push.sent += pend.length; push.ok = true; push.error = ''; push.at = Date.now(); persist();
      for (const [rid, u] of users) await fbPrune(rid, u);
    } catch (e) { push.ok = false; push.error = fbErr(e); push.backoff = Date.now() + 15000; }
    finally { pushing = false; }
    return;
  }
  try {
    let i = 0, posts = 0;
    while (i < pend.length && posts < 6) {
      const chunk = []; let size = 20;
      while (i < pend.length && size + pend[i].box.b.length + 40 < 3600) { chunk.push(pend[i]); size += pend[i].box.b.length + 40; i++; }
      if (!chunk.length) { pend[i].m.pu = 1; i++; continue; }
      const res = await fetch(pushUrl(), { method: 'POST', body: JSON.stringify({ v: 1, i: chunk.map((x) => x.box) }) });
      posts++;
      if (!res.ok) { push.ok = false; push.error = res.status === 429 ? 'تجاوزت حد خدمة الإشعارات مؤقتاً، ستُعاد المحاولة' : `خدمة الإشعارات ردت HTTP ${res.status}`; push.backoff = Date.now() + (res.status === 429 ? 60000 : 15000); break; }
      chunk.forEach((x) => { x.m.pu = 1; }); push.sent += chunk.length; push.ok = true; push.error = ''; push.at = Date.now();
    }
    persist();
  } catch { push.ok = false; push.error = 'تعذر الوصول لخدمة الإشعارات (تحقق من الإنترنت)'; push.backoff = Date.now() + 15000; }
  finally { pushing = false; }
}

/* ---------- مزامنة توزيع الأرقام والنطاقات لمتصفح كل مستخدم (بدون خادم) ----------
   الكود وحده كان يصل لنسخة المستخدم، أما الأرقام الموزَّعة والنطاقات فكانت تبقى في متصفح المدير. الآن يرسل متصفح المدير حالة كل مستخدم
   مشفّرة بمفتاحه عبر نفس قناة الإشعارات، فتظهر أرقامه ونطاقاته في أي متصفح يدخل منه، وتتحدّث فوراً عند أي توزيع أو إرجاع. */
const STATE_REPUBLISH_MS = 5 * 3600e3;
function userState(u) {
  return { nums: numbers().filter((r) => r.u === u.id).map((r) => [r.id, r.n, r.d, r.a, r.t]),
    doms: core().domains.filter((d) => canSeeDomain(u, d)).map((d) => ({ id: d.id, name: d.name, apps: d.apps, createdAt: d.createdAt })),
    ann: (core().announcements || []).slice(-6).map((a) => ({ id: a.id, title: String(a.title || '').slice(0, 160), body: String(a.body || '').slice(0, 700), by: a.by, t: a.t })) };
}
function stateParts(s) {
  const parts = []; let cur = { doms: [], nums: [], ann: [] }, len = 0;
  const flush = () => { parts.push(cur); cur = { doms: [], nums: [], ann: [] }; len = 0; };
  for (const a of s.ann || []) { cur.ann.push(a); len += JSON.stringify(a).length; if (len > 1700) flush(); }
  for (const d of s.doms) { cur.doms.push(d); len += JSON.stringify(d).length; if (len > 1700) flush(); }
  for (const n of s.nums) { cur.nums.push(n); len += JSON.stringify(n).length + 1; if (len > 1700) flush(); }
  if (cur.doms.length || cur.nums.length || cur.ann.length || !parts.length) flush();
  return parts;
}
let stating = false;
async function pushStates(force = false) {
  const st = core().settings;
  if (SNAP || !st.pushOn || !st.pushTopic || stating) return;
  if (!force && push.backoff > Date.now()) return;
  fbSeed();
  stating = true;
  if (syncBase) {
    try {
      const map = {}, done = [], ts = Date.now();
      for (const u of core().users) {
        if (isPriv(u) || u.disabled) continue;
        const s = userState(u); if (!s.nums.length && !s.doms.length && !s.ann.length && !u.stH) continue;
        const h = hex(sha256(utf8(JSON.stringify(s)))).slice(0, 12);
        if (u.stH === h && ts - (u.stAt || 0) < 7 * 864e5) continue;
        const pk = userPushKey(u), rid = pushRid(pk);
        map[`u/${rid}/state`] = seal(pk, JSON.stringify({ k: 's', h, ts, i: 0, o: 1, doms: s.doms, nums: s.nums, ann: s.ann })); map[`u/${rid}/v/s`] = ts;
        done.push([u, h]);
        if (done.length >= 40) break;
      }
      if (done.length) { await fbReq('PATCH', '', map); for (const [u, h] of done) { u.stH = h; u.stAt = ts; } touch(); push.ok = true; push.error = ''; push.at = Date.now(); }
    } catch (e) { push.ok = false; push.error = fbErr(e); push.backoff = Date.now() + 15000; }
    finally { stating = false; }
    return;
  }
  try {
    let posts = 0;
    for (const u of core().users) {
      if (isPriv(u) || u.disabled) continue;
      const s = userState(u); if (!s.nums.length && !s.doms.length && !s.ann.length && !u.stH) continue;
      const h = hex(sha256(utf8(JSON.stringify(s)))).slice(0, 12);
      if (u.stH === h && Date.now() - (u.stAt || 0) < STATE_REPUBLISH_MS) continue;
      const parts = stateParts(s); if (posts + parts.length > 24) break;
      const pk = userPushKey(u), rid = pushRid(pk), ts = Date.now();
      for (let i = 0; i < parts.length; i++) {
        const item = { k: 's', h, ts, i, o: parts.length, doms: parts[i].doms, nums: parts[i].nums, ann: parts[i].ann };
        const res = await fetch(pushUrl(), { method: 'POST', body: JSON.stringify({ v: 1, i: [{ r: rid, b: seal(pk, JSON.stringify(item)) }] }) });
        posts++;
        if (!res.ok) { push.ok = false; push.error = res.status === 429 ? 'تجاوزت حد خدمة الإشعارات مؤقتاً، ستُعاد المحاولة' : `خدمة الإشعارات ردت HTTP ${res.status}`; push.backoff = Date.now() + (res.status === 429 ? 60000 : 15000); return; }
      }
      u.stH = h; u.stAt = ts; touch();
    }
  } catch { push.backoff = Date.now() + 15000; } finally { stating = false; }
}
function stateGot(it, uid) {
  const c = core(); c.stg ||= {};
  if (!it.h || !(it.ts > (c.stTs || 0))) return 0;
  const g = c.stg[it.h] ||= { ts: it.ts, o: it.o, p: {} };
  g.p[it.i] = { d: it.doms || [], n: it.nums || [], a: it.ann || [] };
  if (Object.keys(g.p).length < g.o) { touch(); return 0; }
  const doms = [], nums = [], anns = [];
  for (let i = 0; i < g.o; i++) { const p = g.p[i]; if (!p) return 0; doms.push(...p.d); nums.push(...p.n); anns.push(...(p.a || [])); }
  const list = (c.announcements ||= []);
  for (const a of anns) { const e = list.find((y) => y.id === a.id); e ? Object.assign(e, a) : list.push(a); }
  list.sort((x, y) => x.t - y.t);
  const ids = new Set(nums.map((x) => x[0])), ns = new Set(nums.map((x) => digitsOnly(x[1])));
  db.numData.items = numbers().filter((r) => r.u !== uid && !ids.has(r.id) && !ns.has(r.n));
  for (const x of nums) db.numData.items.push({ id: x[0], n: digitsOnly(x[1]), d: x[2], u: uid, a: x[3], t: x[4], sy: 1 });
  const keep = new Set(doms.map((d) => d.id));
  c.domains = c.domains.filter((d) => !d.sy || keep.has(d.id));
  for (const d of doms) { const rec = { id: d.id, name: d.name, apps: d.apps, access: '*', createdAt: d.createdAt, sy: 1 }, e = c.domains.find((y) => y.id === d.id); e ? Object.assign(e, rec) : c.domains.push(rec); }
  c.stTs = g.ts; delete c.stg[it.h];
  for (const k of Object.keys(c.stg)) if (c.stg[k].ts <= g.ts) delete c.stg[k];
  reindex(); persist(); notifyNew(); return 1;
}

/* ---------- التواصل مع الدعم عبر نفس القناة المشفّرة ---------- */
function fileChunk(uid, it) {
  const c = core(), g = ((c.cfp ||= {})[it.id] ||= { o: it.o, p: {} }); g.p[it.i] = String(it.d || '');
  if (Object.keys(g.p).length < g.o) return 0;
  const url = Array.from({ length: g.o }, (_, i) => g.p[i] || '').join(''); delete c.cfp[it.id];
  if (!/^data:[\w.+\/-]+;base64,[A-Za-z0-9+\/=]+$/.test(url)) return 0;
  const m = ((c.chat ||= {})[uid] || []).find((x) => x.id === it.id);
  if (m && m.file) m.file.url = url; else (c.cfd ||= {})[it.id] = url;
  return 1;
}
async function sendFile(pk, id, url) {
  const parts = []; for (let i = 0; i < url.length; i += 2000) parts.push(url.slice(i, i + 2000));
  for (let i = 0; i < parts.length; i++) if (!(await sendBox(pk, { k: 'cf', id, i, o: parts.length, d: parts[i] }))) return false;
  return true;
}
function addChat(uid, it) {
  const th = ((core().chat ||= {})[uid] ||= []);
  if (!it.id || th.some((m) => m.id === it.id)) return 0;
  const rec = { id: String(it.id).replace(/[^\w-]/g, '').slice(0, 40), from: it.from === 's' ? 's' : 'u', name: String(it.name || '').slice(0, 60), text: String(it.text || '').slice(0, 2000), t: Number(it.t) || Date.now() };
  if (it.file && it.file.name) { rec.file = { name: String(it.file.name).slice(0, 120), type: String(it.file.type || '').slice(0, 80), size: Number(it.file.size) || 0, parts: it.file.parts || 0 }; const u0 = it.file.url || (core().cfd || {})[rec.id]; if (u0 && /^data:[\w.+\/-]+;base64,/.test(u0)) rec.file.url = u0; }
  th.push(rec);
  th.sort((a, b) => a.t - b.t); if (th.length > 300) th.splice(0, th.length - 300); return 1;
}
async function sendBox(pk, obj) {
  if (syncBase) {
    try {
      const rid = pushRid(pk), b = seal(pk, JSON.stringify(obj)), ts = Date.now(), me = currentUser();
      await fbReq('PATCH', '', me && isPriv(me) ? { [`u/${rid}/log/${fbKey()}`]: b, [`u/${rid}/v/l`]: ts } : { [`inbox/${fbKey()}`]: { r: rid, b }, inboxv: ts });
      return true;
    } catch (e) { push.error = fbErr(e); return false; }
  }
  try { const r = await fetch(pushUrl(), { method: 'POST', body: JSON.stringify({ v: 1, i: [{ r: pushRid(pk), b: seal(pk, JSON.stringify(obj)) }] }) }); return r.ok; } catch { return false; }
}
let aes = null, aesTimer = null;
function adminReceive(raw) {
  let j; try { j = JSON.parse(raw); } catch { return; }
  if (!j || !Array.isArray(j.i)) return;
  load(); let n = 0, acc = 0;
  for (const box of j.i) {
    if (!box || !box.r) continue;
    const u = core().users.find((x) => x.pk && !isPriv(x) && pushRid(x.pk) === box.r); if (!u) continue;
    let it; try { it = JSON.parse(unseal(u.pk, box.b) || 'null'); } catch { continue; }
    if (!it) continue; acc++;
    if (it.k === 'c' && it.from === 'u') n += addChat(u.id, it);
    if (it.k === 'cf') n += fileChunk(u.id, it);
  }
  if (n) { persist(); notifyNew(); }
  return acc;
}
// فحص صندوق الدعم الدائم: رسائل المستخدمين تبقى في القاعدة حتى يفتح المدير صفحته ثم تُحذف بعد استلامها
let fbAdmV, fbAdmBusy = false;
async function fbAdminPoll() {
  if (fbAdmBusy) return; fbAdmBusy = true;
  try {
    const v = await fbReq('GET', 'inboxv');
    if (v === fbAdmV) return;
    const box = await fbReq('GET', 'inbox') || {}, del = {}, now = Date.now();
    for (const k of Object.keys(box).sort()) {
      const e = box[k]; if (!e || !e.r || typeof e.b !== 'string') { del['inbox/' + k] = null; continue; }
      const acc = adminReceive(JSON.stringify({ i: [e] }));
      if (acc || now - parseInt(k.slice(0, 9), 36) > 2 * 864e5) del['inbox/' + k] = null;
    }
    if (Object.keys(del).length) await fbReq('PATCH', '', del);
    fbAdmV = v; if (push.error && /قاعدة المزامنة/.test(push.error)) push.error = '';
  } catch (e) { push.error = fbErr(e); } finally { fbAdmBusy = false; }
}
function ensureAdminListener() {
  if (SNAP || (typeof EventSource === 'undefined' && !syncBase)) return;
  const u = currentUser(), st = core().settings;
  if (!u || !isPriv(u) || !st.pushOn || !st.pushTopic) { if (aes) { try { aes.close(); } catch { /* تجاهل */ } aes = null; } return; }
  if (syncBase) { fbAdminPoll(); return; }
  if (aes) return;
  aes = new EventSource(pushUrl() + '/sse?since=' + encodeURIComponent(ls.get('nfs_chat_since') || '12h'));
  aes.onmessage = (ev) => { let d; try { d = JSON.parse(ev.data); } catch { return; } if (d.event !== 'message') return; if (d.id) ls.set('nfs_chat_since', d.id); adminReceive(d.message); };
  aes.onerror = () => { try { aes.close(); } catch { /* تجاهل */ } aes = null; clearTimeout(aesTimer); aesTimer = setTimeout(ensureAdminListener, 5000); };
}

/* الاستماع في نسخة المستخدم */
let es = null, esUid = null, esTimer = null;
function myPushKey(uid) { try { const v = JSON.parse(ls.get(PKEY) || 'null'); return v && v.uid === uid ? v.pk : null; } catch { return null; } }
function receive(raw, uid, pk, rid) {
  let j; try { j = JSON.parse(raw); } catch { return 0; }
  if (!j || !Array.isArray(j.i)) return 0;
  const seen = ingest.seen ||= new Set(messages().map((m) => m.k));
  let added = 0;
  for (const box of j.i) {
    if (!box || box.r !== rid) continue;
    const txt = unseal(pk, box.b); if (!txt) continue;
    let it; try { it = JSON.parse(txt); } catch { continue; }
    if (it && it.k === 's') { stateGot(it, uid); continue; }
    if (it && it.k === 'c') { if (it.from === 's' && addChat(uid, it)) { persist(); notifyNew(); } continue; }
    if (it && it.k === 'cf') { if (fileChunk(uid, it)) { persist(); notifyNew(); } continue; }
    if (!it || !it.id || seen.has(it.id)) continue; seen.add(it.id);
    messages().push({ k: it.id, p: 'push', pn: String(it.p || ''), n: digitsOnly(it.n), s: String(it.s || '').slice(0, 60), x: String(it.x || '').slice(0, 600), c: it.c || null, a: APPS[it.a] ? it.a : 'ot', t: Number(it.t) || Date.now(), r: Date.now(), o: uid, earn: Number(it.earn) || 0 });
    added++;
  }
  if (added) { messages().sort((a, b) => a.t - b.t); if (messages().length > MAX_MESSAGES) messages().splice(0, messages().length - MAX_MESSAGES); push.got += added; push.lastAt = Date.now(); persist(); notifyNew(); }
  return added;
}
function stopListen() { if (es) { try { es.close(); } catch { /* تجاهل */ } } es = null; esUid = null; fbUV = {}; fbUBusy = false; push.listening = false; push.connected = false; clearTimeout(esTimer); }
// استقبال المستخدم من القاعدة الدائمة: نسأل عن رقم نسخة صغير؛ إن تغيّر نجلب الحالة و/أو الأكواد الجديدة فقط
let fbUV = {}, fbUBusy = false;
async function fbUserPoll(uid, pk, rid) {
  if (fbUBusy) return; fbUBusy = true;
  try {
    const v = (await fbReq('GET', `u/${rid}/v`)) || {};
    push.connected = true; push.error = ''; push.syncAt = Date.now();
    let changed = 0;
    if (v.s && v.s !== fbUV.s) {
      const b = await fbReq('GET', `u/${rid}/state`);
      if (typeof b === 'string') { load(); receive(JSON.stringify({ i: [{ r: rid, b }] }), uid, pk, rid); }
      fbUV.s = v.s; changed++;
    }
    if (v.l && v.l !== fbUV.l) {
      const since = ls.get(FBSINCE) || '', log = (await fbReq('GET', `u/${rid}/log`, undefined, since ? fbOrderKey + '&startAt=%22' + encodeURIComponent(since) + '%22' : '')) || {}, keys = Object.keys(log).sort();
      if (keys.length) { load(); receive(JSON.stringify({ i: keys.filter((k) => typeof log[k] === 'string').map((k) => ({ r: rid, b: log[k] })) }), uid, pk, rid); ls.set(FBSINCE, keys[keys.length - 1]); }
      fbUV.l = v.l; changed++;
    }
    if (changed) notifyNew();
  } catch (e) { push.connected = false; push.error = fbErr(e); } finally { fbUBusy = false; }
}
const isSyncUser = () => { const u = currentUser(); return !!u && !!u.sync && !isPriv(u); };
function ensureListener() {
  if (!SNAP && !isSyncUser()) return;
  const u = currentUser(), st = core().settings;
  if (!u || isPriv(u) || !st.pushOn || !st.pushTopic) { stopListen(); return; }
  const pk = myPushKey(u.id); if (!pk) { push.error = 'سجّل الخروج ثم الدخول مرة أخرى لتفعيل استقبال الأكواد'; return; }
  if (syncBase) { if (esUid !== u.id) { stopListen(); esUid = u.id; } push.listening = true; fbUserPoll(u.id, pk, pushRid(pk)); return; }
  if (es && esUid === u.id) return;
  stopListen();
  const rid = pushRid(pk), since = ls.get(PSINCE) || '12h';
  esUid = u.id; push.listening = true;
  if (typeof EventSource === 'undefined') return;
  es = new EventSource(pushUrl() + '/sse?since=' + encodeURIComponent(since));
  es.onopen = () => { push.connected = true; push.error = ''; notifyNew(); };
  es.onmessage = (ev) => {
    let d; try { d = JSON.parse(ev.data); } catch { return; }
    if (d.event !== 'message') return;
    if (d.id) ls.set(PSINCE, d.id);
    load(); receive(d.message, u.id, pk, rid);
  };
  es.onerror = () => { push.connected = false; push.error = 'انقطع الاتصال، تتم إعادة المحاولة...'; const cur = es; esTimer = setTimeout(() => { if (es === cur) { stopListen(); ensureListener(); } }, 5000); };
}

/* ---------- البوت (يعمل ما دامت الصفحة مفتوحة) ---------- */
const bot = { last: null, newTotal: 0, panels: {}, running: false };
function activePanels() {
  const a = core().settings.activePanel;
  return a === 'all' ? core().panels.filter((p) => p.enabled) : core().panels.filter((p) => p.id === a && p.enabled);
}

/* ---------- مصدر تيليجرام: البوت يقرأ رسائل المجموعة/القناة التي تصلها من اللوحة ---------- */
const tg = { ok: null, error: '', at: 0, got: 0, skipped: 0, bot: '' };
const tgActive = () => !!(core().settings.tgOn && core().settings.tgToken);
async function fetchTelegram() {
  const st = core().settings; if (!tgActive()) return 0;
  const base = 'https://api.telegram.org/bot' + st.tgToken;
  try {
    if (!tg.bot) { const me = await (await fetch(base + '/getMe')).json(); if (me.ok) tg.bot = '@' + me.result.username; }
    const q = `?timeout=0&limit=100&offset=${Number(st.tgOffset) || 0}&allowed_updates=${encodeURIComponent('["message","edited_message","channel_post","edited_channel_post"]')}`;
    let j = await (await fetch(base + '/getUpdates' + q)).json();
    if (!j.ok && j.error_code === 409 && /webhook/i.test(j.description || '')) { await fetch(base + '/deleteWebhook'); j = await (await fetch(base + '/getUpdates' + q)).json(); }
    if (!j.ok) {
      tg.ok = false; tg.at = Date.now();
      tg.error = j.error_code === 401 ? 'توكن البوت غير صحيح' : j.error_code === 409 ? 'البوت يقرأ منه برنامج آخر الآن، استخدم بوتاً مخصصاً لـ NFSsms' : String(j.description || 'خطأ من تيليجرام').slice(0, 120);
      return 0;
    }
    const items = []; let last = Number(st.tgOffset) || 0;
    for (const u of j.result) {
      last = Math.max(last, u.update_id + 1);
      const m = u.message || u.edited_message || u.channel_post || u.edited_channel_post, text = m && (m.text || m.caption);
      if (!text) continue;
      const number = tgNumber(text, extractCode(text));
      if (!number) { tg.skipped++; continue; }
      items.push({ pid: `${m.chat.id}:${m.message_id}`, number, sender: m.forward_from_chat?.title || m.forward_sender_name || m.chat.title || m.from?.first_name || 'Telegram', content: text, time: (m.date || 0) * 1000 || Date.now() });
    }
    if (last !== (Number(st.tgOffset) || 0)) { st.tgOffset = last; touch(); }
    load(); const added = ingest({ id: 'tg', pn: 'Telegram' }, items);
    tg.ok = true; tg.error = ''; tg.at = Date.now(); tg.got += added; bot.newTotal += added;
    return added;
  } catch { tg.ok = false; tg.error = 'تعذر الوصول لتيليجرام (تحقق من الإنترنت)'; tg.at = Date.now(); return 0; }
}
/* ---------- مصدر الوسيط: يسحب الأكواد من بوت الوسيط مباشرة (بدون توكن تيليجرام وبدون تعارض) ---------- */
const rf = { ok: null, error: '', at: 0, got: 0 };
async function fetchRelayFeed() {
  const st = core().settings, relay = String(st.relayUrl || '').trim(), tok = String(st.relayToken || '').trim();
  if (!relay || !tok) return 0;
  const base = relay.replace(/\/+$/, '').replace(/\/relay$/i, '');
  try {
    const r = await fetch(`${base}/messages?limit=100&token=${encodeURIComponent(tok)}`);
    if (r.status === 401) { rf.ok = false; rf.error = 'مفتاح الوسيط غير صحيح'; rf.at = Date.now(); return 0; }
    if (!r.ok) { rf.ok = false; rf.error = 'الوسيط لا يدعم الإرسال المباشر (حدّث بوت الوسيط) HTTP ' + r.status; rf.at = Date.now(); return 0; }
    const j = await r.json();
    const items = (j.messages || []).filter((m) => m && m.number && m.content).map((m) => ({ pid: 'rl' + String(m.id), number: m.number, sender: m.sender || m.panel || 'Relay', content: m.content, time: parseTime(m.time) }));
    load(); const added = ingest({ id: 'rl', pn: 'Relay' }, items);
    rf.ok = true; rf.error = ''; rf.at = Date.now(); rf.got += added; bot.newTotal += added;
    return added;
  } catch { rf.ok = false; rf.error = 'تعذر الوصول للوسيط'; rf.at = Date.now(); return 0; }
}
async function runBot(force = false) {
  if (bot.running || (!core().settings.botOn && !force)) return;
  bot.running = true;
  try {
    await fetchTelegram();
    await fetchRelayFeed();
    for (const p of activePanels()) {
      try {
        const r = await fetchMessages(p); load(); const added = ingest(p, r.items);
        bot.newTotal += added; bot.panels[p.id] = { ok: true, ms: r.ms, count: r.items.length, added, at: Date.now() };
      } catch (e) { bot.panels[p.id] = { ok: false, error: String(e.message || e).slice(0, 160), ms: e.ms, at: Date.now() }; }
    }
    bot.last = Date.now();
    await pushPending(); await pushStates(); await apiPublish();
  } finally { bot.running = false; }
}
const pushStatus = () => ({ mode: syncBase ? 'durable' : 'temp', syncUrl: syncBase, syncAt: push.syncAt || 0, on: !!core().settings.pushOn, ok: push.ok, at: push.at, sent: push.sent, error: push.error, listening: push.listening, connected: push.connected, got: push.got, lastAt: push.lastAt });
const botStatus = () => ({ on: !!core().settings.botOn && !SNAP, last: bot.last, newTotal: bot.newTotal, running: bot.running, panels: { ...bot.panels }, push: pushStatus(), relayFeed: { ok: rf.ok, error: rf.error, at: rf.at, got: rf.got }, tg: { on: tgActive(), ok: tg.ok, error: tg.error, at: tg.at, got: tg.got, skipped: tg.skipped, bot: tg.bot } });
// تبويب واحد فقط يجلب من اللوحة في نفس المتصفح (لا تكرار ولا تضارب)
const TAB_ID = randHex(6);
function isLeader() {
  let v = null; try { v = JSON.parse(ls.get(LEAD) || 'null'); } catch { v = null; }
  const now = Date.now();
  if (!v || v.id === TAB_ID || now - v.t > Math.max(15000, clampInt(core().settings.pollSeconds, 2, 120, 5) * 3000 + 5000)) { ls.set(LEAD, JSON.stringify({ id: TAB_ID, t: now })); return true; }
  return false;
}
const IS_LOCAL = typeof window !== 'undefined' && String(window.NFS_API || '').trim() === 'local';
let botStarted = false;
export function startBot() { if (!botStarted) { botStarted = true; scheduleBot(); } }
if (IS_LOCAL) { startBot(); setTimeout(() => { try { load(); if (SNAP || isSyncUser()) ensureListener(); else ensureAdminListener(); } catch { /* تجاهل */ } }, 50); }
function scheduleBot() {
  setTimeout(async () => {
    try {
      load();
      if (SNAP || isSyncUser()) ensureListener();
      else { ensureAdminListener(); if (currentUser() && isLeader()) { republishAccts(); if (activePanels().length || tgActive() || core().settings.relayUrl) await runBot(); else { await pushPending(); await pushStates(); await apiPublish(); } } }
    } catch { /* تجاهل */ }
    scheduleBot();
  }, (SNAP ? 3 : clampInt(db?.core.settings.pollSeconds, 2, 120, 5)) * 1000);
}

/* ---------- الجلسة ---------- */
function currentUser() {
  load();
  let s = null; try { s = JSON.parse(ls.get(SESS) || 'null'); } catch { s = null; }
  if (!s || s.exp < Date.now()) { if (s) ls.del(SESS); return null; }
  return core().users.find((u) => u.id === s.uid && !u.disabled && (u.sv || '') === (s.sv || '')) || null;
}
const startSession = (u) => ls.set(SESS, JSON.stringify({ uid: u.id, sv: u.sv, exp: Date.now() + SESSION_DAYS * 864e5 }));
const dropSessions = (u) => { u.sv = randHex(6); touch(); };

/* ---------- قناة آمنة لمزامنة بيانات المديرين بلا خادم ----------
   يُشارك المدير رابطاً يحتوي مفتاحاً عشوائياً. القناة العامة تحمل بيانات مشفّرة فقط؛ لا تُشارك كلمات السر أو جلسات الدخول أو مفاتيح لوحات SMS. */
const managerTopicValid = (v) => !!v && /^nfs-mgr-[a-f0-9]{24}$/.test(v);
function setManagerChannel(value) {
  managerChannel = value && managerTopicValid(value.topic) && /^[a-f0-9]{64}$/.test(value.key || '') ? { topic: value.topic, key: value.key } : null;
  try { managerChannel ? ls.set(MANAGER_CHANNEL_KEY, JSON.stringify(managerChannel)) : ls.del(MANAGER_CHANNEL_KEY); } catch { /* تجاهل */ }
  if (managerEventSource) { try { managerEventSource.close(); } catch {} managerEventSource = null; }
  clearTimeout(managerPollTimer); managerPollTimer = null; managerLastPullAt = 0; managerLastAppliedId = ''; managerLastPublishedId = '';
}
function managerSharedState() {
  const c = core();
  return {
    schema: 1, ts: Date.now(),
    users: c.users.filter((u) => !isPriv(u)).map((u) => ({ id: u.id, username: u.username, name: u.name, role: 'user', disabled: !!u.disabled, createdAt: u.createdAt || 0, phone: u.phone || '' })),
    domains: c.domains.map((d) => ({ id: d.id, name: d.name, apps: d.apps, access: d.access, createdAt: d.createdAt })),
    requests: c.requests.map((r) => ({ ...r })),
    announcements: c.announcements.map((a) => ({ ...a })),
    numbers: numbers().map((r) => ({ id: r.id, n: r.n, d: r.d, u: r.u, a: r.a, t: r.t, c: r.c, rel: r.rel })),
    messages: messages().slice(-1000).map((m) => ({ k: m.k, p: m.p, n: m.n, s: m.s, x: m.x, c: m.c, a: m.a, t: m.t, r: m.r, pay: m.pay || 0, pn: m.pn || '', o: m.o, earn: m.earn })),
    seq: { user: c.seq.user || 0, domain: c.seq.domain || 0, request: c.seq.request || 0, announcement: c.seq.announcement || 0 },
    numSeq: db.numData.seq || 0,
    pricePerCode: Number(c.settings.pricePerCode) || 0,
  };
}
async function managerEncodeState(state) {
  const raw = JSON.stringify(state);
  try {
    if (typeof CompressionStream !== 'undefined') {
      const stream = new Blob([raw]).stream().pipeThrough(new CompressionStream('gzip'));
      return 'gz:' + b64(new Uint8Array(await new Response(stream).arrayBuffer()));
    }
  } catch { /* متصفح قديم: استخدم JSON كما هو */ }
  return 'js:' + raw;
}
async function managerDecodeState(text) {
  if (text.startsWith('js:')) return JSON.parse(text.slice(3));
  if (!text.startsWith('gz:') || typeof DecompressionStream === 'undefined') throw new Error('لا يدعم هذا المتصفح فك ضغط المزامنة');
  const bytes = unb64(text.slice(3));
  const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'));
  return JSON.parse(await new Response(stream).text());
}
async function managerFetchMessages(topic) {
  const ctl = new AbortController(), timer = setTimeout(() => ctl.abort(), 12000);
  try {
    const res = await fetch(`${DEFAULT_PUSH}/${encodeURIComponent(topic)}/json?poll=1&since=all`, { signal: ctl.signal });
    if (!res.ok) throw Object.assign(new Error(`HTTP ${res.status}`), { status: res.status });
    const text = await res.text(), out = [];
    for (const line of text.split('\n')) { try { const e = JSON.parse(line); if (e?.event === 'message' && e.message) out.push(JSON.parse(e.message)); } catch { /* تجاهل رسالة تالفة */ } }
    return out;
  } finally { clearTimeout(timer); }
}
async function managerPost(topic, body) {
  const res = await fetch(`${DEFAULT_PUSH}/${encodeURIComponent(topic)}`, { method: 'POST', headers: { 'Content-Type': 'text/plain; charset=utf-8' }, body });
  if (!res.ok) throw Object.assign(new Error(`تعذر النشر على القناة (HTTP ${res.status})`), { status: res.status });
}
async function publishManagerSnapshot(force = false) {
  if (!managerChannel || managerApplying || !db) return { ok: false, error: 'قناة المديرين غير مفعّلة' };
  const me = currentUser(); if (!me || !isPriv(me)) return { ok: false, error: 'سجّل الدخول بحساب مدير أولاً' };
  if (managerPublishTimer) { clearTimeout(managerPublishTimer); managerPublishTimer = null; }
  try {
    const state = managerSharedState(), id = `${Date.now().toString(36)}-${randHex(3)}`;
    const packed = await managerEncodeState(state), box = seal(managerChannel.key, packed);
    const chunkTopic = `${managerChannel.topic}-${id.replace(/[^a-z0-9-]/gi, '')}`;
    const chunks = box.match(/.{1,1800}/g) || [''];
    for (let i = 0; i < chunks.length; i++) await managerPost(chunkTopic, JSON.stringify({ v: 1, id, i, n: chunks.length, b: chunks[i] }));
    const manifest = { v: 1, id, topic: chunkTopic, n: chunks.length, ts: state.ts };
    await managerPost(managerChannel.topic, JSON.stringify(manifest));
    managerLastPublishedId = id; managerLastAppliedId = id; managerLastPullAt = Date.now(); managerChannelError = '';
    return { ok: true, topic: managerChannel.topic, chunks: chunks.length };
  } catch (e) { managerChannelError = 'تعذر مزامنة بيانات المديرين عبر القناة العامة. تحقق من الإنترنت؛ ' + String(e.message || ''); return { ok: false, error: managerChannelError }; }
}
function applyManagerSnapshot(s, id) {
  if (!s || s.schema !== 1 || !Array.isArray(s.users) || !Array.isArray(s.domains) || !Array.isArray(s.numbers) || !Array.isArray(s.messages)) return false;
  managerApplying = true;
  try {
    const c = core(), localUsers = c.users, privileged = localUsers.filter(isPriv), byName = new Map(localUsers.filter((u) => !isPriv(u)).map((u) => [u.username, u]));
    const users = s.users.filter((u) => u && typeof u.username === 'string' && Number.isFinite(Number(u.id))).map((remote) => {
      const local = byName.get(remote.username) || {};
      // البيانات الحساسة المحلية (تجزئة كلمة السر ومفتاح إرسال الأكواد) لا تدخل القناة ولا تُستبدل.
      return { ...local, ...remote, role: 'user', id: Number(remote.id), username: String(remote.username).toLowerCase() };
    });
    c.users = [...privileged, ...users];
    c.domains = s.domains.map((d) => ({ ...d, id: Number(d.id), apps: Array.isArray(d.apps) ? d.apps : [], access: d.access === '*' ? '*' : (Array.isArray(d.access) ? d.access.map(Number) : []) }));
    c.requests = (s.requests || []).map((r) => ({ ...r }));
    c.announcements = (s.announcements || []).map((a) => ({ ...a }));
    c.seq.user = Math.max(Number(c.seq.user) || 0, Number(s.seq?.user) || 0, ...users.map((u) => Number(u.id) || 0));
    c.seq.domain = Math.max(Number(c.seq.domain) || 0, Number(s.seq?.domain) || 0, ...c.domains.map((d) => Number(d.id) || 0));
    c.seq.request = Math.max(Number(c.seq.request) || 0, Number(s.seq?.request) || 0);
    c.seq.announcement = Math.max(Number(c.seq.announcement) || 0, Number(s.seq?.announcement) || 0);
    db.numData.items = s.numbers.map((r) => ({ ...r, id: Number(r.id), d: Number(r.d), u: r.u == null ? null : Number(r.u) }));
    db.numData.seq = Math.max(Number(db.numData.seq) || 0, Number(s.numSeq) || 0, ...db.numData.items.map((r) => Number(r.id) || 0));
    db.msgData.items = s.messages.map((m) => ({ ...m }));
    c.settings.pricePerCode = Math.max(0, Math.min(1000, Number(s.pricePerCode) || 0));
    reindex();
    managerLastAppliedId = id; managerChannelError = '';
    persist(); notifyNew();
    return true;
  } finally { managerApplying = false; }
}
async function pullManagerSnapshot(force = false) {
  if (!managerChannel || !db) return { ok: false, error: 'قناة المديرين غير مفعّلة' };
  const me = currentUser(); if (!me || !isPriv(me)) return { ok: false, error: 'سجّل الدخول بحساب مدير أولاً' };
  if (managerPullPromise) return managerPullPromise;
  if (!force && Date.now() - managerLastPullAt < 12000) return { ok: true, skipped: true };
  managerPullPromise = (async () => {
    try {
      const manifests = (await managerFetchMessages(managerChannel.topic)).filter((m) => m && m.v === 1 && typeof m.id === 'string' && String(m.topic || '').startsWith(managerChannel.topic + '-') && /^nfs-mgr-[a-f0-9]{24}-[a-z0-9-]+$/i.test(m.topic || '') && Number.isFinite(Number(m.n)));
      const latest = manifests.sort((a, b) => Number(a.ts) - Number(b.ts)).at(-1);
      managerLastPullAt = Date.now();
      if (!latest || latest.id === managerLastAppliedId || latest.id === managerLastPublishedId) return { ok: true, empty: !latest };
      const rows = await managerFetchMessages(latest.topic), parts = new Array(Number(latest.n));
      for (const r of rows) if (r && r.v === 1 && r.id === latest.id && Number.isInteger(r.i) && r.i >= 0 && r.i < parts.length && typeof r.b === 'string') parts[r.i] = r.b;
      if (!parts.length || parts.some((p) => typeof p !== 'string')) { managerChannelError = 'بيانات القناة غير مكتملة؛ ستتم إعادة المحاولة'; return { ok: false, error: managerChannelError }; }
      const packed = unseal(managerChannel.key, parts.join('')); if (!packed) throw new Error('مفتاح القناة غير صحيح');
      const state = await managerDecodeState(packed);
      if (applyManagerSnapshot(state, latest.id)) return { ok: true, id: latest.id };
      throw new Error('تنسيق بيانات القناة غير صالح');
    } catch (e) { managerChannelError = 'تعذر استقبال بيانات المدير الثاني: ' + String(e.message || 'تحقق من الرابط والاتصال'); managerLastPullAt = Date.now(); return { ok: false, error: managerChannelError }; }
    finally { managerPullPromise = null; }
  })();
  return managerPullPromise;
}
function startManagerChannelListener() {
  if (!managerChannel || managerEventSource || managerPollTimer) return;
  try {
    if (typeof EventSource !== 'undefined') {
      managerEventSource = new EventSource(`${DEFAULT_PUSH}/${encodeURIComponent(managerChannel.topic)}/sse?since=all`);
      managerEventSource.onmessage = () => { pullManagerSnapshot(true).catch(() => {}); };
      managerEventSource.onerror = () => { managerChannelError = 'انقطع الاتصال بقناة المديرين؛ ستتم إعادة المحاولة'; };
      return;
    }
  } catch { managerEventSource = null; }
  const poll = async () => { if (!managerChannel) return; await pullManagerSnapshot(true).catch(() => {}); managerPollTimer = setTimeout(poll, 15000); };
  managerPollTimer = setTimeout(poll, 15000);
}
function scheduleManagerPublish() {
  if (!managerChannel || managerApplying || managerPublishTimer) return;
  const me = currentUser(); if (!me || !isPriv(me)) return;
  managerPublishTimer = setTimeout(() => { managerPublishTimer = null; publishManagerSnapshot().catch(() => {}); }, 1800);
}

/* ---------- مزامنة الحسابات بين المتصفحات (بدون خادم خاص بك) ----------
   عند إنشاء المدير حساباً (أو تغيير كلمة سره) يُنشر سجل الحساب مشفّراً بمفتاح مشتق من كلمة سر صاحبه على قناة ntfy.sh عامة
   اسمها مشتق من اسم المستخدم وعنوان الموقع. عندما يكتب المستخدم بياناته في متصفح آخر ولا يجد الحساب محلياً،
   يجلب المتصفح السجل ويفكه بكلمة السر التي كتبها، ثم يحفظه في تخزينه المحلي ويدخل مباشرة دون أي رسالة خطأ.
   كلمة السر لا تُنشر نصاً أبداً، ومن لا يعرفها لا يستطيع فك السجل. تحفظ ntfy.sh الرسائل نحو 12 ساعة،
   لذلك يعيد برنامج المدير نشر السجلات تلقائياً كل بضع ساعات ما دام مفتوحاً. بعد أول دخول ناجح يبقى الحساب محفوظاً في متصفح المستخدم نهائياً. */
const ACCT_REPUBLISH_MS = 5 * 3600e3;
const acctScope = () => { try { const o = location.origin; return o && o !== 'null' ? o : 'file'; } catch { return 'file'; } };
const acctTopic = (username) => 'nfs-acct-' + hex(sha256(utf8('nfs-acct|' + acctScope() + '|' + username))).slice(0, 32);
const acctKey = (password, s) => hashPw(password, 'acct:' + s);
function makeAcct(u, password) {
  const s = randHex(8);
  const rec = { id: u.id, username: u.username, name: u.name, createdAt: u.createdAt, salt: u.salt, hash: u.hash };
  return JSON.stringify({ v: 1, s, b: seal(acctKey(password, s), JSON.stringify(rec)) });
}
let acctBackoff = 0;
async function publishAcct(u) {
  if (SNAP || !u.acct || acctBackoff > Date.now()) return false;
  if (syncBase) {
    try {
      const st = core().settings;
      await fbReq('PUT', 'acct/' + acctTopic(u.username), { a: u.acct, m: u.ps && st.pushTopic ? JSON.stringify({ v: 2, ps: u.ps, pt: st.pushTopic }) : null, ts: Date.now() });
      u.acctAt = Date.now(); u.acctT = st.pushTopic; u.acctB = 'f'; touch(); return true;
    } catch (e) { acctBackoff = Date.now() + 15000; push.error = fbErr(e); return false; }
  }
  try {
    const res = await fetch(DEFAULT_PUSH + '/' + acctTopic(u.username), { method: 'POST', body: u.acct });
    if (!res.ok) { if (res.status === 429) acctBackoff = Date.now() + 60000; return false; }
    const st = core().settings;
    if (u.ps && st.pushTopic) await fetch(DEFAULT_PUSH + '/' + acctTopic(u.username), { method: 'POST', body: JSON.stringify({ v: 2, ps: u.ps, pt: st.pushTopic }) }).catch(() => {});
    u.acctAt = Date.now(); u.acctT = st.pushTopic; touch(); return true;
  } catch { acctBackoff = Date.now() + 15000; return false; }
}
// تعطيل أو حذف المستخدم: نحذف سجل حسابه من القاعدة الدائمة فلا يستطيع فتحه من متصفح جديد
function dropAcct(u) { if (syncBase && !SNAP) fbReq('DELETE', 'acct/' + acctTopic(u.username)).catch(() => {}); }
async function republishAccts() {
  if (SNAP || acctBackoff > Date.now()) return;
  fbSeed();
  let n = 0;
  for (const u of core().users) {
    if (n >= 8) break;
    if (isPriv(u) || u.disabled || !u.acct) continue;
    if (syncBase ? (u.acctB === 'f' && u.acctT === core().settings.pushTopic) : (Date.now() - (u.acctAt || 0) < ACCT_REPUBLISH_MS && u.acctT === core().settings.pushTopic)) continue;
    n++; if (!(await publishAcct(u))) break;
  }
}
// يجلب سجل الحساب من القناة العامة ويفكه بكلمة السر؛ يعيد null إن لم يوجد أو لم تطابق كلمة السر.
let pullErr = '';
async function pullAcct(username, password) {
  pullErr = '';
  if (syncBase) {
    try {
      const d = await fbReq('GET', 'acct/' + acctTopic(username));
      if (!d || typeof d.a !== 'string') return null;
      const e = JSON.parse(d.a); let meta = null; try { const m = d.m && JSON.parse(d.m); meta = m && m.ps && m.pt ? m : null; } catch { meta = null; }
      if (!e || e.v !== 1 || typeof e.s !== 'string' || typeof e.b !== 'string') return null;
      let rec = null; try { const t = unseal(acctKey(password, e.s), e.b); rec = t && JSON.parse(t); } catch { rec = null; }
      return rec && rec.username === username && rec.salt && rec.hash && checkPw(rec, password) ? { rec, acct: d.a, meta } : null;
    } catch (e) { pullErr = e instanceof SyntaxError ? '' : fbErr(e); return null; }
  }
  try {
    const ctl = new AbortController(), timer = setTimeout(() => ctl.abort(), 8000);
    let text = '';
    try { const res = await fetch(`${DEFAULT_PUSH}/${acctTopic(username)}/json?poll=1&since=all`, { signal: ctl.signal }); if (!res.ok) return null; text = await res.text(); }
    finally { clearTimeout(timer); }
    const envs = [];
    for (const line of text.split('\n')) { try { const m = JSON.parse(line); if (m && m.event === 'message' && m.message) envs.push(JSON.parse(m.message)); } catch { /* تجاهل سطراً تالفاً */ } }
    const meta = envs.find((e) => e && e.v === 2 && e.ps && e.pt) || null; // الأحدث أولاً بعد العكس أدناه
    const keys = new Map();
    for (const e of envs.reverse().slice(0, 8)) {
      if (!e || e.v !== 1 || typeof e.s !== 'string' || typeof e.b !== 'string') continue;
      if (!keys.has(e.s)) keys.set(e.s, acctKey(password, e.s));
      let rec = null; try { const t = unseal(keys.get(e.s), e.b); rec = t && JSON.parse(t); } catch { rec = null; }
      if (rec && rec.username === username && rec.salt && rec.hash && checkPw(rec, password)) return { rec, acct: JSON.stringify({ v: 1, s: e.s, b: e.b }), meta };
    }
  } catch { /* لا اتصال أو لا سجل */ }
  return null;
}
// يضيف الحساب المجلوب إلى تخزين هذا المتصفح (أو يحدّثه إن تغيّرت كلمة السر).
function adoptAcct({ rec, acct, meta }) {
  let u = core().users.find((x) => x.username === rec.username);
  if (u && isPriv(u)) return null;
  if (u) Object.assign(u, { name: rec.name || u.name, salt: rec.salt, hash: rec.hash, disabled: false, acct, acctAt: Date.now() });
  else {
    const id = core().users.some((x) => x.id === rec.id) ? ++core().seq.user : rec.id;
    core().seq.user = Math.max(core().seq.user, id);
    u = { id, username: rec.username, name: rec.name || rec.username, role: 'user', disabled: false, createdAt: rec.createdAt || Date.now(), salt: rec.salt, hash: rec.hash, acct, acctAt: Date.now() };
    core().users.push(u);
  }
  if (meta) { u.ps = meta.ps; u.sync = 1; Object.assign(core().settings, { pushTopic: meta.pt, pushOn: true }); }
  persist(); return u;
}

const lockouts = new Map(), LOCK_MS = 15 * 60e3;
const lockState = (name) => { const s = lockouts.get(name) || { n: 0, t: 0 }; if (Date.now() - s.t > LOCK_MS) s.n = 0; return s; };

/* ---------- المسارات ---------- */
const routes = [];
const route = (method, pattern, opts, handler) => routes.push({ method, re: new RegExp(`^${pattern.replace(/:(\w+)/g, '(?<$1>[^/]+)')}$`), opts, handler });
const AUTH = { auth: true }, ADMIN = { auth: true, admin: true }, MANAGER = { auth: true, manager: true }, OPEN = {};

route('POST', '/api/login', OPEN, async ({ body }) => {
  const username = str(body.username, 64).toLowerCase().replace(/\s+/g, '');
  const lock = lockState(username);
  if (lock.n >= 10) throw new HttpError(429, 'الحساب مقفل مؤقتاً 15 دقيقة بسبب محاولات خاطئة');
  let user = core().users.find((u) => u.username === username && !u.disabled);
  // نسمح بمسافات زائدة في بداية/نهاية كلمة السر (تحدث عند النسخ واللصق من الهاتف)
  let pw = typeof body.password === 'string' ? body.password : '';
  let ok = user && checkPw(user, pw);
  if (!ok && user && pw !== pw.trim() && checkPw(user, pw.trim())) { pw = pw.trim(); ok = true; }
  // الحساب أنشأه المدير في متصفح آخر (أو تغيّرت كلمة سره): نجلبه من القناة العامة ونحفظه في هذا المتصفح
  if (!ok && !SNAP && username && pw && !(user && isPriv(user))) {
    const got = (await pullAcct(username, pw)) || (pw !== pw.trim() ? await pullAcct(username, pw.trim()) : null);
    if (got) { const u = adoptAcct(got); if (u) { user = u; ok = true; if (pw !== pw.trim() && !checkPw(u, pw)) pw = pw.trim(); } }
  }
  if (!ok && !user && syncBase && pullErr) throw new HttpError(503, pullErr);
  if (!ok) {
    lock.n++; lock.t = Date.now(); lockouts.set(username, lock);
    if (!user) throw new HttpError(401, SUPPORT_MSG);
    throw new HttpError(401, SNAP
      ? 'اسم المستخدم أو كلمة السر غير صحيحة. إن غيّر المدير كلمة سرك بعد إصدار هذا الملف فاطلب نسخة جديدة.'
      : 'اسم المستخدم أو كلمة السر غير صحيحة');
  }
  body.password = pw;
  lockouts.delete(username);
  if (!SNAP && !isPriv(user) && !user.sync) { const g = await pullAcct(username, pw).catch(() => null); if (g && g.meta) adoptAcct(g); }
  startSession(user);
  if ((SNAP || user.sync) && !isPriv(user)) {
    const pk = typeof user.pkx === 'string' ? user.pkx : (user.ps ? pushKey(body.password, user.ps) : null);
    if (pk) { ls.set(PKEY, JSON.stringify({ uid: user.id, pk })); stopListen(); ensureListener(); }
  }
  return { user: publicUser(user), token: 'local' };
});
route('POST', '/api/logout', OPEN, () => { ls.del(SESS); stopListen(); return { ok: true }; });
route('GET', '/api/me', AUTH, ({ user }) => ({ user: publicUser(user), apps: Object.fromEntries(Object.entries(APPS).map(([k, v]) => [k, v.name])), settings: { price: core().settings.pricePerCode } }));
route('GET', '/api/manager-sync', MANAGER, async () => {
  if (!managerChannel) managerChannel = readManagerChannel();
  startManagerChannelListener();
  await pullManagerSnapshot().catch(() => {});
  return { enabled: !!managerChannel, topic: managerChannel?.topic || '', key: managerChannel?.key || '', error: managerChannelError || '', lastSync: managerLastPullAt || 0 };
});
route('POST', '/api/manager-sync', MANAGER, async ({ user, body }) => {
  if (body.create) {
    if (user.role !== 'admin') throw new HttpError(403, 'إنشاء قناة جديدة متاح للمدير الأول فقط');
    if (!managerChannel || body.regenerate) setManagerChannel({ topic: 'nfs-mgr-' + randHex(12), key: randHex(32) });
    startManagerChannelListener();
    const r = await publishManagerSnapshot(true);
    return { enabled: true, topic: managerChannel.topic, key: managerChannel.key, ...r };
  }
  if (body.disable) {
    if (user.role !== 'admin') throw new HttpError(403, 'إيقاف القناة متاح للمدير الأول فقط');
    setManagerChannel(null); return { enabled: false };
  }
  if (body.republish) {
    startManagerChannelListener();
    const r = await publishManagerSnapshot(true); return { enabled: !!managerChannel, topic: managerChannel?.topic || '', key: managerChannel?.key || '', ...r };
  }
  const r = await pullManagerSnapshot(true); return { enabled: !!managerChannel, topic: managerChannel?.topic || '', key: managerChannel?.key || '', ...r };
});
route('POST', '/api/me/password', AUTH, ({ user, body }) => {
  if (!checkPw(user, String(body.current || ''))) throw bad('كلمة السر الحالية غير صحيحة');
  if (String(body.next || '').length < 4) throw bad('كلمة السر الجديدة 4 أحرف على الأقل');
  Object.assign(user, newCred(String(body.next)));
  if (!SNAP && !isPriv(user)) { user.acct = makeAcct(user, String(body.next)); user.acctAt = 0; publishAcct(user); }
  touch(); return { ok: true };
});

function buildStats(user, tz) {
  const isAdmin = isPriv(user), now = Date.now();
  const owned = ownedMessages(isAdmin ? null : user.id).filter((x) => x.m.c);
  const todayKey = dayKey(now, tz);
  const series = Array.from({ length: 7 }, (_, i) => ({ day: (todayKey - 6 + i) * 864e5 + tz * 60000, n: 0 }));
  const apps = {}; let todayCount = 0, mine = 0;
  for (const { m, r } of owned) {
    if (isAdmin && !r) continue;
    mine++;
    const k = dayKey(m.t, tz); if (k === todayKey) todayCount++;
    const idx = k - (todayKey - 6); if (idx >= 0 && idx < 7) series[idx].n++;
    apps[m.a] = (apps[m.a] || 0) + 1;
  }
  const price = Number(core().settings.pricePerCode) || 0;
  let payTotal = 0; for (const { m, r } of owned) if (r) payTotal += m.pay || 0;
  const base = { payTotal: user.role === 'admin' ? +payTotal.toFixed(3) : 0, codes: mine, codesToday: todayCount, series, price, earnings: +(mine * price).toFixed(3), apps: Object.entries(apps).map(([k, n]) => ({ k, n })).sort((a, b) => b.n - a.n) };
  if (!isAdmin) {
    const mineNums = numbers().filter((r) => r.u === user.id);
    const extra = new Set(); for (const { r } of owned) if (r && r.pushed && !lookupNumber(r.n)) extra.add(r.n);
    for (const n of extra) mineNums.push({ a: owned.find((x) => x.r && x.r.n === n)?.m.a || 'ot' });
    return { ...base, numbers: mineNums.length, pending: core().requests.filter((r) => r.userId === user.id && r.status === 'pending').length, byApp: Object.entries(mineNums.reduce((a, r) => ((a[r.a] = (a[r.a] || 0) + 1), a), {})).map(([k, n]) => ({ k, n })) };
  }
  const total = numbers().length, assigned = numbers().reduce((n, r) => n + (r.u ? 1 : 0), 0);
  let unowned = 0; for (const m of messages()) if (m.c && !messageOwner(m)) unowned++;
  const perUser = {}; for (const { m, r } of owned) if (r) perUser[r.u] = (perUser[r.u] || 0) + 1;
  return {
    ...base, users: core().users.filter((u) => !isPriv(u)).length, domains: core().domains.length, numbers: total, assigned, free: total - assigned, unowned,
    pending: core().requests.filter((r) => r.status === 'pending').length,
    top: Object.entries(perUser).map(([id, n]) => ({ id: +id, name: userOf(+id)?.name || '—', username: userOf(+id)?.username || '', n })).sort((a, b) => b.n - a.n).slice(0, 5),
    bot: botStatus(), activePanel: core().settings.activePanel,
  };
}
route('GET', '/api/stats', AUTH, ({ user, query }) => buildStats(user, clampInt(query.get('tz'), -840, 840, 0)));

route('GET', '/api/codes', AUTH, ({ user, query }) => {
  const scope = query.get('scope') || 'all', items = [];
  for (const { m, r } of ownedMessages(isPriv(user) ? null : user.id)) {
    if (isPriv(user) && scope === 'owned' && !r) continue;
    if (isPriv(user) && scope === 'unowned' && r) continue;
    const it = codeDto(m, r); if (m.earn != null && m.o) it.earn = m.earn; if (user.role !== 'admin') delete it.pay;
    items.push(it);
    if (items.length >= 200) break;
  }
  return { items, bot: botStatus(), price: Number(core().settings.pricePerCode) || 0, rev: String(core().stTs || 0) };
});

/* ---------- واجهة API لبوتات تيليجرام (بدون خادم) ----------
   متصفح المدير ينشر كل كود جديد كنص JSON على قناة عامة سرية الاسم (مفتاح عشوائي طويل). أي بوت يقرأها بطلب GET عادي
   من رابط القناة، دون خادم ودون تثبيت. الرابط هو المفتاح: من لا يعرفه لا يستطيع القراءة، ويمكن تغييره في أي وقت. */
const apiBase = () => String(core().settings.pushServer || DEFAULT_PUSH).replace(/\/+$/, '');
const KEY_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
// مفتاح بصيغة nfs_ + 32 حرفاً ورقماً (يُستخدم أيضاً اسماً للقناة السرية)
const genApiKey = () => { const a = new Uint8Array(32); (globalThis.crypto || window.crypto).getRandomValues(a); let k = ''; for (const x of a) k += KEY_CHARS[x % KEY_CHARS.length]; return 'nfs_' + k; };
const cleanSiteUrl = (v) => { const t = String(v || '').trim().replace(/\/+$/, ''); if (!t) return ''; if (!/^https?:\/\/[^\s/?#]+(\/[^\s?#]*)?$/i.test(t)) throw bad('رابط الموقع غير صالح، مثال: https://example.com'); return t.slice(0, 200); };
// لكل حساب قناة/مفتاح nfs_ مستقل: المستخدم يقرأ أكواده فقط، والمدير والمشرف يقرآن كل الأكواد
function userTopic(u) { if (!/^nfs/.test(u.apiTopic || '')) { u.apiTopic = genApiKey(); u.apiSince = Date.now(); touch(); } return u.apiTopic; }
function apiKit(u) {
  const st = core().settings, mgr = isPriv(u);
  if (!/^nfs/.test(u.apiTopic || '') && u.role === 'admin' && /^nfs/.test(st.apiTopic || '')) { u.apiTopic = st.apiTopic; u.apiSince = u.apiSince || Date.now(); u.apiOn = !!st.apiOn; touch(); }
  const base = { mode: 'push', siteUrl: st.siteUrl || '', base: apiBase(), scope: mgr ? 'all' : 'own', canEditUrl: mgr, locked: !mgr };
  // نسخة المستخدمين القديمة لا تحمل قناته: يلزم تصدير نسخة جديدة من المدير
  if (SNAP && !/^nfs/.test(u.apiTopic || '')) return { ...base, on: false, unavailable: true, key: '', topic: '', read: '', sent: 0 };
  const topic = userTopic(u);
  return { ...base, on: mgr ? !!u.apiOn : u.apiOn !== false, topic, key: topic, read: `${apiBase()}/${topic}/json?poll=1&since=10m`, sent: u.apiSent || 0 };
}
let apiBusy = false;
async function apiPublish() {
  if (SNAP || apiBusy) return 0;
  const users = core().users.filter((u) => !u.disabled && (isPriv(u) ? u.apiOn : u.apiOn !== false));
  if (!users.length) return 0;
  const list = messages(), out = [];
  for (let k = list.length - 1; k >= 0 && out.length < 30; k--) { const m = list[k]; if (m.ap) continue; if (!m.c) { m.ap = 1; continue; } out.push(m); }
  if (!out.length) return 0; apiBusy = true; let n = 0;
  try {
    for (const m of out.reverse()) {
      const r = messageOwner(m), owner = r ? userOf(r.u) : null;
      const targets = users.filter((u) => (isPriv(u) || (owner && u.id === owner.id)) && m.t >= (u.apiSince || 0));
      const body = JSON.stringify({ id: m.k, number: m.n, app: m.a, code: m.c, sender: m.s, text: m.x, time: m.t, user: owner ? owner.username : null });
      let ok = true;
      for (const u of targets) { const res = await fetch(`${apiBase()}/${userTopic(u)}`, { method: 'POST', body }); if (!res.ok) { ok = false; break; } u.apiSent = (u.apiSent || 0) + 1; }
      if (!ok) break;
      m.ap = 1; n++;
    }
  } catch { /* ستُعاد المحاولة */ } finally { apiBusy = false; if (n) persist(); }
  return n;
}
route('GET', '/api/apikit', AUTH, ({ user }) => apiKit(user));
route('POST', '/api/apikit', AUTH, ({ user, body }) => {
  const mgr = isPriv(user);
  if (body.on != null) {
    if (!mgr) throw bad('تفعيل API لحسابك يتحكم به المدير في هذا الوضع');
    const on = !!body.on; if (on && !user.apiOn) user.apiSince = Date.now(); user.apiOn = on;
  }
  if (body.siteUrl != null) { if (!mgr) throw new HttpError(403, 'رابط الموقع يضبطه المدير فقط'); core().settings.siteUrl = cleanSiteUrl(body.siteUrl); }
  if (body.regen) { if (SNAP) throw bad('اطلب من المدير نسخة محدّثة لتغيير المفتاح'); user.apiTopic = genApiKey(); user.apiSince = Date.now(); }
  persist(); return apiKit(user);
});
route('POST', '/api/apikit/test', AUTH, async ({ user }) => {
  const kit = apiKit(user); if (kit.unavailable) throw bad('نسخة حسابك لا تحمل مفتاح API، اطلب نسخة جديدة من المدير');
  const t0 = Date.now(), id = 'test-' + Date.now().toString(36);
  const res = await fetch(`${kit.base}/${kit.topic}`, { method: 'POST', body: JSON.stringify({ id, number: '0000000000', app: 'ot', code: '123456', sender: 'NFSsms', text: 'API test', time: Date.now(), user: null, test: true }) });
  if (!res.ok) throw bad('تعذر النشر على القناة، تحقق من الإنترنت');
  const txt = await (await fetch(kit.read)).text();
  return { ok: txt.includes(id), ms: Date.now() - t0, url: kit.read };
});

route('GET', '/api/chat', AUTH, ({ user, query }) => {
  const ch = (core().chat ||= {});
  if (!isPriv(user)) return { items: (ch[user.id] || []).slice(-200) };
  const q = Number(query.get('u'));
  if (q) { const x = userOf(q); return { items: (ch[q] || []).slice(-200), user: x ? { id: x.id, username: x.username, name: x.name } : null }; }
  const threads = Object.entries(ch).filter(([, t]) => t.length).map(([uid, t]) => { const x = userOf(Number(uid)), l = t[t.length - 1]; return { uid: Number(uid), username: x?.username || '', name: x?.name || '', last: l.text.slice(0, 80), from: l.from, t: l.t, n: t.length }; }).sort((a, b) => b.t - a.t);
  return { threads };
});
route('POST', '/api/chat', AUTH, async ({ user, body }) => {
  const mgr = isPriv(user), uid = mgr ? Number(body.to) : user.id, target = userOf(uid);
  if (!target) throw bad('المستخدم غير موجود');
  const text = str(body.text, 2000), f = body.file && typeof body.file.data === 'string' ? body.file : null;
  if (!text && !f) throw bad('اكتب رسالة');
  if (f && (f.data.length > 56000 || !/^data:[\w.+\/-]+;base64,[A-Za-z0-9+\/=]+$/.test(f.data))) throw bad('بدون خادم: الصور تُصغَّر تلقائياً، والملفات حتى 40KB');
  const item = { id: String(body.id || '').replace(/[^\w-]/g, '').slice(0, 40) || 'c' + Date.now().toString(36), from: mgr ? 's' : 'u', name: user.name || user.username, text, t: Date.now() };
  if (f) item.file = { name: String(f.name || 'file').slice(0, 120), type: String(f.type || 'application/octet-stream'), size: Number(f.size) || 0, url: f.data };
  addChat(uid, item); persist();
  const pk = mgr ? userPushKey(target) : ((SNAP || user.sync) ? myPushKey(user.id) : userPushKey(user));
  if (pk && core().settings.pushOn && core().settings.pushTopic) {
    const wire = { k: 'c', ...item }; if (item.file) wire.file = { name: item.file.name, type: item.file.type, size: item.file.size, parts: Math.ceil(item.file.url.length / 2000) };
    sendBox(pk, wire).then((ok) => ok && item.file && sendFile(pk, item.id, item.file.url));
  }
  return { item };
});

route('GET', '/api/my/numbers', AUTH, ({ user }) => {
  const last = new Map();
  for (const { m, r } of ownedMessages(user.id)) if (m.c && !last.has(r.id)) last.set(r.id, { c: m.c, t: m.t, a: m.a });
  const items = numbers().filter((r) => r.u === user.id).map((r) => ({ id: r.id, n: r.n, a: r.a, d: r.d, dn: domainOf(r.d)?.name || '', t: r.t, last: last.get(r.id) || null }));
  const have = new Set(items.map((x) => x.n));
  for (const { m, r } of ownedMessages(user.id)) if (r && r.pushed && !have.has(r.n)) { have.add(r.n); items.push({ id: r.id, n: r.n, a: m.a, d: 0, dn: m.pn || '', t: m.t, last: last.get(r.id) || null }); }
  items.sort((a, b) => b.t - a.t); return { items };
});

/* النطاقات */
route('GET', '/api/domains', AUTH, ({ user }) => {
  const counts = domainCounts(), mine = {};
  for (const r of numbers()) if (r.u === user.id) (mine[r.d] ||= {})[r.a] = (mine[r.d][r.a] || 0) + 1;
  return { items: core().domains.filter((d) => canSeeDomain(user, d)).map((d) => { const c = counts.get(d.id) || { total: 0, free: 0, assigned: 0 }; return { id: d.id, name: d.name, apps: d.apps, access: d.access, createdAt: d.createdAt, ...(isPriv(user) ? c : { free: c.free > 0 }), mine: mine[d.id] || {} }; }) };
});
function cleanDomainInput(body, partial) {
  const out = {};
  if (!partial || body.name != null) {
    const name = str(body.name, 120).toLowerCase();
    if (!/^[a-z0-9؀-ۿ][a-z0-9؀-ۿ._-]{0,118}$/.test(name)) throw bad('اسم النطاق غير صالح');
    out.name = name;
  }
  if (!partial || body.apps != null) {
    const apps = [...new Set((Array.isArray(body.apps) ? body.apps : []).filter((a) => APPS[a] && a !== 'ot'))];
    if (!apps.length) throw bad('اختر تطبيقاً واحداً على الأقل');
    out.apps = apps;
  }
  if (!partial || body.access != null) out.access = body.access === '*' ? '*' : (Array.isArray(body.access) ? body.access.map(Number).filter((id) => userOf(id)) : []);
  return out;
}
route('POST', '/api/domains', MANAGER, ({ body }) => {
  const d = cleanDomainInput(body, false);
  if (core().domains.some((x) => x.name === d.name)) throw bad('هذا النطاق موجود مسبقاً');
  const rec = { id: ++core().seq.domain, createdAt: Date.now(), ...d }; core().domains.push(rec); touch(); return { item: rec };
});
route('PATCH', '/api/domains/:id', MANAGER, ({ params, body }) => {
  const d = domainOf(params.id); if (!d) throw new HttpError(404, 'النطاق غير موجود');
  const upd = cleanDomainInput(body, true);
  if (upd.name && core().domains.some((x) => x.name === upd.name && x.id !== d.id)) throw bad('هذا الاسم مستخدم');
  Object.assign(d, upd); touch(); return { item: d };
});
route('DELETE', '/api/domains/:id', MANAGER, ({ params }) => {
  const d = domainOf(params.id); if (!d) throw new HttpError(404, 'النطاق غير موجود');
  db.numData.items = numbers().filter((r) => r.d !== d.id); reindex();
  core().domains = core().domains.filter((x) => x.id !== d.id); core().requests = core().requests.filter((r) => r.domainId !== d.id);
  touch(); return { ok: true };
});
route('GET', '/api/domains/:id/numbers', MANAGER, ({ params, query }) => {
  const d = domainOf(params.id); if (!d) throw new HttpError(404, 'النطاق غير موجود');
  const filter = query.get('filter') || 'all', q = digitsOnly(query.get('q') || '');
  const offset = clampInt(query.get('offset'), 0, 1e7, 0), limit = clampInt(query.get('limit'), 1, 200, 100);
  const list = numbers().filter((r) => r.d === d.id && (filter === 'all' || (filter === 'free' ? !r.u : !!r.u)) && (!q || r.n.includes(q)));
  return { total: list.length, items: list.slice(offset, offset + limit).map((r) => ({ id: r.id, n: r.n, u: r.u, un: r.u ? userOf(r.u)?.username : null, a: r.a, t: r.t })) };
});
route('POST', '/api/domains/:id/numbers/import', MANAGER, ({ params, body }) => {
  const d = domainOf(params.id); if (!d) throw new HttpError(404, 'النطاق غير موجود');
  const { valid, invalid } = parseNumbers(body.text);
  let added = 0, duplicates = 0; const now = Date.now();
  for (const n of valid) {
    if (lookupNumber(n)?.n === n) { duplicates++; continue; }
    const rec = { id: ++db.numData.seq, d: d.id, n, u: null, a: null, t: 0, c: now };
    numbers().push(rec); byDigits.set(n, rec); const k = n.slice(-9), arr = byLast9.get(k); if (arr) arr.push(rec); else byLast9.set(k, [rec]);
    added++;
  }
  if (added) touch();
  return { added, duplicates, invalid, total: valid.length };
});
route('POST', '/api/domains/:id/numbers/replace', MANAGER, ({ params, body }) => {
  const d = domainOf(params.id); if (!d) throw new HttpError(404, 'النطاق غير موجود');
  const ids = new Set((Array.isArray(body.ids) ? body.ids : []).map(Number).filter(Number.isFinite));
  if (!ids.size) throw bad('حدد الأرقام القديمة التي تريد استبدالها');
  const selected = numbers().filter((r) => ids.has(r.id));
  if (selected.length !== ids.size || selected.some((r) => r.d !== d.id)) throw bad('بعض الأرقام المحددة لا تتبع هذا النطاق؛ حدّث القائمة ثم أعد الاختيار');
  const { valid, invalid } = parseNumbers(body.text);
  if (!valid.length) throw bad('أدخل رقماً جديداً صالحاً واحداً على الأقل؛ لم يُحذف أي رقم');
  const outside = new Set(numbers().filter((r) => !ids.has(r.id)).map((r) => r.n));
  const additions = [], seen = new Set(); let duplicates = 0;
  for (const n of valid) { if (outside.has(n) || seen.has(n)) { duplicates++; continue; } seen.add(n); additions.push(n); }
  if (!additions.length) throw bad('كل الأرقام الجديدة موجودة مسبقاً خارج الاختيار؛ لم يُحذف أي رقم');
  const assignedRemoved = selected.filter((r) => r.u).length, now = Date.now();
  db.numData.items = numbers().filter((r) => !ids.has(r.id));
  for (const n of additions) db.numData.items.push({ id: ++db.numData.seq, d: d.id, n, u: null, a: null, t: 0, c: now });
  reindex(); touch();
  return { replaced: selected.length, added: additions.length, duplicates, invalid, unassigned: assignedRemoved, total: valid.length };
});
route('POST', '/api/domains/:id/numbers/assign', MANAGER, ({ params, body }) => {
  const d = domainOf(params.id); if (!d) throw new HttpError(404, 'النطاق غير موجود');
  const u = userOf(Number(body.userId)); if (!u || isPriv(u)) throw bad('اختر مستخدماً');
  if (!d.apps.includes(body.app)) throw bad('هذا التطبيق غير مفعّل في النطاق');
  const count = clampInt(body.count, 1, 100000, 0); if (!count) throw bad('أدخل عدداً صحيحاً');
  const free = numbers().reduce((n, r) => n + (r.d === d.id && !r.u ? 1 : 0), 0);
  if (free < count) throw new HttpError(409, `المتوفر ${free} رقم فقط`);
  return { assigned: assignNumbers(d.id, u.id, body.app, count) };
});
route('POST', '/api/numbers/release', MANAGER, ({ body }) => {
  const ids = new Set((Array.isArray(body.ids) ? body.ids : []).map(Number)); let n = 0;
  for (const r of numbers()) if (ids.has(r.id) && r.u) { releaseRec(r); n++; }
  if (n) touch(); return { released: n };
});
route('POST', '/api/numbers/delete', MANAGER, ({ body }) => {
  const ids = new Set((Array.isArray(body.ids) ? body.ids : []).map(Number)), before = numbers().length;
  db.numData.items = numbers().filter((r) => !ids.has(r.id)); reindex(); touch(); return { deleted: before - numbers().length };
});
route('GET', '/api/domains/:id/export', ADMIN, ({ params }) => {
  const d = domainOf(params.id); if (!d) throw new HttpError(404, 'النطاق غير موجود');
  const rows = ['number,status,user,app'].concat(numbers().filter((r) => r.d === d.id).map((r) => `${r.n},${r.u ? 'assigned' : 'free'},${r.u ? userOf(r.u)?.username || '' : ''},${r.a || ''}`));
  return { raw: rows.join('\n'), type: 'text/csv; charset=utf-8' };
});

/* الطلبات */
route('GET', '/api/requests', AUTH, ({ user }) => {
  const list = core().requests.filter((r) => isPriv(user) || r.userId === user.id).sort((a, b) => b.createdAt - a.createdAt).slice(0, 100);
  return { items: list.map((r) => ({ ...r, dn: domainOf(r.domainId)?.name || '—', un: userOf(r.userId)?.name || '—', uu: userOf(r.userId)?.username || '' })) };
});
route('POST', '/api/requests', AUTH, ({ user, body }) => {
  const d = domainOf(body.domainId); if (!d || !canSeeDomain(user, d)) throw bad('النطاق غير متاح');
  if (!d.apps.includes(body.app)) throw bad('التطبيق غير متاح في هذا النطاق');
  const count = clampInt(body.count, 1, 10000, 0); if (!count) throw bad('أدخل عدداً صحيحاً');
  if (core().requests.some((r) => r.userId === user.id && r.domainId === d.id && r.app === body.app && r.status === 'pending')) throw bad('لديك طلب معلّق لهذا التطبيق');
  core().requests.push({ id: ++core().seq.request, userId: user.id, domainId: d.id, app: body.app, count, note: str(body.note, 300), status: 'pending', createdAt: Date.now() });
  touch(); return { ok: true };
});
route('POST', '/api/requests/:id/decide', MANAGER, ({ params, body }) => {
  const r = core().requests.find((x) => x.id === Number(params.id) && x.status === 'pending'); if (!r) throw new HttpError(404, 'الطلب غير موجود');
  if (body.accept) {
    const count = clampInt(body.count, 1, 100000, r.count);
    const free = numbers().reduce((n, x) => n + (x.d === r.domainId && !x.u ? 1 : 0), 0);
    if (free < count) throw new HttpError(409, `المتوفر ${free} رقم فقط`);
    r.assigned = assignNumbers(r.domainId, r.userId, r.app, count); r.status = 'accepted';
  } else r.status = 'rejected';
  r.decidedAt = Date.now(); touch(); return { ok: true };
});

/* الإعلانات */
route('GET', '/api/announcements', AUTH, () => ({ items: core().announcements.slice(-50).reverse() }));
route('POST', '/api/announcements', MANAGER, ({ user, body }) => {
  const title = str(body.title, 160), text = String(body.body ?? '').trim().slice(0, 5000);
  if (!title || !text) throw bad('العنوان والنص مطلوبان');
  const item = { id: ++core().seq.announcement, title, body: text, by: user.name || user.username, t: Date.now() };
  core().announcements.push(item); if (core().announcements.length > 200) core().announcements.splice(0, core().announcements.length - 200);
  touch(); return { item };
});
route('DELETE', '/api/announcements/:id', MANAGER, ({ params }) => {
  const i = core().announcements.findIndex((a) => a.id === Number(params.id)); if (i < 0) throw new HttpError(404, 'الإعلان غير موجود');
  core().announcements.splice(i, 1); touch(); return { ok: true };
});

/* المستخدمون */
route('GET', '/api/users', MANAGER, () => {
  const nums = {}; for (const r of numbers()) if (r.u) nums[r.u] = (nums[r.u] || 0) + 1;
  const codes = {}; for (const { m, r } of ownedMessages(null)) if (r && m.c) codes[r.u] = (codes[r.u] || 0) + 1;
  return { items: core().users.filter((u) => !isPriv(u)).map((u) => ({ ...publicUser(u), disabled: !!u.disabled, createdAt: u.createdAt, phone: u.phone || '', numbers: nums[u.id] || 0, codes: codes[u.id] || 0, needsReset: !SNAP && (!u.ps || !u.acct) })) };
});
route('GET', '/api/users/:id/numbers', MANAGER, ({ params }) => {
  const u = userOf(Number(params.id)); if (!u || isPriv(u)) throw new HttpError(404, 'المستخدم غير موجود');
  const items = numbers().filter((r) => r.u === u.id).map((r) => ({ id: r.id, n: r.n, a: r.a, d: r.d, dn: domainOf(r.d)?.name || '', t: r.t }));
  items.sort((a, b) => b.t - a.t);
  return { user: { id: u.id, name: u.name, username: u.username }, items };
});
const checkPassword = (p) => { if (p.length < 8 || !/\p{L}/u.test(p) || !/\p{Nd}/u.test(p)) throw bad('كلمة السر 8 أحرف على الأقل وتحتوي حروفاً وأرقاماً'); };
const phoneOf = (v) => { const raw = str(v, 24); if (!raw) return ''; const d = digitsOnly(raw); if (d.length < 8 || d.length > 15) throw bad('رقم الهاتف غير صحيح (8-15 رقماً)'); return d; };
route('GET', '/api/registration-status', OPEN, () => ({ open: false }));
route('POST', '/api/register', OPEN, () => { throw new HttpError(403, 'التسجيل مغلق. إنشاء الحسابات متاح من لوحة الإدارة فقط.'); });
route('POST', '/api/users', MANAGER, ({ body }) => {
  const username = str(body.username, 24).toLowerCase().replace(/\s+/g, ''), name = str(body.name, 60) || username;
  const password = String(body.password || ''), confirm = body.confirm == null ? password : String(body.confirm);
  if (!/^[a-z0-9_.]{3,24}$/.test(username)) throw bad('اسم المستخدم: حروف إنجليزية وأرقام (3 على الأقل)');
  checkPassword(password);
  if (password !== confirm) throw bad('تأكيد كلمة السر غير مطابق');
  const phone = phoneOf(body.phone);
  if (core().users.some((u) => u.username === username)) throw new HttpError(409, 'اسم المستخدم مستخدم');
  if (phone && core().users.some((u) => u.phone === phone)) throw new HttpError(409, 'رقم الهاتف مسجل بالفعل');
  const ps = randHex(8);
  const u = { id: ++core().seq.user, username, name, role: 'user', disabled: false, createdAt: Date.now(), ...(phone ? { phone } : {}), ...newCred(password), ps, pk: pushKey(password, ps) };
  if (!SNAP) { u.acct = makeAcct(u, password); publishAcct(u); }
  core().users.push(u); touch(); return { item: publicUser(u) };
});
route('PATCH', '/api/users/:id', MANAGER, ({ params, body }) => {
  const u = userOf(Number(params.id)); if (!u || isPriv(u)) throw new HttpError(404, 'المستخدم غير موجود');
  if (body.name != null) u.name = str(body.name, 60) || u.name;
  if (body.password) { checkPassword(String(body.password)); const ps = randHex(8); Object.assign(u, newCred(String(body.password)), { ps, pk: pushKey(String(body.password), ps), pkx: false }); dropSessions(u); if (!SNAP) { u.acct = makeAcct(u, String(body.password)); u.acctAt = 0; publishAcct(u); } }
  if (body.disabled != null) { u.disabled = !!body.disabled; if (u.disabled) { dropSessions(u); dropAcct(u); } else { u.acctB = ''; } }
  touch(); return { ok: true };
});
route('DELETE', '/api/users/:id', MANAGER, ({ params }) => {
  const u = userOf(Number(params.id)); if (!u || isPriv(u)) throw new HttpError(404, 'المستخدم غير موجود');
  for (const r of numbers()) if (r.u === u.id) releaseRec(r);
  dropAcct(u); core().users = core().users.filter((x) => x.id !== u.id); core().requests = core().requests.filter((r) => r.userId !== u.id);
  for (const d of core().domains) if (Array.isArray(d.access)) d.access = d.access.filter((id) => id !== u.id);
  touch(); return { ok: true };
});

route('POST', '/api/export/users', ADMIN, () => {
  if (!TEMPLATE || SNAP) throw bad('التصدير متاح من ملف index.html الأصلي فقط');
  const c = core();
  const users = c.users.filter((u) => !isPriv(u) && !u.disabled).map((u0) => { userPushKey(u0); userTopic(u0); const { sv, pk, pkx, ...u } = u0; return pkx || !u.ps ? { ...u, pkx: pk } : u; });
  const keep = new Set(users.map((u) => u.id));
  const snap = {
    id: Date.now().toString(36), at: Date.now(),
    db: {
      core: { users, domains: c.domains.map((d) => ({ ...d, access: d.access === '*' ? '*' : (d.access || []).filter((i) => keep.has(i)) })), requests: [], announcements: c.announcements, panels: [],
        settings: { activePanel: null, botOn: false, pollSeconds: 8, pricePerCode: c.settings.pricePerCode, pushOn: !!c.settings.pushOn, pushServer: c.settings.pushServer, pushTopic: c.settings.pushTopic }, seq: { ...c.seq } },
      numData: { seq: db.numData.seq, items: numbers().filter((r) => !r.u || keep.has(r.u)) }, msgData: { items: [] },
    },
  };
  const tag = '<script id="nfs-snapshot" type="application/json">';
  const i = TEMPLATE.indexOf(tag), j = TEMPLATE.indexOf('</script>', i);
  if (i < 0 || j < 0) throw bad('تعذر تجهيز الملف');
  const json = JSON.stringify(snap).replace(/</g, '\\u003c');
  return { html: TEMPLATE.slice(0, i + tag.length) + json + TEMPLATE.slice(j), users: users.length, numbers: snap.db.numData.items.length };
});

/* اللوحات والبوت */
const panelDto = (p) => ({ id: p.id, name: p.name, type: p.type, url: p.url, path: p.path, authHeader: p.authHeader, authScheme: p.authScheme, enabled: p.enabled, keyMask: maskKey(p.key), hasKey: !!p.key, status: bot.panels[p.id] || null });
route('GET', '/api/panels', ADMIN, () => ({ items: core().panels.map(panelDto), settings: core().settings, bot: botStatus() }));
function panelInput(body, p) {
  const url = str(body.url ?? p.url, 300).replace(/\/+$/, '');
  if (!/^https?:\/\/[^\s]+$/i.test(url)) throw bad('رابط اللوحة غير صالح (يبدأ بـ http أو https)');
  p.name = str(body.name ?? p.name, 60) || p.name; p.url = url;
  if (body.key) p.key = str(body.key, 400);
  p.path = str(body.path ?? p.path ?? '', 200); p.authHeader = str(body.authHeader ?? p.authHeader ?? 'Authorization', 60) || 'Authorization';
  p.authScheme = str(body.authScheme ?? p.authScheme ?? '', 20);
  if (body.enabled != null) p.enabled = !!body.enabled;
  if (body.type) p.type = body.type === 'primehub' ? 'primehub' : 'generic';
}
route('POST', '/api/panels', ADMIN, ({ body }) => {
  const p = { id: `p${++core().seq.panel}_${Date.now().toString(36)}`, name: '', url: '', key: '', path: '', authHeader: 'Authorization', authScheme: 'Bearer', enabled: true, type: 'generic' };
  if (!str(body.name)) throw bad('أدخل اسم اللوحة');
  panelInput(body, p); core().panels.push(p); touch(); return { item: panelDto(p) };
});
route('PUT', '/api/panels/:id', ADMIN, ({ params, body }) => {
  const p = core().panels.find((x) => x.id === params.id); if (!p) throw new HttpError(404, 'اللوحة غير موجودة');
  panelInput(body, p); touch(); return { item: panelDto(p) };
});
route('DELETE', '/api/panels/:id', ADMIN, ({ params }) => {
  core().panels = core().panels.filter((x) => x.id !== params.id);
  if (core().settings.activePanel === params.id) core().settings.activePanel = null;
  touch(); return { ok: true };
});
route('POST', '/api/panels/:id/test', ADMIN, async ({ params }) => {
  const p = core().panels.find((x) => x.id === params.id); if (!p) throw new HttpError(404, 'اللوحة غير موجودة');
  let r;
  try { r = await fetchAll(p); } catch (e) { bot.panels[p.id] = { ok: false, error: String(e.message || e).slice(0, 160), ms: e.ms, at: Date.now() }; return { ok: false, error: String(e.message).slice(0, 200), ms: e.ms }; }
  load();
  const added = ingest(p, r.items);
  bot.panels[p.id] = { ok: true, ms: r.ms, count: r.items.length, added, at: Date.now() };
  const keys = new Set(r.items.map((it) => `${p.id}:${it.pid}`));
  const rows = messages().filter((m) => keys.has(m.k)).map((m) => ({ m, r: messageOwner(m) })).sort((a, b) => b.m.t - a.m.t);
  const per = new Map(); let delivered = 0, unowned = 0, codes = 0, pay = 0, earn = 0;
  for (const { m, r: o } of rows) {
    if (m.c) codes++;
    if (!o) { if (m.c) unowned++; continue; }
    if (!m.c) continue;
    delivered++; pay += m.pay || 0;
    const it = codeDto(m, o); earn += it.earn;
    const u = userOf(o.u), e = per.get(o.u) || { id: o.u, name: u?.name || '—', username: u?.username || '', n: 0, earn: 0 };
    e.n++; e.earn += it.earn; per.set(o.u, e);
  }
  await pushPending(true); await pushStates(true);
  return { ok: true, ms: r.ms, count: r.items.length, added, codes, delivered, unowned, pay: +pay.toFixed(3), earn: +earn.toFixed(3),
    users: [...per.values()].map((e) => ({ ...e, earn: +e.earn.toFixed(3) })).sort((a, b) => b.n - a.n),
    items: rows.slice(0, 300).map(({ m, r: o }) => codeDto(m, o)), push: pushStatus() };
});
route('POST', '/api/panels/:id/detect', ADMIN, async ({ params }) => {
  const p = core().panels.find((x) => x.id === params.id); if (!p) throw new HttpError(404, 'اللوحة غير موجودة');
  const found = await detectEndpoint(p);
  if (!found) return { ok: false, error: 'لم يُعثر على مسار رسائل يقبل هذا المفتاح. أدخل المسار من توثيق اللوحة يدوياً.' };
  Object.assign(p, found); touch(); return { ok: true, found };
});
route('POST', '/api/settings', ADMIN, ({ body }) => {
  const s = core().settings;
  if (body.activePanel !== undefined) {
    if (body.activePanel !== 'all' && body.activePanel !== null && !core().panels.some((p) => p.id === body.activePanel)) throw bad('لوحة غير معروفة');
    s.activePanel = body.activePanel;
  }
  if (body.botOn != null) s.botOn = !!body.botOn;
  if (body.pollSeconds != null) s.pollSeconds = clampInt(body.pollSeconds, 3, 120, 8);
  if (body.relayUrl !== undefined) { const u = str(body.relayUrl, 300); if (u && !/^https?:\/\/\S+$/i.test(u)) throw bad('رابط الوسيط غير صالح'); s.relayUrl = u; }
  if (body.publicProxy != null) s.publicProxy = !!body.publicProxy;
  if (body.syncUrl !== undefined) {
    const t = String(body.syncUrl || '').trim(), v = cleanSync(t);
    if (t && !v) throw bad('رابط قاعدة المزامنة يجب أن يكون مثل https://اسم-مشروعك-default-rtdb.firebaseio.com');
    setSyncBase(v); s.syncUrl = v; fbAdmV = undefined; push.backoff = 0; push.error = ''; for (const u of core().users) { u.stH = ''; u.acctB = ''; }
  }
  if (body.pushOn != null) s.pushOn = !!body.pushOn;
  if (body.pushServer !== undefined) { const u = str(body.pushServer, 200).replace(/\/+$/, '') || DEFAULT_PUSH; if (!/^https:\/\/\S+$/i.test(u)) throw bad('رابط خدمة الإشعارات يجب أن يبدأ بـ https'); s.pushServer = u; }
  if (body.relayToken !== undefined) s.relayToken = str(body.relayToken, 200);
  if (body.tgToken !== undefined) { const t = str(body.tgToken, 120); if (t && !/^\d{5,}:[\w-]{20,}$/.test(t)) throw bad('توكن البوت غير صالح'); if (t !== (s.tgToken || '')) { s.tgToken = t; s.tgOffset = 0; tg.bot = ''; tg.ok = null; tg.error = ''; } }
  if (body.tgOn != null) s.tgOn = !!body.tgOn;
  if (body.pricePerCode != null) s.pricePerCode = Math.max(0, Math.min(1000, Number(body.pricePerCode) || 0));
  touch(); return { settings: s };
});
route('POST', '/api/sync/test', ADMIN, async ({ body }) => {
  const t = String(body.url ?? syncBase).trim(), v = cleanSync(t);
  if (!v) throw bad('الصق رابط القاعدة كاملاً، مثال: https://اسم-مشروعك-default-rtdb.firebaseio.com');
  const keep = syncBase; syncBase = v;
  try {
    const k = 'acct/zz-test-' + fbKey(), val = randHex(6), t0 = Date.now();
    await fbReq('PUT', k, val); const back = await fbReq('GET', k); await fbReq('DELETE', k);
    if (back !== val) throw Object.assign(new Error('mismatch'), { status: 0 });
    return { ok: true, ms: Date.now() - t0 };
  } catch (e) { return { ok: false, error: fbErr(e) }; } finally { syncBase = keep; }
});
route('POST', '/api/sync/check', AUTH, async () => {
  const mode = !syncBase ? 'none' : isSb() ? 'supabase' : 'firebase';
  const delivery = { listening: !!push.listening, connected: !!push.connected, ok: push.ok !== false, error: push.error || '', lastAt: push.lastAt || 0, got: push.got || 0, sent: push.sent || 0 };
  if (!syncBase) return { ok: push.ok !== false, mode: 'public', host: 'ntfy.sh', ms: 0, error: push.error || '', delivery };
  const k = 'acct/zz-check-' + fbKey(), val = randHex(8), t0 = Date.now();
  try {
    await fbReq('PUT', k, val); const w = Date.now() - t0;
    const back = await fbReq('GET', k); await fbReq('DELETE', k);
    if (back !== val) return { ok: false, mode, error: 'كُتبت البيانات لكن القراءة لم تطابقها، تحقق من سياسة الجدول nfs_kv.', delivery };
    return { ok: true, mode, ms: Date.now() - t0, writeMs: w, host: syncBase.split('#')[0].replace(/^https:\/\//, ''), delivery };
  } catch (e) {
    let why = '';
    if (mode === 'supabase') { // تمييز: الرابط/المفتاح خطأ، أم الجدول غير موجود
      try { const i = syncBase.indexOf('#'); const r = await fetch(syncBase.slice(0, i) + '/rest/v1/', { headers: { apikey: syncBase.slice(i + 1) } });
        why = r.status === 401 || r.status === 403 ? 'key' : r.ok ? (e.status === 404 ? 'table' : '') : 'url'; } catch { why = 'url'; }
    }
    const msg = why === 'table' ? 'المشروع متصل والمفتاح صحيح، لكن جدول nfs_kv غير موجود. نفّذ كود SQL في Supabase ← SQL Editor ثم أعد الفحص.'
      : why === 'key' ? 'المفتاح مرفوض من Supabase: تأكد أنه المفتاح المنشور (sb_publishable_...) لهذا المشروع.'
      : why === 'url' ? 'تعذر الوصول إلى رابط المشروع، تأكد من Project URL ومن الإنترنت.' : fbErr(e);
    return { ok: false, mode, error: msg, hint: why, status: e.status || 0, delivery };
  }
});
route('POST', '/api/sync/republish', ADMIN, async () => {
  core().settings.fbDone = '';
  if (!syncBase) { for (const u of core().users) { u.stH = ''; u.acctAt = 0; } push.backoff = 0; acctBackoff = 0; await republishAccts(); await pushPending(true); await pushStates(true); return { ok: push.ok !== false, error: push.error || '', push: pushStatus() }; } for (const u of core().users) { u.stH = ''; u.acctB = ''; }
  fbSeed(); push.backoff = 0; acctBackoff = 0;
  await republishAccts(); await pushPending(true); await pushStates(true);
  return { ok: push.ok !== false, error: push.error || '', push: pushStatus() };
});
route('POST', '/api/bot/run', ADMIN, async () => { await runBot(true); return { bot: botStatus() }; });
route('GET', '/api/bot', AUTH, () => ({ bot: botStatus() }));

/* ---------- نقطة الدخول التي تستدعيها الواجهة ---------- */
export async function localApi(path, { method = 'GET', body } = {}) {
  const url = new URL(path, 'http://local');
  const r = routes.find((x) => x.method === method && x.re.test(url.pathname));
  if (!r) throw Object.assign(new Error('مسار غير معروف'), { status: 404 });
  load();
  let user = null;
  if (r.opts.auth) {
    user = currentUser();
    if (!user) throw Object.assign(new Error('غير مسجّل'), { status: 401 });
    if (r.opts.admin && user.role !== 'admin') throw Object.assign(new Error('للمدير الكامل فقط'), { status: 403 });
    if (r.opts.manager && !isPriv(user)) throw Object.assign(new Error('غير مسموح'), { status: 403 });
  }
  try {
    if (user && isPriv(user) && managerChannel) {
      startManagerChannelListener();
      // قراءة أولية عند دخول المدير، ثم مزامنة الدلتا/اللقطة دورياً. قبل عمليات الكتابة نقرأ الأحدث لتقليل تعارض المتصفحات.
      await pullManagerSnapshot(method !== 'GET' && url.pathname !== '/api/manager-sync').catch(() => {});
    }
    return await r.handler({ user, body: body || {}, query: url.searchParams, params: url.pathname.match(r.re).groups || {} });
  } catch (e) {
    if (e.status) throw e;
    console.error('NFSsms', e);
    throw Object.assign(new Error('حدث خطأ داخلي: ' + String(e && e.message || e).slice(0, 120)), { status: 500 });
  }
}

if (typeof window !== 'undefined' && window.__NFS_TEST) window.__nfsLocalApi = localApi; // خطاف الاختبار فقط
