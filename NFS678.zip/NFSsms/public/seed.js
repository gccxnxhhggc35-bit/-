// بيانات البداية للوضع المحلي. حساب المدير: saleh (كلمة السر مجزّأة، غير مخزّنة كنص).
// مفاتيح اللوحات غير مضمّنة هنا عمداً؛ أدخلها من صفحة "اللوحات" بعد الدخول.
export const SEED = {
  "admin": {
    "username": "saleh",
    "name": "saleh",
    "salt": "f8b877d1ef4ef2b0d0b2f50be97d7a7e",
    "hash": "d8da744956cdfe69b86f6d8e943ab088cd3a7626e9ffad0712b555fd461dd182"
  },
  "panels": [
    {
      "id": "prime",
      "name": "Prime Hub",
      "type": "primehub",
      "url": "http://169.58.91.190:5000",
      "path": "/api/messages/cdr",
      "authHeader": "X-API-Token",
      "authScheme": "",
      "enabled": true
    },
    {
      "id": "thirdwave",
      "name": "ThirdWave",
      "type": "generic",
      "url": "https://thirdwave.im",
      "path": "",
      "authHeader": "Authorization",
      "authScheme": "Bearer",
      "enabled": true
    },
    {
      "id": "royal",
      "name": "Royal",
      "type": "generic",
      "url": "http://145.239.69.111:20189",
      "path": "",
      "authHeader": "X-API-Key",
      "authScheme": "",
      "enabled": true
    }
  ],
  "activePanel": "prime"
};
