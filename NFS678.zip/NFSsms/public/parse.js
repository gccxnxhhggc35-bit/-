// أدوات استخراج الكود وتحديد التطبيق وتحليل الأرقام (بدون اعتماديات خارجية)

const AR_DIGITS = '٠١٢٣٤٥٦٧٨٩';
const FA_DIGITS = '۰۱۲۳۴۵۶۷۸۹';

export function toAsciiDigits(s) {
  return String(s ?? '').replace(/[٠-٩۰-۹]/g, (c) => {
    const i = AR_DIGITS.indexOf(c);
    return String(i >= 0 ? i : FA_DIGITS.indexOf(c));
  });
}

export function cleanText(s) {
  return toAsciiDigits(s)
    .replace(/\\[nrt]/g, ' ') // بعض اللوحات ترسل \n كنص حرفي
    .replace(/\\(['"\\/])/g, '$1')
    .replace(/[\u0000-\u001f\u007f\u200e\u200f\u202a-\u202e]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

export function digitsOnly(s) {
  let d = toAsciiDigits(s).replace(/\D/g, '');
  if (d.startsWith('00')) d = d.slice(2);
  return d;
}

export function extractCode(content) {
  const t = cleanText(content);
  if (!t) return null;
  let m = t.match(/(?<!\d)(\d{3})-(\d{3})(?!\d)/); // واتساب: 448-916
  if (m) return m[1] + m[2];
  m = t.match(/(?:code|otp|pin|passcode|verification|confirm\w*|token|رمز|كود|تحقق|التحقق|تأكيد)[^\d]{0,40}(?<!\d)(\d{4,8})(?!\d)/i);
  if (m) return m[1];
  m = t.match(/(?<!\d)(\d{4,8})(?!\d)[^\d]{0,30}(?:is your|is the|هو|بمثابة|رمز|كود|code)/i);
  if (m) return m[1];
  m = t.match(/(?<![\d+])(\d{4,8})(?!\d)/);
  return m ? m[1] : null;
}

export const APPS = {
  wa: { name: 'واتساب', re: /whats\s?app|واتس/i },
  tg: { name: 'تيليجرام', re: /telegram|تيليجرام|تلغرام/i },
  fb: { name: 'فيسبوك', re: /facebook|\bfb\b|meta|فيسبوك|فيس بوك/i },
  ig: { name: 'انستغرام', re: /insta|انستا/i },
  tt: { name: 'تيك توك', re: /tik\s?tok|تيك\s?توك|douyin/i },
  sn: { name: 'سناب شات', re: /snap/i },
  im: { name: 'إيمو', re: /\bimo\b|ايمو|إيمو/i },
  yt: { name: 'يوتيوب', re: /youtube|يوتيوب/i },
  go: { name: 'جوجل', re: /google|gmail|\bg-\d|جوجل/i },
  x: { name: 'إكس (تويتر)', re: /twitter|\bx\.com\b|تويتر/i },
  vb: { name: 'فايبر', re: /viber|فايبر/i },
  ds: { name: 'ديسكورد', re: /discord/i },
  ot: { name: 'أخرى', re: /$^/ },
};

export function detectApp(sender, content) {
  const hay = `${sender ?? ''} ${cleanText(content)}`;
  for (const [k, v] of Object.entries(APPS)) if (k !== 'ot' && v.re.test(hay)) return k;
  return 'ot';
}

export function parseNumbers(text) {
  const valid = new Set();
  let invalid = 0;
  const ok = (d) => d.length >= 7 && d.length <= 15;
  // كل سطر/فاصلة رقم واحد (يُسمح بالمسافات والشرطات داخل الرقم: +963 944 111 222)
  for (const chunk of String(text ?? '').split(/[\r\n,;\t]+/)) {
    const c = toAsciiDigits(chunk).trim();
    if (!c || !/\d/.test(c)) continue;
    const merged = digitsOnly(c.replace(/[\s\-().]/g, ''));
    if (/^[+\d\s\-().]+$/.test(c) && ok(merged)) { valid.add(merged); continue; }
    // عدة أرقام في السطر مفصولة بمسافات
    for (const tok of c.split(/\s+/)) {
      if (!/\d/.test(tok)) continue;
      const d = digitsOnly(tok);
      if (/^[+\d\-().]+$/.test(tok) && ok(d)) valid.add(d);
      else invalid++;
    }
  }
  return { valid: [...valid], invalid };
}

export function parseTime(v) {
  if (v == null || v === '') return Date.now();
  if (typeof v === 'number' || /^\d+(\.\d+)?$/.test(String(v))) {
    const n = Number(v);
    return n < 1e12 ? Math.round(n * 1000) : Math.round(n);
  }
  const t = Date.parse(String(v));
  return Number.isNaN(t) ? Date.now() : t;
}

// استخراج رقم الهاتف من نص رسالة تيليجرام (يفضّل السطر الذي فيه «رقم/Number/To»، ثم الذي يبدأ بـ +).
export function tgNumber(text, code) {
  const t = toAsciiDigits(String(text ?? '')).replace(/\d{4}[-/.]\d{1,2}[-/.]\d{1,2}|\d{1,2}[-/.]\d{1,2}[-/.]\d{2,4}/g, ' ');
  const skip = code ? digitsOnly(String(code)) : '';
  const label = /(number|num\b|phone|mobile|msisdn|\bto\b|recipient|الرقم|رقم|هاتف|جوال|📞|☎|📱)/i, found = [];
  for (const line of t.split(/\r?\n/)) {
    for (const m of line.matchAll(/\+?\d[\d\s\-().]{5,18}\d/g)) {
      const d = digitsOnly(m[0].replace(/[\s\-().]/g, ''));
      if (d.length < 7 || d.length > 15 || d === skip) continue;
      found.push({ d, lab: label.test(line), plus: m[0].startsWith('+') });
    }
  }
  if (!found.length) return null;
  return (found.find((x) => x.lab) || found.find((x) => x.plus) || found[0]).d;
}
