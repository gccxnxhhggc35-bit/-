import './pwa.js';
import { THEMES, getPrefs, setPref } from './prefs.js';
import { APP_KEYS, APP_NAMES, APP_COLORS, sprite, appIcon, panelIcon, ico, ill } from './icons.js';
import { LOCAL, canExport, saveText, setToken, download, $, $$, esc, fmt, phone, tz, api, setUnauth, timeAgo, toast, copyText, openSheet, closeSheet, sheetOpen, sheetBody, confirmBox, initFx, animateMount, donut, bars, empty, skeleton } from './core.js';

const S = { me: null, tab: 'home', token: 0, seen: null, fresh: new Set(), poll: null, codeFilter: 'all', scope: 'all', dom: null, userSearch: '', ua: null };
const isAdmin = () => S.me?.role === 'admin';
const isLimitedAdmin = () => S.me?.role === 'limited_admin';
const isManager = () => isAdmin() || isLimitedAdmin();
const navItems = () => isAdmin() ? NAV_ADMIN : isLimitedAdmin() ? NAV_MANAGER : NAV_USER;
const NAV_ADMIN = [['home', 'الرئيسية'], ['codes', 'الأكواد'], ['chat', 'التواصل'], ['doms', 'النطاقات'], ['users', 'المستخدمون'], ['panels', 'اللوحات'], ['me', 'حسابي']];
const NAV_MANAGER = [['home', 'الرئيسية'], ['codes', 'الترافيك'], ['chat', 'التواصل'], ['doms', 'النطاقات'], ['users', 'المستخدمون'], ['me', 'حسابي']];
const NAV_USER = [['home', 'الرئيسية'], ['codes', 'الأكواد'], ['chat', 'التواصل'], ['doms', 'أرقامي'], ['me', 'حسابي']];
const SHOW_APPS = APP_KEYS.filter((k) => k !== 'ot');

document.body.insertAdjacentHTML('beforeend', sprite());
initFx();
setUnauth(() => { if (S.me) { stopPoll(); setToken(null); S.me = null; showLogin(); toast('انتهت الجلسة، سجّل الدخول من جديد', 'err'); } });

/* ======================= Clerk: تحميل SDK والجلسة ======================= */
let clerkLoadPromise = null;

/* شعار الموقع الحقيقي مع اسم NFSsms (يُستخدم في كل شاشات الدخول) */
const brandLogo = (sub = 'أرقام وأكواد تحقق فورية') => `<div class="brand"><div class="bmark"><i class="bglow"></i><i class="bring"></i><span class="bimg"><img src="icons/icon-192.png" alt="شعار NFSsms" width="96" height="96" decoding="async"><i class="bshine"></i></span></div><div class="btxt"><b class="bname" aria-label="NFSsms">${[...'NFSsms'].map((c, i) => `<span style="--i:${i}">${c}</span>`).join('')}</b><small>${sub}</small></div></div>`;

function hasClerkAuth() {
  return !LOCAL && typeof window.NFS_CLERK_PUBLISHABLE_KEY === 'string' && window.NFS_CLERK_PUBLISHABLE_KEY.startsWith('pk_');
}
async function getClerk() {
  const key = String(window.NFS_CLERK_PUBLISHABLE_KEY || '').trim();
  if (!key.startsWith('pk_')) throw new Error('مفتاح Clerk العام غير مضبوط في config.js');
  if (!clerkLoadPromise) {
    clerkLoadPromise = new Promise((resolve, reject) => {
      let domain;
      try { domain = atob(key.split('_')[2]).replace(/\$$/, ''); }
      catch { reject(new Error('مفتاح Clerk العام غير صالح')); return; }
      if (!domain || !/^[a-z0-9.-]+$/i.test(domain)) { reject(new Error('نطاق Clerk غير صالح')); return; }
      const script = document.createElement('script');
      script.src = `https://${domain}/npm/@clerk/clerk-js@6/dist/clerk.browser.js`;
      script.async = true;
      script.crossOrigin = 'anonymous';
      script.dataset.clerkPublishableKey = key;
      script.onload = async () => {
        try {
          if (!window.Clerk) throw new Error('لم يتم تحميل مكتبة Clerk');
          await window.Clerk.load();
          resolve(window.Clerk);
        } catch (err) { reject(err); }
      };
      script.onerror = () => reject(new Error('تعذر تحميل Clerk. تحقق من اتصال الإنترنت ومفتاح النشر.'));
      document.head.appendChild(script);
    });
  }
  return clerkLoadPromise;
}
function clerkErrorMessage(err) {
  const items = err?.errors;
  if (Array.isArray(items) && items.length) return items.map((x) => x.longMessage || x.message).filter(Boolean).join(' · ');
  return err?.message || 'تعذر تسجيل الدخول. تحقق من البيانات وحاول مجدداً.';
}
async function completeClerkLogin() {
  const clerk = await getClerk();
  const clerkToken = await clerk.session?.getToken();
  if (!clerkToken) throw new Error('لم تنشأ جلسة Clerk صالحة؛ حاول تسجيل الدخول مرة أخرى.');
  const r = await api('/api/clerk/session', { method: 'POST', body: { token: clerkToken } });
  setToken(r.token);
  await enterApp(r.user);
}
function showClerkLogin() {
  S.me = null;
  const orbit = ['wa', 'tg', 'fb', 'ig', 'tt', 'sn'].map((k, i) => `<div class="o" style="--a:${i * 60}deg"><div class="pos"><div class="in">${appIcon(k)}</div></div></div>`).join('');
  $('#app').innerHTML = `<div id="login"><div class="lwrap">
    <div class="lhero"><div class="stage"><i class="glow"></i><i class="ring"></i><i class="ring r2"></i><div class="orbit">${orbit}</div>${ill.hero}</div>
      <div class="tag"><h2>أكواد التحقق في لحظتها</h2><p>تُجلب الرسائل من لوحتك تلقائياً وتصل كل كود لصاحب الرقم مباشرة.</p></div></div>
    <form class="lc glass" id="clerkForm" autocomplete="on">
      ${brandLogo()}
      <h2 id="clerkTitle">أهلاً بعودتك</h2><p class="s" id="clerkDesc">سجّل الدخول بالبريد الإلكتروني وكلمة السر</p>
      <div class="seg" id="clerkModes" style="margin:.6rem 0 1rem"><button type="button" id="clerkSignIn" class="on">دخول</button><button type="button" id="clerkSignUp">إنشاء حساب</button></div>
      <div class="lerr" id="clerkErr">${ico('shield', 'sm')}<span></span></div>
      <div id="clerkCredentials">
        <div class="fld">${ico('mail')}<input id="clerkEmail" class="ltr" type="text" name="identifier" placeholder="البريد الإلكتروني أو اسم المستخدم saleh" autocomplete="username" autocapitalize="none" required></div>
        <div class="fld">${ico('lock')}<input id="clerkPassword" class="ltr" type="password" name="password" placeholder="كلمة السر" autocomplete="current-password" minlength="8" required></div>
      </div>
      <button id="clerkForgot" class="btn s" style="margin:.1rem 0 .55rem" type="button">نسيت كلمة السر؟ أرسل رمز استعادة للبريد</button>
      <div id="clerkVerify" hidden><div class="fld">${ico('shield')}<input id="clerkCode" class="ltr" inputmode="numeric" autocomplete="one-time-code" placeholder="رمز التحقق المرسل إلى بريدك" maxlength="10"></div><p class="mini" id="clerkCodeHint">افتح بريدك الإلكتروني واكتب رمز التحقق الذي أرسله Clerk.</p></div>
      <div id="clerkResetPassword" hidden><div class="fld">${ico('key')}<input id="clerkNewPassword" class="ltr" type="password" autocomplete="new-password" placeholder="كلمة السر الجديدة (8 أحرف على الأقل)" minlength="8"></div></div>
      <button id="clerkSubmit" class="btn" type="submit">دخول ${ico('bolt', 'sm')}</button>
      <div class="signup-panel" id="clerkSignupPanel">
        <div class="signup-copy"><strong>ليس لديك حساب بعد؟</strong><span>أنشئ حسابك بالبريد الإلكتروني وكلمة السر، ثم أكّد بريدك برمز التحقق.</span></div>
        <button id="clerkCreateAccount" class="signup-action" type="button">إنشاء حساب جديد ${ico('userplus', 'sm')}</button>
      </div>
      <button id="clerkBack" class="btn s" style="margin-top:.5rem" type="button" hidden>العودة</button>
      <div class="lnote">${ico('shield', 'sm')}<span>تسجيل آمن وتأكيد البريد عبر رمز إلكتروني</span></div>
      <button id="managerLogin" class="btn s" style="margin-top:.8rem;width:100%" type="button">دخول المشرف المحدود 1Whisper</button>
    </form></div></div>`;

  const state = { mode: 'signin', step: 'credentials', secondFactor: false };
  const title = $('#clerkTitle'), desc = $('#clerkDesc'), modes = $('#clerkModes');
  const credentials = $('#clerkCredentials'), verify = $('#clerkVerify'), submit = $('#clerkSubmit'), back = $('#clerkBack');
  const errBox = $('#clerkErr');
  const setError = (message = '') => {
    errBox.querySelector('span').textContent = message;
    errBox.classList.toggle('on', !!message);
  };
  const draw = () => {
    const checking = state.step !== 'credentials';
    const resetting = state.step === 'reset';
    modes.hidden = checking;
    credentials.hidden = checking;
    verify.hidden = !checking;
    $('#clerkResetPassword').hidden = !resetting;
    $('#clerkForgot').hidden = checking || state.mode !== 'signin';
    back.hidden = !checking;
    $('#clerkSignupPanel').hidden = checking || state.mode !== 'signin';
    $('#clerkEmail').required = !checking;
    $('#clerkPassword').required = !checking;
    $('#clerkCode').required = checking;
    $('#clerkNewPassword').required = resetting;
    $('#clerkCode').value = '';
    $('#clerkSignIn').classList.toggle('on', state.mode === 'signin');
    $('#clerkSignUp').classList.toggle('on', state.mode === 'signup');
    $('#clerkEmail').type = state.mode === 'signup' ? 'email' : 'text';
    $('#clerkEmail').autocomplete = state.mode === 'signup' ? 'email' : 'username';
    $('#clerkEmail').placeholder = state.mode === 'signup' ? 'name@gmail.com' : 'البريد الإلكتروني أو اسم المستخدم saleh';
    $('#clerkPassword').minLength = state.mode === 'signup' ? 8 : 1;
    if (resetting) {
      title.textContent = 'استعادة كلمة السر';
      desc.textContent = 'أدخل رمز البريد واختر كلمة سر جديدة';
      $('#clerkCodeHint').textContent = 'أدخل رمز استعادة كلمة السر الذي أرسله Clerk إلى بريدك.';
      submit.innerHTML = `حفظ كلمة السر ${ico('check', 'sm')}`;
    } else if (checking) {
      title.textContent = 'تحقق من بريدك';
      desc.textContent = state.secondFactor ? 'أدخل رمز الأمان لتأكيد تسجيل الدخول' : 'أرسلنا رمز تحقق إلى بريدك الإلكتروني';
      $('#clerkCodeHint').textContent = 'افتح بريدك الإلكتروني واكتب رمز التحقق الذي أرسله Clerk.';
      submit.innerHTML = `تأكيد الرمز ${ico('check', 'sm')}`;
    } else if (state.mode === 'signup') {
      title.textContent = 'إنشاء حساب جديد';
      desc.textContent = 'أدخل بريدك وكلمة السر، ثم أكّد البريد بالرمز';
      submit.innerHTML = `إنشاء حساب ${ico('userplus', 'sm')}`;
      $('#clerkPassword').autocomplete = 'new-password';
    } else {
      title.textContent = 'أهلاً بعودتك';
      desc.textContent = 'سجّل الدخول بالبريد الإلكتروني وكلمة السر';
      submit.innerHTML = `دخول ${ico('bolt', 'sm')}`;
      $('#clerkPassword').autocomplete = 'current-password';
    }
  };
  $('#clerkSignIn').onclick = () => { state.mode = 'signin'; state.step = 'credentials'; state.secondFactor = false; setError(); draw(); };
  const startSignup = () => { state.mode = 'signup'; state.step = 'credentials'; state.secondFactor = false; setError(); draw(); $('#clerkEmail').focus(); };
  $('#clerkSignUp').onclick = startSignup;
  $('#clerkCreateAccount').onclick = startSignup;
  $('#clerkForgot').onclick = async () => {
    setError();
    const email = $('#clerkEmail').value.trim().toLowerCase();
    if (!email || !email.includes('@')) { setError('أدخل البريد الإلكتروني المسجّل بالحساب لإرسال رمز الاستعادة.'); $('#clerkEmail').focus(); return; }
    const b = $('#clerkForgot'); b.classList.add('l');
    try {
      const clerk = await getClerk();
      await clerk.client.signIn.create({ strategy: 'reset_password_email_code', identifier: email });
      state.step = 'reset'; state.secondFactor = false; draw(); $('#clerkCode').focus();
    } catch (err) { setError(clerkErrorMessage(err)); }
    finally { b.classList.remove('l'); }
  };
  back.onclick = () => { state.step = 'credentials'; state.secondFactor = false; setError(); draw(); };
  $('#clerkForm').onsubmit = async (e) => {
    e.preventDefault();
    const btn = submit;
    setError();
    btn.classList.add('l');
    try {
      if (state.step === 'credentials') {
        const identifier = $('#clerkEmail').value.trim();
        const password = $('#clerkPassword').value;
        // يمكن لحساب المدير المهيّأ والمشرف 1Whisper استخدام اسم مستخدم؛ البريد فقط يُرسل إلى Clerk.
        if (state.mode === 'signin' && !identifier.includes('@')) {
          const r = await api('/api/login', { method: 'POST', body: { username: identifier, password } });
          setToken(r.token);
          await enterApp(r.user);
          return;
        }
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(identifier)) {
          throw new Error('أدخل بريداً إلكترونياً صحيحاً، أو استخدم اسم المستخدم saleh للدخول الإداري.');
        }
        const clerk = await getClerk();
        if (state.mode === 'signup') {
          await clerk.client.signUp.create({ emailAddress: identifier.toLowerCase(), password });
          await clerk.client.signUp.prepareEmailAddressVerification({ strategy: 'email_code' });
          state.step = 'code'; state.secondFactor = false;
          draw();
          $('#clerkCode').focus();
          return;
        }
        const attempt = await clerk.client.signIn.create({ identifier: identifier.toLowerCase(), password });
        if (attempt.status === 'complete') {
          await clerk.setActive({ session: attempt.createdSessionId });
          await completeClerkLogin();
          return;
        }
        if (attempt.status === 'needs_second_factor') {
          const factor = (attempt.supportedSecondFactors || []).find((x) => x.strategy === 'email_code');
          if (!factor) throw new Error('يتطلب الحساب خطوة أمان أخرى غير مفعّلة في هذه الشاشة.');
          await clerk.client.signIn.prepareSecondFactor({ strategy: 'email_code', emailAddressId: factor.emailAddressId });
          state.step = 'code'; state.secondFactor = true;
          draw();
          $('#clerkCode').focus();
          return;
        }
        throw new Error('لم يكتمل تسجيل الدخول. تحقق من إعدادات حساب Clerk.');
      } else if (state.step === 'reset') {
        const clerk = await getClerk();
        const attempt = await clerk.client.signIn.attemptFirstFactor({
          strategy: 'reset_password_email_code', code: $('#clerkCode').value.trim(), password: $('#clerkNewPassword').value,
        });
        if (attempt.status !== 'complete') throw new Error('لم تكتمل استعادة كلمة السر. تحقق من الرمز وكلمة السر الجديدة.');
        await clerk.setActive({ session: attempt.createdSessionId });
        await completeClerkLogin();
        return;
      } else {
        const clerk = await getClerk();
        const code = $('#clerkCode').value.trim();
        const attempt = state.secondFactor
          ? await clerk.client.signIn.attemptSecondFactor({ strategy: 'email_code', code })
          : await clerk.client.signUp.attemptEmailAddressVerification({ code });
        if (attempt.status !== 'complete') throw new Error('لم يكتمل التحقق. تأكد من الرمز والمتطلبات المطلوبة.');
        await clerk.setActive({ session: attempt.createdSessionId });
        await completeClerkLogin();
      }
    } catch (err) {
      setError(clerkErrorMessage(err));
    } finally {
      btn.classList.remove('l');
    }
  };
  $('#managerLogin').onclick = showManagerLogin;
  draw();
  $('#clerkEmail').focus();
}

function showManagerLogin() {
  S.me = null;
  $('#app').innerHTML = `<div id="login"><div class="lwrap"><div class="tag"><h2>دخول المشرف المحدود</h2><p>صلاحيات إدارة المستخدمين والنطاقات وقبول الطلبات فقط.</p></div>
    <form class="lc glass" id="managerForm" autocomplete="on">${brandLogo('دخول المشرفين')}
      <h2>1Whisper</h2><p class="s">أدخل بيانات المشرف المحدود</p><div class="lerr" id="managerErr">${ico('shield', 'sm')}<span></span></div>
      <div class="fld">${ico('user')}<input id="managerUsername" class="ltr" name="username" value="1Whisper" autocomplete="username" autocapitalize="none" required></div>
      <div class="fld">${ico('lock')}<input id="managerPassword" class="ltr" name="password" type="password" placeholder="كلمة السر" autocomplete="current-password" required></div>
      <button id="managerSubmit" class="btn" type="submit">دخول ${ico('bolt', 'sm')}</button>
      <button id="managerBack" class="btn s" type="button" style="margin-top:.65rem;width:100%">العودة إلى تسجيل الدخول بالبريد</button>
      <div class="lnote">${ico('shield', 'sm')}<span>هذه صلاحيات محدودة ولا تشمل إعدادات الخادم أو البوت.</span></div></form></div></div>`;
  $('#managerUsername').focus();
  $('#managerBack').onclick = showLogin;
  $('#managerForm').onsubmit = async (e) => {
    e.preventDefault();
    const b = $('#managerSubmit'), box = $('#managerErr');
    box.classList.remove('on'); b.classList.add('l');
    try {
      const r = await api('/api/login', { method: 'POST', body: { username: $('#managerUsername').value, password: $('#managerPassword').value } });
      setToken(r.token); await enterApp(r.user);
    } catch (err) {
      b.classList.remove('l'); box.querySelector('span').textContent = err.message; box.classList.add('on');
    }
  };
}

/* ======================= تسجيل الدخول ======================= */
function showLogin() {
  if (hasClerkAuth()) return showClerkLogin();
  S.me = null;
  const orbit = ['wa', 'tg', 'fb', 'ig', 'tt', 'sn'].map((k, i) => `<div class="o" style="--a:${i * 60}deg"><div class="pos"><div class="in">${appIcon(k)}</div></div></div>`).join('');
  $('#app').innerHTML = `<div id="login"><div class="lwrap">
    <div class="lhero"><div class="stage"><i class="glow"></i><i class="ring"></i><i class="ring r2"></i><div class="orbit">${orbit}</div>${ill.hero}</div>
      <div class="tag"><h2>أكواد التحقق في لحظتها</h2><p>تُجلب الرسائل من لوحتك تلقائياً وتصل كل كود لصاحب الرقم مباشرة.</p></div></div>
    <form class="lc glass" id="lf" autocomplete="on">
      ${brandLogo()}
      <h2>أهلاً بعودتك</h2><p class="s">سجّل الدخول للمتابعة إلى حسابك</p>
      <div class="lerr" id="lerr">${ico('shield', 'sm')}<span></span></div>
      <div class="fld">${ico('user')}<input id="u" class="ltr" name="username" placeholder="اسم المستخدم" autocomplete="username" autocapitalize="none" required></div>
      <div class="fld">${ico('lock')}<input id="p" class="ltr" name="password" type="password" placeholder="كلمة السر" autocomplete="current-password" required><button type="button" class="eye" data-act="eye" aria-label="إظهار كلمة السر">${ico('eye')}</button></div>
      <button id="lb" class="btn" type="submit">دخول ${ico('bolt', 'sm')}</button>
      <div class="lnote">${ico('shield', 'sm')}<span>اتصال محمي وجلسة آمنة</span></div>
    </form></div></div>`;
  $('#u').focus();
  $('#lf').onsubmit = async (e) => {
    e.preventDefault();
    const b = $('#lb'), box = $('#lerr');
    box.classList.remove('on'); b.classList.add('l');
    try {
      const r = await api('/api/login', { method: 'POST', body: { username: $('#u').value, password: $('#p').value } });
      setToken(r.token);
      await enterApp(r.user);
    } catch (err) {
      b.classList.remove('l');
      box.querySelector('span').textContent = err.message; box.classList.add('on');
      const c = $('#lf'); c.classList.remove('shake'); void c.offsetWidth; c.classList.add('shake');
    }
  };
}

/* ======================= الهيكل العام ======================= */
async function enterApp(me) {
  S.me = me; S.tab = 'home'; S.seen = null; S.fresh.clear(); S.annLatest = null;
  const items = navItems();
  $('#app').innerHTML = `<div id="shell"><main id="main"><div class="page" id="page"></div></main></div>
    <nav id="nav" class="glass" aria-label="التنقل"><div class="brand-side"><b>NFSsms</b></div><div class="w"><i class="bub" style="width:${100 / items.length}%;--i:0"></i>
    ${items.map(([k, l]) => `<button class="nv" data-act="tab" data-t="${k}" aria-label="${l}"><span class="ni">${ico(k)}</span><span class="lb">${l}</span></button>`).join('')}</div>
    <div class="side-foot"><div class="av"><i>${esc((me.name || me.username)[0].toUpperCase())}</i></div><div><b>${esc(me.name)}</b><small>${isAdmin() ? 'مدير النظام' : isLimitedAdmin() ? 'مشرف محدود' : '@' + esc(me.username)}</small></div></div></nav>`;
  setTimeout(() => $('#nav').classList.add('show'), 80);
  await go('home');
  startPoll();
}

function setNav(tab) {
  const items = navItems();
  $$('#nav .nv').forEach((b) => b.classList.toggle('on', b.dataset.t === tab));
  $('#nav .bub')?.style.setProperty('--i', items.findIndex((x) => x[0] === tab));
}

async function go(tab, { quiet = false } = {}) {
  S.tab = tab; setNav(tab);
  const token = ++S.token;
  const main = $('#main');
  if (!quiet) {
    main.scrollTo({ top: 0 });
    main.innerHTML = `<div class="page">${skeleton(1, true)}${skeleton(4)}</div>`;
  }
  let out;
  try { out = await VIEWS[tab](); } catch (e) {
    if (token !== S.token) return;
    main.innerHTML = `<div class="page">${empty(ill.inbox, 'تعذر تحميل الصفحة', e.message)}</div>`; return;
  }
  if (token !== S.token) return;
  const y = main.scrollTop;
  main.innerHTML = `<div class="page ${tab === 'chat' ? 'page-support' : ''} ${quiet ? 'noanim' : ''}" id="page">${out}</div>`;
  if (quiet) main.scrollTo({ top: y });
  animateMount($('#page'), quiet);
}

/* ======================= المشاركات ======================= */
const tools = () => `<div class="tools"><button class="tbtn" data-act="openapi" aria-label="API">${ico('api')}<span>API</span></button><button class="tbtn" data-act="opensettings" aria-label="الإعدادات">${ico('sliders')}<span>الإعدادات</span></button></div>`;
const topbar = (hi, title, right = '') => `<div class="top hero h-${S.tab}"><i class="hb hb1"></i><i class="hb hb2"></i><i class="hb hb3"></i><svg class="hero-wave" viewBox="0 0 400 60" preserveAspectRatio="none" aria-hidden="true"><path d="M0 30Q50 0 100 30T200 30T300 30T400 30V60H0Z"/></svg><span class="hero-ico">${ico(S.tab)}</span><div class="hero-t"><p class="hi">${hi}</p><h1>${title}</h1></div><div class="topr">${right}${tools()}</div></div>`;
const globeSvg = '<svg class="globe" viewBox="0 0 48 48" aria-hidden="true"><circle class="g-o" cx="24" cy="24" r="19"/><ellipse class="g-m" cx="24" cy="24" rx="8" ry="19"/><path class="g-l" d="M5 24h38M8 14h32M8 34h32"/><g class="g-orb"><circle class="g-p" cx="24" cy="2.500" r="2.600"/></g></svg>';
const ringM = (pct) => `<svg class="ringm" viewBox="0 0 60 60" aria-hidden="true"><circle class="rb" cx="30" cy="30" r="25"/><circle class="rf" cx="30" cy="30" r="25" data-d="${(pct * 1.5708).toFixed(1)} 157.08" style="stroke-dasharray:0 157.08"/></svg>`;
const sc = (k, icon, label, value, f = 0) => `<div class="sc glass c${(k % 6) + 1}" style="--k:${k}"><div class="ic">${ico(icon)}</div><b data-count="${value}" data-f="${f}">0</b><small>${label}</small></div>`;
const sec = (t, right = '', icon = '') => `<div class="sec"><h3>${icon ? `<span class="sec-i">${ico(icon, 'sm')}</span>` : ''}${t}</h3>${right}</div>`;
const appsLegend = (list) => list.length
  ? `<div class="legend">${list.slice(0, 6).map((a, i) => `<div style="--k:${i}">${appIcon(a.k, 27)}<span>${esc(APP_NAMES[a.k] || a.k)}</span><b>${fmt(a.n)}</b></div>`).join('')}</div>` : '';
const appsDonut = (list, label = 'كود') => `<div class="donutw">${donut(list.map((a) => ({ v: a.n, color: APP_COLORS[a.k] || '#999' })), 0, label)}${appsLegend(list)}</div>`;
const pushPill = (bot) => {
  const p = bot?.push || {};
  if (!p.on) return `<div class="livepill glass"><i class="led no"></i><span>الاستقبال متوقف</span></div>`;
  if (p.connected) return `<div class="livepill glass"><i class="led ok"></i><span>متصل · تصلك الأكواد فوراً</span></div>`;
  if (p.error) return `<div class="livepill glass err"><i class="led no"></i><span>${esc(p.error)}</span></div>`;
  return `<div class="livepill glass"><i class="led no"></i><span>جارٍ الاتصال لاستقبال الأكواد...</span></div>`;
};
const fmtTime = (t) => new Date(t).toLocaleString('en-GB', { year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }).replace(',', '');
const money = (v) => '$' + fmt(v, v && v < 0.01 ? 3 : 3).replace(/0+$/, '').replace(/\.$/, '');
const botPill = (bot, panelName) => (bot?.push?.listening || (!isManager() && !bot?.on && bot?.push?.on)) ? pushPill(bot) : bot?.on
  ? `<div class="livepill glass"><i class="led ok"></i><span>البوت يعمل${panelName ? ' · ' + esc(panelName) : ''}</span></div>`
  : `<div class="livepill glass"><i class="led no"></i><span>البوت متوقف</span></div>`;

/* ======================= الإعلانات ======================= */
const annSeenGet = () => { try { return Number(localStorage.getItem('nfs_ann_seen') || 0); } catch { return 0; } };
const annSeenSet = (id) => { try { localStorage.setItem('nfs_ann_seen', String(id)); } catch {} };
async function loadAnn() {
  try { const r = await api('/api/announcements'); S.ann = r.items; S.annLatest = r.items[0]?.id || 0; return r.items; } catch { return S.ann || []; }
}
async function checkAnn() {
  try {
    const r = await api('/api/announcements'); const top = r.items[0];
    if (S.annLatest != null && top && top.id > S.annLatest) {
      S.annLatest = top.id; S.ann = r.items;
      toast('إعلان جديد: ' + top.title, 'okk');
      if (S.tab === 'home' && !sheetOpen()) go('home', { quiet: true });
    }
  } catch { /* تجاهل */ }
}
const annCard = (items) => {
  const seen = annSeenGet(), admin = isAdmin(), unread = items.filter((a) => a.id > seen).length;
  const list = items.slice(0, 2).map((a, i) => `<button class="annitem ${a.id > seen ? 'new' : ''}" data-act="openAnn" style="--k:${i}"><b>${esc(a.title)}</b><span>${esc(a.body.slice(0, 110))}${a.body.length > 110 ? '…' : ''}</span><small>${timeAgo(a.t)}</small></button>`).join('');
  return `<div class="card glass ann"><div class="cardh"><h3>${ico('megaphone', 'sm')} الإعلانات ${unread ? `<span class="pill no">${unread} جديد</span>` : ''}</h3><div class="annbtns">${items.length ? '<button class="btn m s" data-act="openAnn">عرض الكل</button>' : ''}${admin ? `<button class="btn m" data-act="newAnn">${ico('plus', 'sm')} إعلان</button>` : ''}</div></div>${list || `<p class="mini">${admin ? 'لم تُرسل إعلانات بعد. اضغط «إعلان» لإرسال أول إعلان لكل المستخدمين.' : 'لا توجد إعلانات حالياً.'}</p>`}</div>`;
};

function renderUserCards(items, query = '') {
  if (!items.length) return empty(ill.users, query ? 'لم يتم العثور على مستخدم بهذا البريد' : 'لا يوجد مستخدمون بعد', query ? 'تأكد من البريد الإلكتروني المسجّل في Clerk.' : 'سيظهر المستخدم هنا بعد إنشاء حسابه وتأكيد بريده في Clerk.');
  const ub = (act, icon, label, d, cls = '') => `<button class="ua ${cls}" data-act="${act}" ${d}>${ico(icon, 'sm')}<span>${label}</span></button>`;
  return `<div class="ugrid">${items.map((u, i) => {
    const d = `data-id="${u.id}"`, off = u.disabled ? 'disabled' : '';
    return `<div class="ucard glass${u.disabled ? ' off' : ''}" style="--k:${i}"><div class="uc-h"><div class="av"><i>${esc((u.name || u.username)[0].toUpperCase())}</i></div>
    <div class="t"><b>${esc(u.name)} ${u.disabled ? '<span class="pill no">معطّل</span>' : '<span class="pill ok">نشط</span>'}</b><small class="ltr">${esc(u.email || '@' + u.username)}</small>${u.email ? `<small class="ltr">@${esc(u.username)}</small>` : ''}${u.phone ? `<small class="ltr">+${esc(u.phone)}</small>` : ''}${u.needsReset ? '<small class="needreset">⚠ أعد تعيين كلمة السر ليعمل من الأجهزة الأخرى</small>' : ''}</div></div>
    <div class="uc-s"><span class="us1">${ico('phone', 'sm')}<b>${fmt(u.numbers)}</b><small>رقم</small></span><span class="us2">${ico('codes', 'sm')}<b>${fmt(u.codes)}</b><small>كود</small></span></div>
    <div class="uc-a">${ub('userAssign', 'plus', 'توزيع', `${d} data-n="${esc(u.name)}" data-email="${esc(u.email || '')}" ${off}`, 'pri')}${ub('userNums', 'phone', 'الأرقام', `${d} data-n="${esc(u.name)}" data-u="${esc(u.username)}"`)}${ub('pwUser', 'key', 'كلمة السر', d)}${ub('toggleUser', u.disabled ? 'play' : 'ban', u.disabled ? 'تفعيل' : 'تعطيل', `${d} data-d="${u.disabled ? 0 : 1}"`)}${ub('delUser', 'trash', 'حذف', `${d} data-n="${esc(u.name)}"`, 'bad')}</div></div>`;
  }).join('')}</div>`;
}

/* ======================= الصفحات ======================= */
const VIEWS = {
  async home() {
    const [st, ann] = await Promise.all([api('/api/stats?tz=' + tz()), loadAnn()]);
    const chart = `<div class="card glass"><div class="cardh"><h3>أكواد آخر 7 أيام</h3><span class="mini">${fmt(st.series.reduce((a, s) => a + s.n, 0))} كود</span></div>${bars(st.series)}</div>`;
    if (!isManager()) {
      const fourth = st.price > 0 ? sc(3, 'wallet', 'أرباحك ($)', st.earnings, 2) : sc(3, 'clock', 'طلبات معلقة', st.pending);
      const byApp = (st.byApp || []).length ? `${sec('أرقامي حسب التطبيق')}<div class="chips">${st.byApp.map((a) => `<span class="chip">${appIcon(a.k, 24)} ${esc(APP_NAMES[a.k] || a.k)} <b>${fmt(a.n)}</b></span>`).join('')}</div>` : '';
      return `${topbar('مرحباً بك', esc(S.me.name), `<div class="bm">${ico('home')}</div>`)}${annCard(ann)}
        <div class="g stats four">${sc(0, 'phone', 'عدد أرقامي', st.numbers)}${sc(1, 'bolt', 'أكواد اليوم', st.codesToday)}${sc(2, 'inbox', 'إجمالي أكوادي', st.codes)}${fourth}</div>
        <div class="cols c21">${chart}<div class="card glass"><div class="cardh"><h3>أكوادي حسب التطبيق</h3></div>${st.apps.length ? appsDonut(st.apps) : empty(ill.inbox, 'لا أكواد بعد', 'ستظهر هنا فور وصول أول كود')}</div></div>${byApp}`;
    }
    const pn = isAdmin() ? (await api('/api/panels')).items : [];
    const active = st.activePanel === 'all' ? 'كل اللوحات' : pn.find((p) => p.id === st.activePanel)?.name;
    const tot = st.assigned + st.free, pct = tot ? Math.round((st.assigned / tot) * 100) : 0;
    const pool = `<div class="card glass poolc"><div class="cardh"><h3>${ico('hash', 'sm')} مخزون الأرقام</h3><span class="mini">${fmt(tot)} رقم</span></div><div class="poolw"><div class="ringw big">${ringM(pct)}<b>${pct}%</b><small>موزّع</small></div><div class="legend"><div><i class="dot" style="background:#ff3b5c"></i><span>موزّعة</span><b>${fmt(st.assigned)}</b></div><div><i class="dot" style="background:#12b5a0"></i><span>متاحة</span><b>${fmt(st.free)}</b></div></div></div></div>`;
    const medal = ['g1', 'g2', 'g3'];
    const top = `<div class="card glass"><div class="cardh"><h3>${ico('crown', 'sm')} أكثر المستخدمين أكواداً</h3></div>${st.top.length ? st.top.map((u, i) => `<div class="trow" style="--k:${i}"><span class="rk ${medal[i] || ''}">${i + 1}</span><div class="t"><b>${esc(u.name)}</b><small class="ltr">@${esc(u.username)}</small></div><span class="pill ok">${fmt(u.n)} كود</span></div>`).join('') : empty(ill.users, 'لا نشاط بعد')}</div>`;
    const panels = `<div class="card glass"><div class="cardh"><h3>${ico('panels', 'sm')} حالة اللوحات</h3></div>${pn.length ? pn.map((p, i) => {
      const s = st.bot.panels[p.id], on = st.activePanel === p.id || st.activePanel === 'all';
      return `<div class="trow" style="--k:${i}">${panelIcon(p, 38)}<div class="t"><b>${esc(p.name)}</b><small>${on ? (s ? (s.ok ? `متصلة · ${s.ms}ms` : esc(s.error || 'خطأ')) : 'بانتظار الجلب') : 'غير مفعّلة'}</small></div><i class="led ${on && s ? (s.ok ? 'ok' : 'no') : ''}"></i></div>`;
    }).join('') : '<p class="mini">تُدار اللوحات من حساب المدير الكامل.</p>'}</div>`;
    const qb = (ic, label, act, extra = '') => `<button class="qa" data-act="${act}" ${extra}><span class="qi">${ico(ic)}</span><b>${label}</b></button>`;
    const quick = `<div class="qgrid">${qb('userplus', 'توزيع أرقام', 'tab', 'data-t="users"')}${qb('globe', 'نطاق جديد', 'addDomain')}${qb('codes', 'الترافيك', 'tab', 'data-t="codes"')}${qb('chat', 'رسائل الدعم', 'tab', 'data-t="chat"')}${isAdmin() ? qb('megaphone', 'إعلان جديد', 'newAnn') : qb('api', 'مفتاح API', 'openapi')}${isAdmin() ? qb('panels', 'اللوحات', 'tab', 'data-t="panels"') : ''}</div>`;
    const kpis = `<div class="g stats six">${sc(0, 'users', 'المستخدمون', st.users)}${sc(1, 'phone', 'كل الأرقام', st.numbers)}${sc(2, 'check', 'أرقام متاحة', st.free)}${sc(3, 'bolt', 'أكواد اليوم', st.codesToday)}${sc(4, 'inbox', 'أكواد موزّعة', st.codes)}${sc(5, 'clock', 'طلبات معلقة', st.pending)}</div>`;
    const act = `<div class="cols c21">${chart}<div class="card glass"><div class="cardh"><h3>الأكواد حسب التطبيق</h3></div>${st.apps.length ? appsDonut(st.apps) : empty(ill.inbox, 'لا أكواد بعد', 'ستظهر عند وصول رسائل لأرقام موزّعة')}</div></div>`;
    const warn = st.unowned ? `<div class="warn" style="margin-top:.9rem">${ico('inbox', 'sm')}<span>${fmt(st.unowned)} رسالة وصلت لأرقام غير موزّعة (لا تظهر لأي مستخدم).</span></div>` : '';
    const head = isAdmin() ? topbar('مرحباً أيها المدير', 'لوحة الإدارة', botPill(st.bot, active)) : topbar('مرحباً بك', 'لوحة المشرف', botPill(st.bot, ''));
    return `${head}${annCard(ann)}${sec('إجراءات سريعة', '', 'bolt')}${quick}${sec('نظرة عامة', '', 'chart')}${kpis}${sec('النشاط', '', 'signal')}${act}${sec('الإدارة', '', 'shield')}<div class="cols c3">${pool}${top}${panels}</div>${warn}`;
  },

  async codes() {
    const admin = isAdmin(), mgr = isManager();
    const r = await api('/api/codes' + (mgr ? '?scope=' + S.scope : ''));
    S.lastCodes = r.items;
    const used = [...new Set(r.items.map((i) => i.a))];
    const pw = !mgr && r.bot?.push?.listening && !r.bot.push.connected && r.bot.push.error ? `<div class="warn">${ico('signal', 'sm')}<span>${esc(r.bot.push.error)}</span></div>` : '';
    const sum = admin ? (() => { const own = r.items.filter((i) => i.u && i.c); const e = own.reduce((a, i) => a + (i.earn || 0), 0), p = own.reduce((a, i) => a + (i.pay || 0), 0); return own.length ? `<div class="chips"><span class="chip">${ico('inbox', 'sm')} ${fmt(own.length)} كود موزّع</span>${e ? `<span class="chip">${ico('wallet', 'sm')} أرباح المستخدمين ${money(e)}</span>` : ''}${p ? `<span class="chip">${ico('chart', 'sm')} ربح اللوحة ${money(p)}</span>` : ''}</div>` : ''; })() : '';
    const head = `${topbar('مباشر', 'الأكواد', botPill(r.bot))}${pw}${sum}
      ${mgr ? `<div class="seg">${[['all', 'الكل'], ['owned', 'موزّعة'], ['unowned', 'غير موزّعة']].map(([k, l]) => `<button data-act="scope" data-v="${k}" class="${S.scope === k ? 'on' : ''}">${l}</button>`).join('')}</div>` : ''}
      <div class="chips"><button class="chip ${S.codeFilter === 'all' ? 'on' : ''}" data-act="cfilter" data-v="all">الكل</button>${used.map((k) => `<button class="chip ${S.codeFilter === k ? 'on' : ''}" data-act="cfilter" data-v="${k}">${appIcon(k, 22)}${APP_NAMES[k] || k}</button>`).join('')}</div>`;
    return `${head}<div id="codelist">${codeList()}</div>`;
  },

  async doms() { return isManager() ? domsAdmin() : domsUser(); },

  async users() {
    const q = String(S.userSearch || '').trim().toLowerCase();
    const clerkMode = hasClerkAuth();
    const { items } = clerkMode && !q ? { items: [] } : await api('/api/users' + (q ? `?email=${encodeURIComponent(q)}` : ''));
    const exp = LOCAL && canExport() && isAdmin() ? `<button class="btn s" data-act="exportUsers" title="ملف HTML يحمل حسابات المستخدمين لإرساله لهم">${ico('download', 'sm')} نسخة للمستخدمين</button>` : '';
    const add = clerkMode ? '' : `<button class="btn m" data-act="addUser">${ico('userplus', 'sm')} مستخدم جديد</button>`;
    const results = clerkMode && !q ? empty(ill.users, 'ابحث عن حساب بالبريد', 'اكتب البريد الإلكتروني الكامل ثم اضغط «بحث» لفتح بطاقة المستخدم وإدارة أرقامه.') : renderUserCards(items, q);
    return `${topbar('إدارة', 'المستخدمون', `<div style="display:flex;gap:.5rem;flex-wrap:wrap">${exp}${add}</div>`)}
      <div class="card glass" style="margin-bottom:.9rem"><label class="lbl" for="userEmail">ابحث عن المستخدم عبر البريد الإلكتروني (Gmail)</label><div style="display:flex;gap:.5rem;align-items:center"><div class="fld" style="flex:1;margin:0">${ico('search')}<input id="userEmail" class="ltr" type="email" placeholder="user@gmail.com" value="${esc(q)}" autocomplete="off"></div><button id="userSearchBtn" class="btn m" data-act="searchUsers">${ico('search', 'sm')} بحث</button></div><small class="mini" style="display:block;margin-top:.5rem">بعد العثور على الحساب يمكنك إدارة أرقامه وتوزيع أرقام متاحة له مباشرة.</small></div>
      <div id="userResults">${results}</div>`;
  },

  async panels() {
    const r = await api('/api/panels');
    const s = r.settings, act = s.activePanel;
    const bs = r.bot;
    const choices = r.items.map((p) => `<button class="pchoice ${act === p.id ? 'on' : ''}" data-act="setActive" data-id="${p.id}">${panelIcon(p, 46)}<div><b>${esc(p.name)}</b><small class="mini">${p.enabled ? '' : 'معطّلة · '}${p.path ? 'المسار محدد' : 'المسار غير محدد'}</small></div><span class="rad"></span></button>`).join('')
      + `<button class="pchoice ${act === 'all' ? 'on' : ''}" data-act="setActive" data-id="all"><span class="app" style="--s:46px;background:var(--grad-cool);display:grid;place-items:center;color:#fff">${ico('panels')}</span><div><b>كل اللوحات</b><small class="mini">جلب من اللوحات المفعّلة معاً</small></div><span class="rad"></span></button>`;
    const cards = r.items.map((p, i) => {
      const st = p.status;
      const state = st ? (st.ok ? `<span class="pill ok"><i class="led ok"></i>متصلة · ${st.ms}ms · ${st.count} رسالة</span>` : `<span class="pill no">${esc(st.error || 'خطأ')}</span>`) : '<span class="pill">لم تُفحص بعد</span>';
      return `<div class="dom pcard glass" style="--k:${i}"><div style="display:flex;align-items:center;gap:.8rem">${panelIcon(p, 50)}<div style="flex:1;min-width:0"><h4>${esc(p.name)}</h4><small class="mini ltr" style="display:block;overflow:hidden;text-overflow:ellipsis">${esc(p.url)}</small></div>${act === p.id || act === 'all' ? '<span class="pill blue">عاملة</span>' : ''}</div>
        <div style="margin:.8rem 0 .6rem">${state}</div>
        <div class="kv"><span>المفتاح</span><span class="ltr">${p.hasKey ? esc(p.keyMask) : 'غير محدد'}</span></div><div class="kv"><span>مسار الرسائل</span><span class="ltr">${esc(p.path || '—')}</span></div>
        <div style="display:flex;gap:.5rem;margin-top:.8rem;flex-wrap:wrap"><button class="btn m cool" data-act="testPanel" data-id="${p.id}">${ico('signal', 'sm')} فحص</button>
        ${p.type === 'generic' ? `<button class="btn m s" data-act="detectPanel" data-id="${p.id}">${ico('search', 'sm')} اكتشاف المسار</button>` : ''}<button class="btn m s" data-act="editPanel" data-id="${p.id}">${ico('edit', 'sm')} تعديل</button></div></div>`;
    }).join('');
    S.panelsData = r.items;
    return `${topbar('الربط', 'اللوحات والبوت', `<button class="btn m" data-act="addPanel">${ico('plus', 'sm')} لوحة</button>`)}
      <div class="card glass"><div style="display:flex;align-items:center;gap:1rem"><div class="bm">${ico('bolt')}</div><div style="flex:1"><b>بوت جلب الأكواد</b><small class="mini" style="display:block">${bs.on ? 'يجلب الرسائل تلقائياً كل ' + s.pollSeconds + ' ثوانٍ' : 'متوقف'}${bs.last ? ' · آخر جلب ' + timeAgo(bs.last) : ''}</small></div>
        <button class="switch ${s.botOn ? 'on' : ''}" data-act="botToggle" aria-label="تشغيل البوت"></button></div>
        <div style="display:flex;gap:.6rem;margin-top:1rem;flex-wrap:wrap;align-items:center"><button class="btn m s" data-act="runNow">${ico('refresh', 'sm')} جلب الآن</button>
        <div class="fld" style="margin:0;flex:1;min-width:11rem"><label>كل (ثانية)</label><input id="poll" type="number" min="3" max="120" value="${s.pollSeconds}" class="ltr"><button class="eye" data-act="savePoll" aria-label="حفظ">${ico('check', 'sm')}</button></div></div></div>
      ${LOCAL ? pushCard(s, bs.push) : ''}
      ${LOCAL && r.items.some((p) => p.status && !p.status.ok && /CORS|ملف التشغيل|HTTPS/.test(p.status.error || '')) ? `<div class="warn">${ico('shield', 'sm')}<span>المتصفح العادي يمنع الاتصال باللوحات. أغلق هذه النافذة وافتح البرنامج بالنقر المزدوج على <b>NFSsms-Start-Windows.bat</b> (أو <b>NFSsms-Start-Mac.command</b> / <b>NFSsms-Start-Linux.sh</b>) الموجود بجانب الملف، ثم اضغط «فحص».</span></div>` : ''}
      ${sec('اللوحة العاملة', '<span class="mini">اختر من أين يجلب البوت الأكواد</span>')}<div class="pgrid">${choices}</div>${sec('كل اللوحات')}<div class="domgrid">${cards}</div>`;
  },

  async me() {
    const me = S.me; let extra = '';
    if (isAdmin()) {
      const st = await api('/api/panels');
      extra = `${sec('إعدادات النظام')}<div class="card glass"><span class="lbl">سعر الكود الواحد ($) - لحساب أرباح المستخدمين (اتركه 0 لإخفاء الأرباح)</span><div class="fld">${ico('wallet')}<input id="price" type="number" step="0.001" min="0" class="ltr" value="${st.settings.pricePerCode}"></div><button class="btn s" data-act="savePrice">حفظ السعر</button></div>`;
      const bs = await api('/api/bot').catch(() => null), tgs = bs?.bot?.tg || {};
      const tgLine = tgs.on ? (tgs.ok === false ? `<div class="warn">${ico('shield', 'sm')}<span>${esc(tgs.error || 'تعذر القراءة')}</span></div>` : `<span class="lbl">${tgs.ok ? 'متصل' : 'جارٍ الاتصال...'} ${esc(tgs.bot || '')} • وصلت ${tgs.got || 0} رسالة${tgs.skipped ? ` • ${tgs.skipped} رسالة بلا رقم تم تخطيها` : ''}</span>`) : '';
      extra += `${sec('بوت تيليجرام')}<div class="card glass"><span class="lbl">اجعل البوت يقرأ الأكواد من مجموعة/قناة تصلها رسائل اللوحة: ١) أنشئ بوتاً من @BotFather ٢) أضفه للمجموعة (أو كمشرف في القناة) وعطّل Privacy Mode (‎/setprivacy ← Disable) ٣) الصق التوكن هنا. استخدم بوتاً مخصصاً لهذا الموقع فقط، ويجب أن تحتوي كل رسالة على رقم الهاتف كاملاً.</span><div class="fld">${ico('key')}<input id="tgtok" class="ltr" type="password" placeholder="توكن البوت 123456:ABC..." autocomplete="off" value="${esc(st.settings.tgToken || '')}"></div>${tgLine}<div style="display:flex;gap:.6rem"><button class="btn s" data-act="saveTg" data-on="1">حفظ وتفعيل</button>${st.settings.tgOn ? '<button class="btn s" data-act="saveTg" data-on="0">إيقاف</button>' : ''}</div></div>`;
      if (LOCAL) extra += `${sec('الجلب بدون خادم')}<div class="card glass"><span class="lbl">افتح البرنامج دائماً بالنقر المزدوج على ملف التشغيل بجانب index.html: <b>NFSsms-Start-Windows.bat</b> (ويندوز) أو <b>NFSsms-Start-Mac.command</b> (ماك) أو <b>NFSsms-Start-Linux.sh</b>. يفتح نافذة كروم/إيدج خاصة تتصل باللوحات مباشرة، بدون أي خادم أو وسيط. اترك النافذة مفتوحة ليستمر الجلب.</span></div>`;
      if (LOCAL) extra += `<details class="card glass"><summary class="lbl" style="cursor:pointer">اختياري: وسيط اتصال خاص بك</summary><span class="lbl">إن أردت فتح البرنامج من متصفح عادي أو استضافة HTTPS: انشر الوسيط (مجلد relay) ثم ضع رابطه ومفتاحه هنا.</span><div class="fld">${ico('inbox')}<input id="rurl" class="ltr" placeholder="https://xxxx.vercel.app/api/relay" value="${esc(st.settings.relayUrl || '')}"></div><div class="fld">${ico('lock')}<input id="rtok" class="ltr" type="password" placeholder="مفتاح الوسيط (RELAY_TOKEN)" value="${esc(st.settings.relayToken || '')}"></div><button class="btn s" data-act="saveRelay">حفظ الوسيط</button></details>`;
    }
    const passwordSection = me.authProvider === 'clerk'
      ? `${sec('كلمة السر')}<div class="card glass"><p class="mini">تُدار كلمة سر هذا الحساب بأمان عبر Clerk. لاستعادتها، استخدم خيار استعادة كلمة السر في شاشة الدخول إلى Clerk.</p></div>`
      : `${sec('تغيير كلمة السر')}<div class="card glass"><div class="fld">${ico('lock')}<input id="pw0" type="password" class="ltr" placeholder="كلمة السر الحالية" autocomplete="current-password"></div><div class="fld">${ico('key')}<input id="pw1" type="password" class="ltr" placeholder="كلمة السر الجديدة (8+ حروف وأرقام)" autocomplete="new-password"></div><button class="btn" data-act="chgPw">حفظ</button></div>`;
    extra = `${sec('فحص API والمزامنة')}<div class="card glass"><span class="lbl">يفحص القناة العامة ويؤكد أن الأرقام والأكواد تصل إلى المتصفحات والأجهزة الأخرى.</span><div id="syncchk" class="tres"></div><button class="btn s" data-act="syncCheck">${ico('refresh', 'sm')} فحص الـAPI</button></div>` + extra;
    return `${topbar('الحساب', 'حسابي')}
      <div class="pc glass"><div class="av big"><i>${esc((me.name || me.username)[0].toUpperCase())}</i></div><div><h2>${esc(me.name)}</h2><p>${esc(me.email || (isAdmin() ? 'صلاحيات كاملة' : '@' + esc(me.username)))}</p></div></div>
      <div class="cols c2"><div>${passwordSection}</div>
      <div>${extra}</div></div>
      <button class="btn s" style="margin-top:1.4rem" data-act="logout">${ico('logout', 'sm')} تسجيل الخروج</button>`;
  },
};

const SB_SQL = 'create table if not exists nfs_kv (k text primary key, v text not null);\nalter table nfs_kv enable row level security;\ncreate policy "nfs_all" on nfs_kv for all to anon using (true) with check (true);';
const SB_DEFAULT_KEY = () => String(window.NFS_SUPABASE_KEY || '');
const syncVal = () => { const u = val('syncurl').trim().replace(/#.*$/, ''), k = val('synckey').trim() || (/\.supabase\.co\/*$/i.test(u) ? SB_DEFAULT_KEY() : ''); return k ? u + '#' + k : u; };
const SYNC_RULES = '{\n  "rules": {\n    "nfs": {\n      ".write": true,\n      "acct": { "$a": { ".read": true } },\n      "u": { "$r": { ".read": true } },\n      "inbox": { ".read": true },\n      "inboxv": { ".read": true }\n    }\n  }\n}';
function pushCard(s, p = {}) {
  const durable = p.mode === 'durable';
  const state = !s.pushOn ? 'متوقف: الأكواد تظهر على هذا الجهاز فقط' : p.ok === false ? esc(p.error) : p.at ? `يعمل · آخر إرسال ${timeAgo(p.at)} · ${fmt(p.sent)} كود منذ فتح البرنامج` : 'يعمل · يُرسل كل كود لصاحب الرقم لحظة وصوله';
  const link = durable ? `${location.origin !== 'null' ? location.origin + location.pathname : ''}#nfssync=${encodeURIComponent(p.syncUrl)}` : '';
  const sync = `<div class="syncbox ok"><div class="syncbox-h"><i class="led ok"></i><b>مزامنة علنية بلا قاعدة بيانات</b></div><p class="mini">الحسابات والأرقام والنطاقات والأكواد تُنشر مشفّرة على القناة العامة، فتظهر في متصفح المستخدم على أي جهاز دون أي قاعدة بيانات أو إعداد. أبقِ هذا المتصفح مفتوحاً ليجلب الأكواد الجديدة ويوصلها فوراً.</p><div class="btnrow"><button class="btn s ghost" data-act="syncRepub">إعادة نشر كل البيانات الآن</button></div></div>`;
  return `<div class="card glass">${sync}<div style="display:flex;align-items:center;gap:1rem;margin-top:1rem"><div class="bm">${ico('users')}</div><div style="flex:1"><b>إيصال فوري لأجهزة المستخدمين</b><small class="mini" style="display:block">${state}</small></div>
    <button class="switch ${s.pushOn ? 'on' : ''}" data-act="pushToggle" aria-label="الإيصال الفوري"></button></div>
    <p class="mini" style="margin-top:.7rem">كل كود يُشفَّر بمفتاح صاحبه ويصل لحسابه على أي جهاز أو هاتف خلال ثوانٍ، بدون خادم خاص بك. مفاتيح اللوحات لا تغادر هذا الجهاز.</p>
    ${durable ? '' : `<details style="margin-top:.5rem"><summary class="mini" style="cursor:pointer">إعداد متقدم: خدمة الإشعارات المؤقتة</summary><div class="fld" style="margin-top:.6rem">${ico('link')}<input id="pushsrv" class="ltr" value="${esc(s.pushServer || 'https://ntfy.sh')}"><button class="eye" data-act="savePushSrv" aria-label="حفظ">${ico('check', 'sm')}</button></div></details>`}</div>`;
}

/* ======================= الأكواد ======================= */
function codeRow(it, i) {
  const fresh = S.fresh.has(it.id);
  const meta = [APP_NAMES[it.a] || 'أخرى', isManager() ? (it.un ? `<b class="who">${esc(it.un)}</b>` : 'غير موزّع') : '', it.p ? `<bdi>${esc(it.p)}</bdi>` : ''].filter(Boolean).join(' · ');
  const tags = [`<span class="pill">${ico('clock', 'sm')}<bdi class="ltr">${fmtTime(it.t)}</bdi> · ${timeAgo(it.t)}</span>`, it.earn ? `<span class="pill ok">${ico('wallet', 'sm')} ربح ${money(it.earn)}</span>` : '', isAdmin() && it.pay ? `<span class="pill blue">اللوحة ${money(it.pay)}</span>` : ''].filter(Boolean).join('');
  return `<div class="row glass hoverable coderow ${fresh ? 'fresh' : ''}" style="--k:${Math.min(i, 12)}">${appIcon(it.a, 48)}<div class="t"><b class="ltr num copyable" data-act="copy" data-v="${it.n}" title="اضغط لنسخ الرقم">${phone(it.n)}</b><small>${meta}</small>${it.x ? `<p class="sms" dir="auto">${esc(it.x)}</p>` : ''}<div class="tags">${tags}</div></div>
    ${it.c ? `<button class="codebtn" data-act="copy" data-v="${it.c}" aria-label="نسخ الكود"><span>${it.c}</span>${ico('copy', 'sm')}</button>` : `<span class="pill">بدون كود</span>`}</div>`;
}
const codeRowAdmin = (it, i) => codeRow(it, i);
function codeList() {
  const list = (S.lastCodes || []).filter((x) => S.codeFilter === 'all' || x.a === S.codeFilter);
  if (!list.length) return empty(ill.inbox, 'لا توجد أكواد بعد', isManager() ? 'تظهر الأكواد عند وصول رسائل للأرقام من اللوحة العاملة' : 'سيصلك الكود هنا فور وصوله لأحد أرقامك');
  return `<div class="rowgrid two">${list.map(codeRow).join('')}</div>`;
}

/* ======================= النطاقات ======================= */
async function domsAdmin() {
  const [{ items }, rq, { items: users }] = await Promise.all([api('/api/domains'), api('/api/requests'), api('/api/users')]);
  S.users = users;
  const pending = rq.items.filter((r) => r.status === 'pending');
  const reqHtml = pending.length ? `${sec(`طلبات المستخدمين <span class="pill wait">${pending.length}</span>`, '', 'clock')}<div class="rowgrid two">${pending.map((r, i) => `<div class="row glass reqrow" style="--k:${i};flex-wrap:wrap">${appIcon(r.app, 46)}<div class="t"><b>${esc(r.un)} · ${APP_NAMES[r.app]}</b><small class="ltr">${esc(r.dn)}</small>${r.note ? `<small>${esc(r.note)}</small>` : ''}<small>${timeAgo(r.createdAt)}</small></div>
    <div class="fld" style="width:5.5rem;margin:0;padding:0 .7rem"><input id="rq${r.id}" type="number" min="1" value="${r.count}" class="ltr"></div><button class="btn m" data-act="decide" data-id="${r.id}" data-ok="1">قبول</button><button class="btn m s" data-act="decide" data-id="${r.id}" data-ok="0">رفض</button></div>`).join('')}</div>` : '';
  S.domains = items;
  const cards = items.map((d, i) => {
    const a = d.total ? (d.assigned / d.total) * 100 : 0;
    return `<div class="dom dcard glass lift" style="--k:${i}"><div class="dc-h">${globeSvg}<div class="dc-n"><h4 class="ltr" style="direction:ltr">${esc(d.name)}</h4><small class="mini">${d.access === '*' ? 'متاح لكل المستخدمين' : (d.access.length + ' مستخدم محدد')}</small></div><div class="stack">${d.apps.slice(0, 5).map((k) => appIcon(k, 32)).join('')}</div></div>
      <div class="dc-b"><div class="ringw">${ringM(a)}<b>${Math.round(a)}%</b></div><div class="dc-s"><div><i class="dt a"></i><span>موزّعة</span><b data-count="${d.assigned}">0</b></div><div><i class="dt f"></i><span>متاحة</span><b data-count="${d.free}">0</b></div><div><i class="dt t"></i><span>الكل</span><b data-count="${d.total}">0</b></div></div></div>
      <button class="btn m wide" data-act="openDom" data-id="${d.id}">${ico('sliders', 'sm')} إدارة الأرقام</button></div>`;
  }).join('');
  const T = items.reduce((o, d) => ({ n: o.n + d.total, f: o.f + d.free }), { n: 0, f: 0 });
  const dsum = `<div class="dsum"><div><b data-count="${items.length}">0</b><small>نطاق</small></div><div><b data-count="${T.n}">0</b><small>رقم</small></div><div><b data-count="${T.f}">0</b><small>متاح</small></div><div class="${pending.length ? 'hot' : ''}"><b data-count="${pending.length}">0</b><small>طلب معلق</small></div></div>`;
  return `${topbar('الأرقام', 'النطاقات', `<button class="btn m" data-act="addDomain">${ico('plus', 'sm')} نطاق</button>`)}${dsum}${reqHtml}
    ${sec('كل النطاقات', `<span class="mini">${items.length} نطاق</span>`, 'globe')}${items.length ? `<div class="domgrid">${cards}</div>` : empty(ill.globe, 'لا توجد نطاقات بعد', 'أضف نطاقاً ثم ارفع ملف الأرقام وابدأ التوزيع')}`;
}

async function domsUser() {
  const [{ items }, mine, rq] = await Promise.all([api('/api/domains'), api('/api/my/numbers'), api('/api/requests')]);
  S.domains = items; S.mine = mine.items;
  const MN = (S.mn ||= { open: new Set(), avail: false });
  const pend = new Set(rq.items.filter((r) => r.status === 'pending').map((r) => r.domainId + ':' + r.app));
  const cards = items.map((d, i) => `<div class="dom dcard glass" style="--k:${i}"><div class="dc-h">${globeSvg}<div class="dc-n"><h4 class="ltr" style="direction:ltr">${esc(d.name)}</h4><small class="mini">${d.free ? 'أرقام متاحة للطلب' : 'لا أرقام متاحة حالياً'}</small></div></div><div class="tiles">${d.apps.map((a) => {
    const n = d.mine[a] || 0, q = pend.has(d.id + ':' + a);
    return `<div class="tile">${appIcon(a, 46)}<b>${APP_NAMES[a]}</b>${n ? `<small style="color:var(--green)">${n} رقم</small>` : ''}${q ? '<small>قيد الانتظار</small>' : d.free ? `<button data-act="askNums" data-id="${d.id}" data-app="${a}">${n ? 'طلب المزيد' : 'طلب أرقام'}</button>` : '<small>غير متاح حالياً</small>'}</div>`;
  }).join('')}</div></div>`).join('');
  // الأرقام مجمّعة حسب النطاق، مخفية افتراضياً
  const groups = new Map();
  for (const n of mine.items) {
    const k = n.d || 0; let g = groups.get(k);
    if (!g) groups.set(k, (g = { id: k, name: n.dn || 'أخرى', items: [], apps: {} }));
    g.items.push(n); g.apps[n.a] = (g.apps[n.a] || 0) + 1;
  }
  const gl = [...groups.values()];
  const allOpen = gl.length > 0 && gl.every((g) => MN.open.has(g.id));
  const numRow = (n, i) => `<div class="row glass hoverable" style="--k:${Math.min(i, 12)}">${appIcon(n.a, 46)}<div class="t"><b class="ltr num copyable" data-act="copy" data-v="${n.n}" title="اضغط لنسخ الرقم">${phone(n.n)}</b><small>${APP_NAMES[n.a] || ''}</small></div>
    ${n.last ? `<button class="codebtn" data-act="copy" data-v="${n.last.c}"><span>${n.last.c}</span>${ico('copy', 'sm')}</button>` : `<span class="pill">بانتظار كود</span>`}</div>`;
  const gcards = gl.map((g, i) => {
    const open = MN.open.has(g.id);
    return `<div class="dom dcard glass${open ? ' opened' : ''}" style="--k:${Math.min(i, 12)}"><div class="dc-h">${globeSvg}<div class="dc-n"><h4 class="ltr" style="direction:ltr">${esc(g.name)}</h4><small class="mini">${fmt(g.items.length)} رقم</small></div><span class="dcount" data-count="${g.items.length}">0</span></div>
      <div class="chips" style="margin-top:.6rem">${Object.entries(g.apps).map(([a, c]) => `<span class="chip">${appIcon(a, 22)} ${esc(APP_NAMES[a] || a)} <b>${fmt(c)}</b></span>`).join('')}</div>
      <div style="display:flex;gap:.5rem;margin-top:.8rem;flex-wrap:wrap"><button class="btn m s" data-act="mnToggle" data-id="${g.id}">${ico(open ? 'eyeoff' : 'eye', 'sm')} ${open ? 'إخفاء الأرقام' : 'عرض الأرقام'}</button><button class="btn m s" data-act="mnDl" data-id="${g.id}">${ico('download', 'sm')} تحميل txt</button></div>
      ${open ? `<div class="rowgrid" style="margin-top:.8rem">${g.items.map(numRow).join('')}</div>` : ''}</div>`;
  }).join('');
  const tools = gl.length ? `<div style="display:flex;gap:.5rem;flex-wrap:wrap;margin-bottom:.9rem"><button class="btn m" data-act="mnDl" data-id="all">${ico('download', 'sm')} تحميل الأرقام txt</button><button class="btn m s" data-act="mnToggleAll">${ico(allOpen ? 'eyeoff' : 'eye', 'sm')} ${allOpen ? 'إخفاء الكل' : 'عرض الكل'}</button></div>` : '';
  const nums = gl.length ? `${tools}<div class="domgrid">${gcards}</div>` : empty(ill.phone, 'لا أرقام لديك بعد', 'اضغط «النطاقات المتاحة وطلبها» أدناه لطلب أرقام');
  const avail = `<button class="btn m ${MN.avail ? 's' : ''}" data-act="mnAvail" style="margin-bottom:.9rem">${ico('doms', 'sm')} ${MN.avail ? 'إخفاء النطاقات المتاحة' : 'عرض النطاقات المتاحة وطلبها'}${items.length ? ` (${items.length})` : ''}</button>`;
  const availBody = MN.avail ? (items.length ? `<div class="domgrid">${cards}</div>` : empty(ill.globe, 'لا توجد نطاقات متاحة لك', 'سيضيفها المدير قريباً')) : '';
  return `${topbar('حسابي', 'أرقامي', `<div class="bm">${ico('doms')}</div>`)}${sec('أرقامي', `<span class="mini">${fmt(mine.items.length)} رقم${gl.length > 1 ? ` · ${gl.length} نطاقات` : ''}</span>`)}${nums}
    ${sec('النطاقات المتاحة')}${avail}${availBody}`;
}

/* تنزيل أرقام المستخدم كملف نصي: رقم في كل سطر */
function downloadMyNumbers(domIds) {
  const set = new Set(domIds.map(Number));
  const list = (S.mine || []).filter((n) => set.has(n.d || 0));
  if (!list.length) return toast('لا توجد أرقام في الاختيار', 'err');
  const names = [...new Set(list.map((n) => n.dn || 'numbers'))];
  const fname = (names.length === 1 ? names[0] : `numbers-${names.length}-domains`).replace(/[^\w.\u0600-\u06ff-]+/g, '_') + '.txt';
  saveText(list.map((n) => n.n).join('\r\n') + '\r\n', fname, 'text/plain');
  toast(`تم تنزيل ${fmt(list.length)} رقم`, 'okk');
}

/* ======================= نافذة إدارة النطاق ======================= */
const toAscii = (s) => String(s).replace(/[٠-٩]/g, (c) => '٠١٢٣٤٥٦٧٨٩'.indexOf(c)).replace(/[۰-۹]/g, (c) => '۰۱۲۳۴۵۶۷۸۹'.indexOf(c));
function parseNums(text) {
  const valid = new Set(); let invalid = 0;
  const ok = (d) => d.length >= 7 && d.length <= 15;
  const dig = (x) => { let d = x.replace(/\D/g, ''); if (d.startsWith('00')) d = d.slice(2); return d; };
  for (const chunk of toAscii(text).split(/[\r\n,;\t]+/)) {
    const c = chunk.trim(); if (!c || !/\d/.test(c)) continue;
    const merged = dig(c.replace(/[\s\-().]/g, ''));
    if (/^[+\d\s\-().]+$/.test(c) && ok(merged)) { valid.add(merged); continue; }
    for (const tok of c.split(/\s+/)) { if (!/\d/.test(tok)) continue; const d = dig(tok); if (/^[+\d\-().]+$/.test(tok) && ok(d)) valid.add(d); else invalid++; }
  }
  return { valid: valid.size, invalid };
}
const appChips = (selected, name = 'apps') => `<div class="chips" id="${name}">${SHOW_APPS.map((k) => `<button type="button" class="chip ${selected.includes(k) ? 'on' : ''}" data-k="${k}" data-act="chipToggle">${appIcon(k, 22)}${APP_NAMES[k]}</button>`).join('')}</div>`;

function openDomain(id) {
  const d = S.domains.find((x) => x.id === +id);
  S.dom = { d, tab: 'add', nums: { items: [], total: 0 }, filter: 'all', q: '', sel: new Set() };
  renderDomSheet();
}
function renderDomSheet() {
  const D = S.dom, d = D.d;
  const tabs = [['add', 'إضافة أرقام'], ['give', 'توزيع'], ['list', 'الأرقام'], ['set', 'إعدادات']];
  openSheet(`<div class="hd"><div><h3 class="ltr" style="direction:ltr">${esc(d.name)}</h3><small class="mini" id="dstat">متاحة ${fmt(d.free)} · موزّعة ${fmt(d.assigned)} · الكل ${fmt(d.total)}</small></div><button class="iconbtn" data-act="closeSheet" aria-label="إغلاق">${ico('close', 'sm')}</button></div>
    <div class="seg" id="domtabs">${tabs.map(([k, l]) => `<button data-act="domTab" data-v="${k}" class="${D.tab === k ? 'on' : ''}">${l}</button>`).join('')}</div><div id="dbody"></div>`, { wide: true });
  domPane();
}
function domPane() {
  const D = S.dom, d = D.d, b = $('#dbody');
  if (D.tab === 'add') {
    b.innerHTML = `<label class="drop" id="drop"><div class="ic">${ico('upload')}</div><b>اسحب ملف الأرقام هنا أو اضغط للاختيار</b><small class="mini">ملف نصي (.txt أو .csv) - رقم في كل سطر</small><input type="file" id="nf" accept=".txt,.csv,text/plain,text/csv"></label>
      <div class="fld t">${ico('file')}<textarea id="ntext" rows="6" class="ltr" placeholder="أو الصق الأرقام هنا:&#10;+4790697243&#10;+963944111222"></textarea></div>
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:.8rem"><span class="pill ok" id="ncount">0 رقم صالح</span><span class="mini" id="ninv"></span></div>
      <button class="btn" data-act="doImport" id="impb">${ico('upload', 'sm')} رفع الأرقام إلى النطاق</button><div id="impres"></div>`;
    const ta = $('#ntext'), upd = () => { const r = parseNums(ta.value); $('#ncount').textContent = `${fmt(r.valid)} رقم صالح`; $('#ninv').textContent = r.invalid ? `${r.invalid} سطر غير صالح` : ''; };
    ta.oninput = upd;
    const read = (f) => { if (!f) return; if (f.size > 6e6) return toast('الملف كبير (الحد 6MB)', 'err'); const rd = new FileReader(); rd.onload = () => { ta.value = rd.result; upd(); toast(`تم قراءة الملف: ${f.name}`, 'okk'); }; rd.readAsText(f); };
    $('#nf').onchange = (e) => read(e.target.files[0]);
    const dz = $('#drop');
    ['dragenter', 'dragover'].forEach((ev) => dz.addEventListener(ev, (e) => { e.preventDefault(); dz.classList.add('over'); }));
    ['dragleave', 'drop'].forEach((ev) => dz.addEventListener(ev, (e) => { e.preventDefault(); dz.classList.remove('over'); }));
    dz.addEventListener('drop', (e) => read(e.dataTransfer.files[0]));
  } else if (D.tab === 'give') {
    const users = S.users || [];
    b.innerHTML = users.length ? `<div class="warn">${ico('inbox', 'sm')}<span>المتاح للتوزيع الآن: <b>${fmt(d.free)}</b> رقم</span></div>
      <span class="lbl">المستخدم</span><div class="fld">${ico('user')}<select id="gu">${users.map((u) => `<option value="${u.id}">${esc(u.name)} (@${esc(u.username)})</option>`).join('')}</select></div>
      <span class="lbl">التطبيق</span><div class="chips" id="gapp">${d.apps.map((k, i) => `<button type="button" class="chip ${i === 0 ? 'on' : ''}" data-k="${k}" data-act="chipOne">${appIcon(k, 22)}${APP_NAMES[k]}</button>`).join('')}</div>
      <span class="lbl">العدد</span><div class="fld">${ico('hash')}<input id="gc" type="number" min="1" value="10" class="ltr"></div>
      <div class="chips">${[10, 50, 100, 500].map((n) => `<button class="chip" data-act="qty" data-v="${n}">${n}</button>`).join('')}<button class="chip" data-act="qty" data-v="${d.free}">الكل (${fmt(d.free)})</button></div>
      <button class="btn" data-act="doGive">${ico('check', 'sm')} توزيع الأرقام</button>` : empty(ill.users, 'أنشئ مستخدماً أولاً', 'من تبويب المستخدمين');
  } else if (D.tab === 'list') {
    b.innerHTML = `<div class="seg">${[['all', 'الكل'], ['free', 'متاحة'], ['assigned', 'موزّعة']].map(([k, l]) => `<button data-act="nfilter" data-v="${k}" class="${D.filter === k ? 'on' : ''}">${l}</button>`).join('')}</div>
      <div class="fld">${ico('search')}<input id="nq" class="ltr" placeholder="بحث برقم" value="${esc(D.q)}"></div>
      <div id="nlist"></div>`;
    let t; $('#nq').oninput = (e) => { clearTimeout(t); t = setTimeout(() => { D.q = e.target.value; loadNums(true); }, 300); };
    loadNums(true);
  } else {
    const acc = d.access === '*';
    b.innerHTML = `<span class="lbl">التطبيقات المفعّلة</span>${appChips(d.apps)}
      <span class="lbl">من يرى هذا النطاق</span><div class="seg"><button data-act="accMode" data-v="all" class="${acc ? 'on' : ''}">كل المستخدمين</button><button data-act="accMode" data-v="some" class="${acc ? '' : 'on'}">مستخدمون محددون</button></div>
      <div id="accl" ${acc ? 'hidden' : ''}><div class="chips">${(S.users || []).map((u) => `<button type="button" class="chip ${!acc && d.access.includes(u.id) ? 'on' : ''}" data-act="chipToggle" data-u="${u.id}">${esc(u.name)}</button>`).join('') || '<span class="mini">لا يوجد مستخدمون</span>'}</div></div>
      <button class="btn" data-act="saveDom">${ico('check', 'sm')} حفظ الإعدادات</button>
      <div style="display:flex;gap:.6rem;margin-top:.7rem">${isAdmin() ? `<button class="btn s" data-act="exportDom" data-id="${d.id}" data-n="${esc(d.name)}">${ico('download', 'sm')} تصدير الأرقام CSV</button>` : ''}<button class="btn danger" data-act="delDom">${ico('trash', 'sm')} حذف النطاق</button></div>`;
  }
}
async function loadNums(reset) {
  const D = S.dom, N = D.nums, box = $('#nlist'); if (!box) return;
  if (reset) { N.items = []; N.total = 0; D.sel.clear(); box.innerHTML = skeleton(3); }
  const r = await api(`/api/domains/${D.d.id}/numbers?filter=${D.filter}&q=${encodeURIComponent(D.q)}&offset=${N.items.length}&limit=100`).catch((e) => { toast(e.message, 'err'); return null; });
  if (!r || !$('#nlist')) return;
  N.items.push(...r.items); N.total = r.total;
  drawNums();
}
function drawNums() {
  const D = S.dom, N = D.nums, box = $('#nlist'); if (!box) return;
  if (!N.items.length) { box.innerHTML = empty(ill.phone, 'لا توجد أرقام', 'ارفع ملف الأرقام من تبويب "إضافة أرقام"'); return; }
  const canReplaceOrDelete = LOCAL || isAdmin();
  box.innerHTML = `<div style="display:flex;gap:.5rem;align-items:center;margin-bottom:.7rem;flex-wrap:wrap"><span class="mini" style="flex:1">${fmt(N.total)} رقم · محدد ${D.sel.size}</span>
    <button class="btn m s" data-act="selAll">${N.total && D.sel.size >= N.total ? 'إلغاء تحديد الكل' : 'تحديد الكل'}</button><button class="btn m s" data-act="relNums" ${D.sel.size ? '' : 'disabled'}>إلغاء التوزيع</button>${canReplaceOrDelete ? `<button class="btn m s" data-act="renewNums" ${D.sel.size ? '' : 'disabled'}>تجديد المحدد</button><button class="btn m danger" data-act="delNums" ${D.sel.size ? '' : 'disabled'}>حذف</button>` : ''}</div>
    ${N.items.map((n) => `<div class="row glass" style="margin-bottom:.4rem;padding:.55rem .8rem;animation:none"><button class="chip ${D.sel.has(n.id) ? 'on' : ''}" style="padding:.3rem .5rem" data-act="nsel" data-id="${n.id}">${ico('check', 'sm')}</button><div class="t"><b class="ltr num">${phone(n.n)}</b></div>${n.u ? `${appIcon(n.a, 30)}<span class="pill blue">${esc(n.un)}</span>` : '<span class="pill ok">متاح</span>'}</div>`).join('')}
    ${N.items.length < N.total ? `<button class="btn s" style="margin-top:.6rem" data-act="moreNums">عرض المزيد</button>` : ''}`;
}
async function refreshDomains() {
  const { items } = await api('/api/domains'); S.domains = items;
  if (S.dom) { const d = S.dom.d = items.find((x) => x.id === S.dom.d.id) || S.dom.d; const el = $('#dstat'); if (el) el.textContent = `متاحة ${fmt(d.free)} · موزّعة ${fmt(d.assigned)} · الكل ${fmt(d.total)}`; }
  if (S.tab === 'doms') go('doms', { quiet: true });
}

/* ======================= أرقام مستخدم (المدير) ======================= */
const unList = () => (S.un.dom === 'all' ? S.un.items : S.un.items.filter((n) => String(n.d || 0) === String(S.un.dom)));
async function unLoad() {
  const U = S.un, r = await api(`/api/users/${U.id}/numbers`).catch((e) => { toast(e.message, 'err'); return null; });
  if (!r || S.un !== U || !$('#unbody')) return;
  U.items = r.items; U.sel = new Set([...U.sel].filter((id) => r.items.some((n) => n.id === id)));
  if (U.dom !== 'all' && !r.items.some((n) => String(n.d || 0) === String(U.dom))) U.dom = 'all';
  unDraw();
}
function unDraw() {
  const U = S.un, box = $('#unbody'); if (!box) return;
  const st = $('#unstat'); if (st) st.textContent = `@${U.username} · ${fmt(U.items.length)} رقم`;
  if (!U.items.length) { box.innerHTML = empty(ill.phone, 'لا أرقام لدى هذا المستخدم', 'كل أرقامه عادت للمخزون العام'); return; }
  const doms = new Map();
  for (const n of U.items) { const k = n.d || 0; const c = doms.get(k) || { name: n.dn || 'أخرى', n: 0 }; c.n++; doms.set(k, c); }
  const list = unList(), allSel = list.length > 0 && list.every((n) => U.sel.has(n.id));
  box.innerHTML = `${doms.size > 1 ? `<div class="chips" style="margin-bottom:.7rem"><button type="button" class="chip ${U.dom === 'all' ? 'on' : ''}" data-act="unDom" data-v="all">الكل <b>${fmt(U.items.length)}</b></button>${[...doms].map(([k, c]) => `<button type="button" class="chip ${String(U.dom) === String(k) ? 'on' : ''}" data-act="unDom" data-v="${k}"><bdi dir="ltr">${esc(c.name)}</bdi> <b>${fmt(c.n)}</b></button>`).join('')}</div>` : ''}
    <div style="display:flex;gap:.5rem;align-items:center;margin-bottom:.7rem;flex-wrap:wrap"><span class="mini" style="flex:1">${fmt(list.length)} رقم · محدد ${fmt(U.sel.size)}</span>
      <button class="btn m s" data-act="unSelAll">${allSel ? 'إلغاء التحديد' : `تحديد الكل (${fmt(list.length)})`}</button>
      <button class="btn m s" data-act="unRelease" ${U.sel.size ? '' : 'disabled'}>إرجاع للمخزون العام</button>
      <button class="btn m danger" data-act="unDelete" ${U.sel.size ? '' : 'disabled'}>${ico('trash', 'sm')} حذف</button></div>
    ${list.slice(0, U.lim).map((n) => `<div class="row glass" style="margin-bottom:.4rem;padding:.55rem .8rem;animation:none"><button class="chip ${U.sel.has(n.id) ? 'on' : ''}" style="padding:.3rem .5rem" data-act="unSel" data-id="${n.id}" aria-label="تحديد">${ico('check', 'sm')}</button><div class="t"><b class="ltr num">${phone(n.n)}</b><small><bdi dir="ltr">${esc(n.dn)}</bdi></small></div>${appIcon(n.a, 30)}</div>`).join('')}
    ${list.length > U.lim ? `<button class="btn s" style="margin-top:.6rem" data-act="unMore">عرض المزيد</button>` : ''}`;
}

/* ======================= الإجراءات ======================= */
const busy = async (b, fn) => { b?.classList.add('l'); try { return await fn(); } catch (e) { toast(e.message, 'err'); } finally { b?.classList.remove('l'); } };
const val = (id) => $('#' + id)?.value ?? '';
const picked = (id) => $$(`#${id} .chip.on`).map((c) => c.dataset.k);

const ACT = {
  tab: (b) => go(b.dataset.t),
  eye: (b) => { const i = $('#p'); const sh = i.type === 'password'; i.type = sh ? 'text' : 'password'; b.innerHTML = ico(sh ? 'eyeoff' : 'eye'); },
  closeSheet: () => closeSheet(),
  async logout() {
    await api('/api/logout', { method: 'POST' }).catch(() => {});
    if (hasClerkAuth()) { try { const clerk = await getClerk(); await clerk.signOut(); } catch {} }
    setToken(null); stopPoll(); showLogin();
  },
  async searchUsers(b) {
    await busy(b, async () => {
      S.userSearch = String(val('userEmail') || '').trim().toLowerCase();
      const host = $('#userResults');
      if (hasClerkAuth() && !S.userSearch) {
        if (host) host.innerHTML = empty(ill.users, 'ابحث عن حساب بالبريد', 'اكتب البريد الإلكتروني الكامل ثم اضغط «بحث».');
        return;
      }
      const { items } = await api('/api/users' + (S.userSearch ? `?email=${encodeURIComponent(S.userSearch)}` : ''));
      if (host) host.innerHTML = renderUserCards(items, S.userSearch);
    });
  },
  async userAssign(b) {
    await busy(b, async () => {
      const { items } = await api('/api/domains');
      const domains = items.filter((d) => Array.isArray(d.apps) && d.apps.length && Number(d.free) > 0);
      if (!domains.length) { toast('لا توجد أرقام متاحة للتوزيع حالياً. أضف أرقاماً إلى أحد النطاقات أولاً.', 'err'); return; }
      S.ua = { id: +b.dataset.id, name: b.dataset.n || 'المستخدم', email: b.dataset.email || '', domains };
      const d = domains[0];
      openSheet(`<div class="hd"><div><h3>توزيع أرقام للمستخدم</h3><small class="mini">${esc(S.ua.name)} · ${esc(S.ua.email)}</small></div><button class="iconbtn" data-act="closeSheet" aria-label="إغلاق">${ico('close', 'sm')}</button></div>
        <span class="lbl">النطاق</span><div class="fld">${ico('doms')}<select id="uaDomain">${domains.map((x) => `<option value="${x.id}">${esc(x.name)} · متاح ${fmt(x.free)}</option>`).join('')}</select></div>
        <div class="warn" style="margin:.5rem 0">${ico('inbox', 'sm')}<span>الأرقام المتاحة في هذا النطاق: <b id="uaStock">${fmt(d.free)}</b></span></div>
        <span class="lbl">التطبيق</span><div class="fld">${ico('apps')}<select id="uaApp">${d.apps.map((k) => `<option value="${k}">${esc(APP_NAMES[k] || k)}</option>`).join('')}</select></div>
        <span class="lbl">عدد الأرقام</span><div class="fld">${ico('hash')}<input id="uaCount" type="number" min="1" max="${d.free}" value="${Math.min(10, d.free)}" class="ltr" required></div>
        <button class="btn" data-act="confirmUserAssign">${ico('check', 'sm')} توزيع الآن دون طلب من المستخدم</button>`);
      $('#uaDomain').onchange = () => {
        const chosen = S.ua.domains.find((x) => x.id === +val('uaDomain'));
        if (!chosen) return;
        $('#uaStock').textContent = fmt(chosen.free);
        $('#uaApp').innerHTML = chosen.apps.map((k) => `<option value="${k}">${esc(APP_NAMES[k] || k)}</option>`).join('');
        const count = $('#uaCount'); count.max = chosen.free;
        if (+count.value > chosen.free) count.value = Math.min(10, chosen.free);
      };
    });
  },
  async confirmUserAssign(b) {
    const d = S.ua?.domains.find((x) => x.id === +val('uaDomain'));
    if (!d) return toast('اختر نطاقاً صالحاً', 'err');
    await busy(b, async () => {
      const r = await api(`/api/domains/${d.id}/numbers/assign`, { method: 'POST', body: { userId: S.ua.id, app: val('uaApp'), count: +val('uaCount') } });
      closeSheet();
      toast(`تم توزيع ${fmt(r.assigned)} رقم إلى ${S.ua.name}`, 'okk');
      S.ua = null;
      go('users', { quiet: true });
    });
  },
  async exportUsers(b) { await busy(b, async () => { const r = await api('/api/export/users', { method: 'POST' }); saveText(r.html, 'NFSsms-users.html'); toast(`تم تنزيل النسخة (${r.users} مستخدم) · أرسلها لهم، وتصلهم الأكواد فوراً ما دام برنامجك مفتوحاً`, 'okk'); }); },
  async exportDom(b) { try { await download(`/api/domains/${b.dataset.id}/export`, `${b.dataset.n || 'numbers'}.csv`); } catch (e) { toast(e.message, 'err'); } },
  async copy(b) {
    await copyText(b.dataset.v);
    const old = b.innerHTML; b.classList.add('done'); if (b.classList.contains('codebtn')) b.innerHTML = `<span>تم النسخ</span>${ico('check', 'sm')}`;
    toast('تم النسخ', 'okk'); setTimeout(() => { b.classList.remove('done'); if (b.classList.contains('codebtn')) b.innerHTML = old; }, 1400);
  },
  scope: (b) => { S.scope = b.dataset.v; go('codes', { quiet: true }); },
  cfilter: (b) => { S.codeFilter = b.dataset.v; $$('[data-act=cfilter]').forEach((x) => x.classList.toggle('on', x === b)); $('#codelist').innerHTML = codeList(); },
  chipToggle: (b) => b.classList.toggle('on'),
  chipOne: (b) => { $$('.chip', b.parentElement).forEach((c) => c.classList.toggle('on', c === b)); },
  qty: (b) => { $('#gc').value = b.dataset.v; },

  /* النطاقات */
  addDomain() {
    api('/api/users').then(({ items }) => { S.users = items; });
    openSheet(`<div class="hd"><h3>نطاق جديد</h3><button class="iconbtn" data-act="closeSheet">${ico('close', 'sm')}</button></div>
      <div class="fld">${ico('doms')}<input id="dn" class="ltr" placeholder="example.com" autocomplete="off"></div><span class="lbl">التطبيقات المدعومة</span>${appChips([])}
      <button class="btn" data-act="saveNewDomain">${ico('plus', 'sm')} إضافة النطاق</button>`);
  },
  async saveNewDomain(b) {
    await busy(b, async () => { await api('/api/domains', { method: 'POST', body: { name: val('dn'), apps: picked('apps'), access: '*' } }); closeSheet(); toast('تمت إضافة النطاق', 'okk'); go('doms', { quiet: true }); });
  },
  openDom: (b) => openDomain(b.dataset.id),
  domTab: (b) => { S.dom.tab = b.dataset.v; $$('#domtabs button').forEach((x) => x.classList.toggle('on', x === b)); domPane(); },
  async doImport(b) {
    await busy(b, async () => {
      const r = await api(`/api/domains/${S.dom.d.id}/numbers/import`, { method: 'POST', body: { text: val('ntext') } });
      $('#impres').innerHTML = `<div class="result"><div class="g1" style="--k:0"><b data-count="${r.added}">0</b><small>أُضيفت</small></div><div class="g2" style="--k:1"><b data-count="${r.duplicates}">0</b><small>مكرّرة</small></div><div class="g3" style="--k:2"><b data-count="${r.invalid}">0</b><small>غير صالحة</small></div></div>`;
      animateMount($('#impres')); toast(r.added ? `تمت إضافة ${fmt(r.added)} رقم` : 'لم تُضف أرقام جديدة', r.added ? 'okk' : 'err');
      if (r.added) { $('#ntext').value = ''; $('#ncount').textContent = '0 رقم صالح'; $('#ninv').textContent = ''; refreshDomains(); }
    });
  },
  async doGive(b) {
    await busy(b, async () => {
      const app = picked('gapp')[0];
      const r = await api(`/api/domains/${S.dom.d.id}/numbers/assign`, { method: 'POST', body: { userId: +val('gu'), app, count: +val('gc') } });
      toast(`تم توزيع ${fmt(r.assigned)} رقم`, 'okk', app); await refreshDomains(); S.dom.tab = 'give'; renderDomSheet();
    });
  },
  nfilter: (b) => { S.dom.filter = b.dataset.v; domPane(); },
  nsel: (b) => { const id = +b.dataset.id, s = S.dom.sel; s.has(id) ? s.delete(id) : s.add(id); drawNums(); },
  async selAll() {
    const D = S.dom, N = D.nums;
    if (N.total && D.sel.size >= N.total) { D.sel.clear(); drawNums(); return; }
    await busy(null, async () => {
      let offset = 0, total = N.total, rounds = 0;
      do {
        const r = await api(`/api/domains/${D.d.id}/numbers?filter=${D.filter}&q=${encodeURIComponent(D.q)}&offset=${offset}&limit=200`);
        total = r.total; r.items.forEach((n) => D.sel.add(n.id)); offset += r.items.length; rounds++;
        if (!r.items.length || rounds > 5000) break;
      } while (offset < total);
      drawNums(); toast(`تم تحديد ${fmt(D.sel.size)} رقم من النتائج الحالية`, 'okk');
    });
  },
  moreNums: () => loadNums(false),
  renewNums() {
    const D = S.dom; if (!D.sel.size) return toast('حدد الأرقام التي تريد استبدالها أولاً', 'err');
    openSheet(`<div class="hd"><div><h3>تجديد الأرقام المحددة</h3><small class="mini">${fmt(D.sel.size)} رقم قديم سيتم استبداله</small></div><button class="iconbtn" data-act="closeSheet" aria-label="إغلاق">${ico('close', 'sm')}</button></div>
      <div class="warn">${ico('alert', 'sm')}<span>سيتم حذف الأرقام المحددة نهائياً، بما فيها الموزّعة، ثم إضافة الأرقام الجديدة كمتاحة. أدخل القائمة الجديدة أدناه. الأرقام الموجودة مسبقاً خارج الاختيار ستُتجاهل، وإذا لم توجد أرقام جديدة صالحة فلن يُحذف شيء.</span></div>
      <div class="fld t"><textarea id="renewtext" rows="8" class="ltr" placeholder="الصق الأرقام الجديدة، رقم في كل سطر"></textarea></div>
      <button class="btn" data-act="doRenew">${ico('refresh', 'sm')} استبدال المحدد بالجديد</button>`);
  },
  async doRenew(b) {
    const D = S.dom, ids = [...D.sel], text = val('renewtext');
    if (!ids.length) return toast('حدد الأرقام القديمة أولاً', 'err');
    if (!parseNums(text).valid) return toast('أدخل أرقاماً جديدة صالحة', 'err');
    if (!(await confirmBox('تأكيد تجديد الأرقام', `سيُحذف ${fmt(ids.length)} رقم قديم ويُضاف ما أمكن من الأرقام الجديدة كمتاحة. لا يمكن التراجع.`, 'تجديد'))) return;
    await busy(b, async () => {
      const r = await api(`/api/domains/${D.d.id}/numbers/replace`, { method: 'POST', body: { ids, text } });
      toast(`تم حذف ${fmt(r.replaced)} قديم وإضافة ${fmt(r.added)} جديد${r.duplicates ? ` · تكرار ${fmt(r.duplicates)}` : ''}${r.unassigned ? ` · سحب التوزيع عن ${fmt(r.unassigned)}` : ''}`, 'okk');
      const id = D.d.id; closeSheet();
      const { items } = await api('/api/domains'); S.domains = items; const d = items.find((x) => x.id === id) || D.d;
      S.dom = { d, tab: 'list', nums: { items: [], total: 0 }, filter: 'all', q: '', sel: new Set() }; renderDomSheet();
    });
  },
  async relNums() { const ids = [...S.dom.sel]; await busy(null, async () => { const r = await api('/api/numbers/release', { method: 'POST', body: { ids } }); toast(`أُلغي توزيع ${r.released} رقم`, 'okk'); await refreshDomains(); loadNums(true); }); },
  async delNums() {
    const ids = [...S.dom.sel];
    if (!(await confirmBox('حذف الأرقام', `سيتم حذف ${ids.length} رقم نهائياً، وستفقد الحسابات التي تستخدمها هذه الأرقام.`, 'حذف'))) return;
    await busy(null, async () => { const r = await api('/api/numbers/delete', { method: 'POST', body: { ids } }); toast(`حُذف ${r.deleted} رقم`, 'okk'); S.dom.sel.clear(); await refreshDomains(); loadNums(true); });
  },
  accMode: (b) => { $$('.sheet .seg button[data-act=accMode]').forEach((x) => x.classList.toggle('on', x === b)); $('#accl').hidden = b.dataset.v === 'all'; },
  async saveDom(b) {
    const all = $('[data-act=accMode][data-v=all]').classList.contains('on');
    const access = all ? '*' : $$('#accl .chip.on').map((c) => +c.dataset.u);
    await busy(b, async () => { await api(`/api/domains/${S.dom.d.id}`, { method: 'PATCH', body: { apps: picked('apps'), access } }); toast('تم حفظ الإعدادات', 'okk'); await refreshDomains(); renderDomSheet(); });
  },
  async delDom() {
    const d = S.dom.d;
    if (!(await confirmBox('حذف النطاق', `سيُحذف النطاق ${d.name} وكل أرقامه (${fmt(d.total)}).`, 'حذف نهائي'))) return;
    await busy(null, async () => { await api(`/api/domains/${d.id}`, { method: 'DELETE' }); closeSheet(); toast('تم حذف النطاق', 'okk'); go('doms', { quiet: true }); });
  },
  async decide(b) {
    const id = b.dataset.id, ok = b.dataset.ok === '1';
    await busy(b, async () => { await api(`/api/requests/${id}/decide`, { method: 'POST', body: { accept: ok, count: +val('rq' + id) } }); toast(ok ? 'تم القبول وتوزيع الأرقام' : 'تم الرفض', ok ? 'okk' : ''); go('doms', { quiet: true }); });
  },
  askNums(b) {
    const d = S.domains.find((x) => x.id === +b.dataset.id), app = b.dataset.app;
    openSheet(`<div class="hd"><div style="display:flex;gap:.8rem;align-items:center">${appIcon(app, 46)}<div><h3>طلب أرقام ${APP_NAMES[app]}</h3><small class="mini ltr">${esc(d.name)}</small></div></div><button class="iconbtn" data-act="closeSheet">${ico('close', 'sm')}</button></div>
      <span class="lbl">العدد المطلوب</span><div class="fld">${ico('hash')}<input id="rc" type="number" min="1" value="10" class="ltr"></div><div class="fld t">${ico('edit')}<textarea id="rm" rows="3" placeholder="ملاحظة للمدير (اختياري)"></textarea></div>
      <button class="btn" data-act="sendReq" data-id="${d.id}" data-app="${app}">إرسال الطلب</button>`);
  },
  async sendReq(b) { await busy(b, async () => { await api('/api/requests', { method: 'POST', body: { domainId: +b.dataset.id, app: b.dataset.app, count: +val('rc'), note: val('rm') } }); closeSheet(); toast('تم إرسال الطلب للمدير', 'okk'); go('doms', { quiet: true }); }); },

  /* أرقامي (المستخدم) */
  mnToggle(b) { const o = (S.mn ||= { open: new Set(), avail: false }).open, id = +b.dataset.id; o.has(id) ? o.delete(id) : o.add(id); go('doms', { quiet: true }); },
  mnToggleAll() {
    const MN = (S.mn ||= { open: new Set(), avail: false }), ids = [...new Set((S.mine || []).map((n) => n.d || 0))];
    const all = ids.length && ids.every((id) => MN.open.has(id));
    MN.open = all ? new Set() : new Set(ids); go('doms', { quiet: true });
  },
  mnAvail() { const MN = (S.mn ||= { open: new Set(), avail: false }); MN.avail = !MN.avail; go('doms', { quiet: true }); },
  mnDl(b) {
    const cnt = new Map();
    for (const n of S.mine || []) { const k = n.d || 0; const c = cnt.get(k) || { name: n.dn || 'أخرى', n: 0 }; c.n++; cnt.set(k, c); }
    const id = b.dataset.id;
    if (id !== 'all') return downloadMyNumbers([+id]);
    if (cnt.size <= 1) return downloadMyNumbers([...cnt.keys()]);
    openSheet(`<div class="hd"><div><h3>تحميل الأرقام txt</h3><small class="mini">اختر النطاق أو أكثر، أو الكل</small></div><button class="iconbtn" data-act="closeSheet" aria-label="إغلاق">${ico('close', 'sm')}</button></div>
      <div class="chips" id="mnpick"><button type="button" class="chip on" data-act="mnPickAll">الكل (${fmt((S.mine || []).length)})</button>${[...cnt].map(([k, c]) => `<button type="button" class="chip on" data-act="mnPick" data-id="${k}"><bdi dir="ltr">${esc(c.name)}</bdi> <b>${fmt(c.n)}</b></button>`).join('')}</div>
      <button class="btn" data-act="mnDoDl" style="margin-top:1rem">${ico('download', 'sm')} تحميل</button>`);
  },
  mnPickAll(b) { const on = !b.classList.contains('on'); $$('#mnpick .chip').forEach((c) => c.classList.toggle('on', on)); },
  mnPick(b) { b.classList.toggle('on'); const ch = $$('#mnpick .chip[data-id]'); $('#mnpick [data-act=mnPickAll]').classList.toggle('on', ch.every((c) => c.classList.contains('on'))); },
  mnDoDl() { const ids = $$('#mnpick .chip[data-id].on').map((c) => +c.dataset.id); if (!ids.length) return toast('اختر نطاقاً واحداً على الأقل', 'err'); downloadMyNumbers(ids); closeSheet(); },

  /* أرقام المستخدم (المدير): حذف أو إرجاع للمخزون العام */
  async userNums(b) {
    const id = +b.dataset.id;
    S.un = { id, name: b.dataset.n, username: b.dataset.u, items: [], sel: new Set(), dom: 'all', lim: 150 };
    openSheet(`<div class="hd"><div><h3>أرقام ${esc(b.dataset.n)}</h3><small class="mini" id="unstat"></small></div><button class="iconbtn" data-act="closeSheet" aria-label="إغلاق">${ico('close', 'sm')}</button></div><div id="unbody">${skeleton(3)}</div>`, { wide: true });
    await unLoad();
  },
  unDom(b) { S.un.dom = b.dataset.v; S.un.lim = 150; unDraw(); },
  unSel(b) { const id = +b.dataset.id, s = S.un.sel; s.has(id) ? s.delete(id) : s.add(id); unDraw(); },
  unSelAll() { const u = S.un, list = unList(); const all = list.every((n) => u.sel.has(n.id)); list.forEach((n) => (all ? u.sel.delete(n.id) : u.sel.add(n.id))); unDraw(); },
  unMore() { S.un.lim += 150; unDraw(); },
  async unRelease() {
    const ids = [...S.un.sel]; if (!ids.length) return;
    if (!(await confirmBox('إرجاع للمخزون العام', `سيُسحب ${fmt(ids.length)} رقم من ${S.un.name} ويعود متاحاً للتوزيع.`, 'إرجاع'))) return;
    await busy(null, async () => { const r = await api('/api/numbers/release', { method: 'POST', body: { ids } }); toast(`أُرجع ${fmt(r.released)} رقم للمخزون العام`, 'okk'); await unLoad(); go('users', { quiet: true }); });
  },
  async unDelete() {
    const ids = [...S.un.sel]; if (!ids.length) return;
    if (!(await confirmBox('حذف الأرقام', `سيتم حذف ${fmt(ids.length)} رقم نهائياً من النظام.`, 'حذف'))) return;
    await busy(null, async () => { const r = await api('/api/numbers/delete', { method: 'POST', body: { ids } }); toast(`حُذف ${fmt(r.deleted)} رقم`, 'okk'); await unLoad(); go('users', { quiet: true }); });
  },

  /* المستخدمون */
  addUser() {
    openSheet(`<div class="hd"><h3>مستخدم جديد</h3><button class="iconbtn" data-act="closeSheet">${ico('close', 'sm')}</button></div>
      <p class="mini" style="margin-bottom:.8rem">التسجيل مغلق للعامة؛ الحسابات تُنشأ من هنا فقط.</p>
      <div class="fld">${ico('user')}<input id="nn" placeholder="الاسم" autocomplete="off"></div><div class="fld">${ico('hash')}<input id="nu" class="ltr" placeholder="اسم المستخدم (a-z 0-9)" autocomplete="off" autocapitalize="none"></div><div class="fld">${ico('phone')}<input id="nph" class="ltr" inputmode="tel" placeholder="رقم الهاتف (اختياري)" autocomplete="off"></div><div class="fld">${ico('lock')}<input id="np" class="ltr" placeholder="كلمة السر (8+ حروف وأرقام)" autocomplete="off"><button type="button" class="eye" data-act="genPw" aria-label="توليد كلمة سر" title="توليد كلمة سر">${ico('refresh')}</button></div><div class="fld">${ico('lock')}<input id="np2" class="ltr" placeholder="تأكيد كلمة السر" autocomplete="off"></div>
      <button class="btn" data-act="makeUser">${ico('userplus', 'sm')} إنشاء الحساب</button>`);
  },
  genPw() {
    const L = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ', D = '23456789';
    const pick = (set, n) => [...crypto.getRandomValues(new Uint32Array(n))].map((x) => set[x % set.length]);
    const pw = [...pick(L, 6), ...pick(D, 3), ...pick(L + D, 1)].sort(() => Math.random() - 0.5).join('');
    $('#np').value = pw; $('#np2').value = pw; $('#np').type = 'text';
  },
  async makeUser(b) {
    await busy(b, async () => {
      const body = { name: val('nn'), username: val('nu'), phone: val('nph'), password: val('np'), confirm: val('np2') };
      const r = await api('/api/users', { method: 'POST', body });
      openSheet(`<div class="hd"><h3>تم إنشاء الحساب</h3><button class="iconbtn" data-act="closeSheet">${ico('close', 'sm')}</button></div>
        <p class="mini" style="margin-bottom:.8rem">سلّم هذه البيانات للمستخدم. كلمة السر لا تُعرض مرة أخرى.</p>
        ${LOCAL && canExport() ? `<div class="warn" style="margin-bottom:.8rem">${ico('inbox', 'sm')}<span><b>مهم:</b> الحساب موجود في هذا الملف فقط. لن يستطيع المستخدم الدخول إلا من ملف «نسخة المستخدمين» الذي يحوي حسابه. نزّل النسخة الآن بعد إنشاء الحساب وأرسلها له، وأعد تنزيلها بعد كل إضافة أو تغيير كلمة سر.</span></div>
        <button class="btn" style="margin-bottom:.6rem" data-act="exportUsers">${ico('download', 'sm')} تنزيل نسخة المستخدمين الآن</button>` : ''}
        <div class="card glass" style="margin-bottom:1rem"><div class="annh"><span class="mini">اسم المستخدم</span><b class="ltr">${esc(r.item.username)}</b></div><div class="annh"><span class="mini">كلمة السر</span><b class="ltr">${esc(body.password)}</b></div></div>
        <button class="btn" data-act="copy" data-v="${esc(r.item.username + ' / ' + body.password)}">${ico('copy', 'sm')} نسخ البيانات</button>`);
      toast('تم إنشاء الحساب', 'okk'); go('users', { quiet: true });
    });
  },
  async openAnn() {
    const items = await loadAnn();
    if (items[0]) annSeenSet(items[0].id);
    const admin = isManager();
    openSheet(`<div class="hd"><h3>الإعلانات</h3><button class="iconbtn" data-act="closeSheet">${ico('close', 'sm')}</button></div>
      ${items.length ? items.map((a) => `<div class="annfull"><div class="annh"><b>${esc(a.title)}</b>${admin ? `<button class="iconbtn bad" data-act="delAnn" data-id="${a.id}" data-n="${esc(a.title)}" title="حذف">${ico('trash', 'sm')}</button>` : ''}</div><p>${esc(a.body).replace(/\n/g, '<br>')}</p><small class="mini">${esc(a.by)} · ${timeAgo(a.t)}</small></div>`).join('') : empty(ill.inbox, 'لا توجد إعلانات', '')}`, { wide: true });
    if (S.tab === 'home') go('home', { quiet: true });
  },
  newAnn() {
    openSheet(`<div class="hd"><h3>إعلان جديد</h3><button class="iconbtn" data-act="closeSheet">${ico('close', 'sm')}</button></div>
      <p class="mini" style="margin-bottom:.8rem">يصل الإعلان لكل المستخدمين فور إرساله.</p>
      <div class="fld">${ico('edit')}<input id="at" placeholder="عنوان الإعلان" maxlength="160" autocomplete="off"></div><div class="fld t">${ico('megaphone')}<textarea id="ab" rows="5" maxlength="5000" placeholder="نص الإعلان"></textarea></div>
      <button class="btn" data-act="sendAnn">${ico('check', 'sm')} إرسال الإعلان</button>`);
  },
  async sendAnn(b) {
    await busy(b, async () => { await api('/api/announcements', { method: 'POST', body: { title: val('at'), body: val('ab') } }); closeSheet(); toast('تم إرسال الإعلان', 'okk'); if (S.tab === 'home') go('home', { quiet: true }); });
  },
  async delAnn(b) {
    if (!(await confirmBox('حذف الإعلان', `سيُحذف «${b.dataset.n}» لدى الجميع.`, 'حذف'))) return;
    await busy(null, async () => { await api(`/api/announcements/${b.dataset.id}`, { method: 'DELETE' }); toast('تم الحذف', 'okk'); ACT.openAnn(); });
  },
  pwUser(b) {
    openSheet(`<div class="hd"><h3>كلمة سر جديدة</h3><button class="iconbtn" data-act="closeSheet">${ico('close', 'sm')}</button></div><div class="fld">${ico('key')}<input id="npw" class="ltr" placeholder="كلمة السر الجديدة (8+ حروف وأرقام)" autocomplete="off"></div><button class="btn" data-act="savePw" data-id="${b.dataset.id}">حفظ</button>`);
  },
  async savePw(b) { await busy(b, async () => { await api(`/api/users/${b.dataset.id}`, { method: 'PATCH', body: { password: val('npw') } }); closeSheet(); toast('تم تغيير كلمة السر', 'okk'); }); },
  async toggleUser(b) { await busy(null, async () => { await api(`/api/users/${b.dataset.id}`, { method: 'PATCH', body: { disabled: b.dataset.d === '1' } }); go('users', { quiet: true }); }); },
  async delUser(b) {
    if (!(await confirmBox('حذف المستخدم', `سيُحذف ${b.dataset.n} وتعود أرقامه إلى المخزون.`, 'حذف'))) return;
    await busy(null, async () => { await api(`/api/users/${b.dataset.id}`, { method: 'DELETE' }); toast('تم الحذف', 'okk'); go('users', { quiet: true }); });
  },

  /* اللوحات */
  async setActive(b) { await busy(null, async () => { await api('/api/settings', { method: 'POST', body: { activePanel: b.dataset.id } }); toast('تم تحديد اللوحة العاملة', 'okk'); await api('/api/bot/run', { method: 'POST' }).catch(() => {}); go('panels', { quiet: true }); }); },
  async botToggle(b) { await busy(null, async () => { await api('/api/settings', { method: 'POST', body: { botOn: !b.classList.contains('on') } }); go('panels', { quiet: true }); }); },
  async runNow(b) { await busy(b, async () => { await api('/api/bot/run', { method: 'POST' }); toast('تم جلب الرسائل', 'okk'); go('panels', { quiet: true }); }); },
  async savePoll() { await busy(null, async () => { await api('/api/settings', { method: 'POST', body: { pollSeconds: +val('poll') } }); toast('تم الحفظ', 'okk'); }); },
  async testPanel(b) {
    toast('جارٍ فحص اللوحة وجلب كل الأكواد...');
    await busy(b, async () => {
      const r = await api(`/api/panels/${b.dataset.id}/test`, { method: 'POST' });
      if (!r.ok) { toast(r.error, 'err'); go('panels', { quiet: true }); return; }
      if (!('delivered' in r)) { toast(`اللوحة تعمل · ${r.ms}ms · ${r.count} رسالة`, 'okk'); return; }
      const name = S.panelsData?.find((p) => p.id === b.dataset.id)?.name || '';
      toast(`تم: ${fmt(r.delivered)} كود وصل لأصحاب الأرقام`, 'okk');
      openSheet(`<div class="hd"><div><h3>نتيجة فحص ${esc(name)}</h3><small class="mini">${fmt(r.count)} رسالة · ${fmt(r.added)} جديدة · ${r.ms}ms</small></div><button class="iconbtn" data-act="closeSheet" aria-label="إغلاق">${ico('close', 'sm')}</button></div>
        <div class="result"><div class="g1" style="--k:0"><b data-count="${r.delivered}">0</b><small>وصلت لأصحابها</small></div><div class="g2" style="--k:1"><b data-count="${r.codes}">0</b><small>كل الأكواد</small></div><div class="g3" style="--k:2"><b data-count="${r.unowned}">0</b><small>لأرقام غير موزّعة</small></div></div>
        <div class="card glass" style="margin:.8rem 0">${r.earn ? `<div class="kv"><span>أرباح المستخدمين</span><b class="ltr">${money(r.earn)}</b></div>` : ''}${r.pay ? `<div class="kv"><span>ربح اللوحة</span><b class="ltr">${money(r.pay)}</b></div>` : ''}<div class="kv"><span>الإيصال لأجهزة المستخدمين</span><span>${r.push?.on ? (r.push.ok === false ? esc(r.push.error) : 'تم الإرسال') : 'متوقف'}</span></div></div>
        ${r.users.length ? `${sec('حسب المستخدم')}${r.users.map((u, i) => `<div class="row glass" style="--k:${i};padding:.55rem .8rem"><div class="av" style="width:2.3rem;height:2.3rem"><i>${esc((u.name || '?')[0])}</i></div><div class="t"><b>${esc(u.name)}</b><small class="ltr">@${esc(u.username)}</small></div><span class="pill ok">${fmt(u.n)} كود</span>${u.earn ? `<span class="pill blue">${money(u.earn)}</span>` : ''}</div>`).join('')}` : `<div class="warn">${ico('inbox', 'sm')}<span>لا توجد أكواد لأرقام موزّعة في هذه اللوحة حالياً. وزّع الأرقام التي تظهر أدناه من صفحة النطاقات.</span></div>`}
        ${r.items.length ? `${sec('كل الرسائل', `<span class="mini">${fmt(r.items.length)}</span>`)}<div class="rowgrid">${r.items.slice(0, 200).map(codeRowAdmin).join('')}</div>` : ''}`, { wide: true });
      animateMount($('.sheet'));
      go('panels', { quiet: true });
    });
  },
  async syncSave(b) { await busy(b, async () => { await api('/api/settings', { method: 'POST', body: { syncUrl: syncVal() } }); const r = val('syncurl').trim() ? await api('/api/sync/republish', { method: 'POST' }).catch((e) => ({ ok: false, error: e.message })) : { ok: true }; toast(r.ok ? 'تم الحفظ، والبيانات تُنشر الآن للقاعدة' : (r.error || 'تعذر النشر'), r.ok ? 'okk' : 'err'); go('panels', { quiet: true }); }); },
  async syncCheck(b) { await busy(b, async () => {
    const box = $('#syncchk'); if (!box) return;
    let r; try { r = await api('/api/sync/check', { method: 'POST' }); } catch (e) { r = { ok: false, error: e.message }; }
    const d = r.delivery || {}, name = 'القناة العامة';
    const lines = r.ok
      ? [`الـAPI يعمل ✔ (${esc(name)} · ${esc(r.host || '')})`, d.listening ? 'استقبال الأرقام والأكواد على هذا الحساب: يعمل' : 'الاستقبال سيبدأ عند تسجيل الدخول بحساب مستخدم', 'الأرقام والأكواد تُحفظ مشفّرة وتصل لأي متصفح آخر يفتح نفس الرابط']
      : [`لا يعمل ✘ ${esc(r.error || '')}`];
    box.className = 'tres on ' + (r.ok ? 'ok' : 'bad');
    box.innerHTML = `<i class="pulse"></i><span>${lines.join('<br>')}</span>`;
  }); },
  async syncTest(b) { await busy(b, async () => { const r = await api('/api/sync/test', { method: 'POST', body: { url: syncVal() } }); toast(r.ok ? `القاعدة تعمل ✔ (${r.ms}ms)` : r.error, r.ok ? 'okk' : 'err'); }); },
  async syncRepub(b) { await busy(b, async () => { const r = await api('/api/sync/republish', { method: 'POST' }); toast(r.ok ? 'أُعيد نشر الحسابات والأرقام والأكواد' : r.error, r.ok ? 'okk' : 'err'); go('panels', { quiet: true }); }); },
  syncCopyLink() { copyText($('#synclink')?.value || ''); toast('تم نسخ الرابط', 'okk'); },
  syncCopySql() { copyText(SB_SQL); toast('تم نسخ كود SQL', 'okk'); },
  syncCopyRules() { copyText(SYNC_RULES); toast('تم نسخ القواعد', 'okk'); },
  async pushToggle(b) { await busy(null, async () => { await api('/api/settings', { method: 'POST', body: { pushOn: !b.classList.contains('on') } }); go('panels', { quiet: true }); }); },
  async savePushSrv() { await busy(null, async () => { await api('/api/settings', { method: 'POST', body: { pushServer: val('pushsrv') } }); toast('تم الحفظ', 'okk'); go('panels', { quiet: true }); }); },
  async detectPanel(b) {
    toast('جارٍ البحث عن المسار... قد يستغرق دقيقة');
    await busy(b, async () => { const r = await api(`/api/panels/${b.dataset.id}/detect`, { method: 'POST' }); toast(r.ok ? `تم العثور على المسار: ${r.found.path}` : r.error, r.ok ? 'okk' : 'err'); go('panels', { quiet: true }); });
  },
  addPanel: () => panelSheet(null),
  editPanel: (b) => panelSheet(S.panelsData.find((p) => p.id === b.dataset.id)),
  async savePanel(b) {
    const id = b.dataset.id;
    const body = { name: val('pn'), url: val('pu'), key: val('pk'), path: val('pp'), authHeader: val('ph'), authScheme: val('ps'), type: val('pt'), enabled: $('#pe').classList.contains('on') };
    await busy(b, async () => { await api(id ? `/api/panels/${id}` : '/api/panels', { method: id ? 'PUT' : 'POST', body }); closeSheet(); toast('تم حفظ اللوحة', 'okk'); go('panels', { quiet: true }); });
  },
  togglePe: (b) => b.classList.toggle('on'),
  async delPanel(b) {
    if (!(await confirmBox('حذف اللوحة', 'سيتوقف الجلب منها.', 'حذف'))) return;
    await busy(null, async () => { await api(`/api/panels/${b.dataset.id}`, { method: 'DELETE' }); closeSheet(); go('panels', { quiet: true }); });
  },

  /* الحساب */
  async chgPw(b) { await busy(b, async () => { await api('/api/me/password', { method: 'POST', body: { current: val('pw0'), next: val('pw1') } }); $('#pw0').value = $('#pw1').value = ''; toast('تم تغيير كلمة السر', 'okk'); }); },
  async togglePub(b) {
    const on = b.dataset.on === '1';
    if (!on && !(await confirmBox('تفعيل وسيط عام', 'ستمر مفاتيح اللوحات والرسائل عبر خدمة طرف ثالث (corsproxy.io). فعّله فقط إن قبلت ذلك.', 'تفعيل', false))) return;
    await busy(b, async () => { await api('/api/settings', { method: 'POST', body: { publicProxy: !on } }); toast(on ? 'تم الإيقاف' : 'تم التفعيل، جرّب "فحص" في اللوحات', 'okk'); go('me', { quiet: true }); });
  },
  async saveRelay(b) { await busy(b, async () => { await api('/api/settings', { method: 'POST', body: { relayUrl: val('rurl'), relayToken: val('rtok') } }); toast('تم حفظ الوسيط، جرّب "فحص" في اللوحات', 'okk'); }); },
  async saveTg(b) { await busy(b, async () => { const on = b.dataset.on === '1', tok = val('tgtok').trim(); await api('/api/settings', { method: 'POST', body: { tgToken: tok, tgOn: on && !!tok } }); toast(on ? 'تم الحفظ، سيبدأ البوت بالقراءة خلال ثوانٍ' : 'تم الإيقاف', 'okk'); go('me', { quiet: true }); }); },
  async savePrice(b) { await busy(b, async () => { await api('/api/settings', { method: 'POST', body: { pricePerCode: +val('price') } }); toast('تم حفظ السعر', 'okk'); }); },
};

function panelSheet(p) {
  openSheet(`<div class="hd"><h3>${p ? 'تعديل اللوحة' : 'لوحة جديدة'}</h3><button class="iconbtn" data-act="closeSheet">${ico('close', 'sm')}</button></div>
    <div class="fld">${ico('panels')}<input id="pn" placeholder="اسم اللوحة" value="${esc(p?.name || '')}"></div>
    <div class="fld">${ico('link')}<input id="pu" class="ltr" placeholder="https://panel.example.com" value="${esc(p?.url || '')}"></div>
    <div class="fld">${ico('key')}<input id="pk" class="ltr" placeholder="${p?.hasKey ? 'اتركه فارغاً للإبقاء على المفتاح الحالي' : 'مفتاح الـ API / التوكن'}" autocomplete="off"></div>
    <div class="fld">${ico('inbox')}<input id="pp" class="ltr" placeholder="/api/messages  (مسار جلب الرسائل)" value="${esc(p?.path || '')}"></div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:.6rem"><div class="fld"><label>الهيدر</label><input id="ph" class="ltr" value="${esc(p?.authHeader || 'Authorization')}"></div>
    <div class="fld"><label>النوع</label><select id="ps"><option value="Bearer" ${p?.authScheme === 'Bearer' || !p ? 'selected' : ''}>Bearer</option><option value="" ${p && !p.authScheme ? 'selected' : ''}>بدون</option></select></div></div>
    <div class="fld"><label>نوع اللوحة</label><select id="pt"><option value="generic" ${p?.type !== 'primehub' ? 'selected' : ''}>عامة (اكتشاف تلقائي)</option><option value="primehub" ${p?.type === 'primehub' ? 'selected' : ''}>Prime Hub</option></select></div>
    <div style="display:flex;align-items:center;gap:.8rem;margin:.4rem 0 1rem"><button class="switch ${p?.enabled !== false ? 'on' : ''}" id="pe" data-act="togglePe" aria-label="تفعيل"></button><span>مفعّلة</span></div>
    <button class="btn" data-act="savePanel" data-id="${p?.id || ''}">${ico('check', 'sm')} حفظ</button>${p ? `<button class="btn danger" style="margin-top:.6rem" data-act="delPanel" data-id="${p.id}">${ico('trash', 'sm')} حذف اللوحة</button>` : ''}`);
}

/* ======================= التواصل مع الدعم ======================= */
const CHK = '<svg class="tick" viewBox="0 0 24 24" aria-hidden="true"><path d="M3 12.5l5 5L21 6"/><path d="M9 12.5l4 4L21 8" class="t2"/></svg>';
const chatTime = (t) => new Date(t).toLocaleTimeString('ar', { hour: '2-digit', minute: '2-digit' });
const chatHTMLOld = (m, mgr, fresh) => {
  const mine = mgr ? m.from === 's' : m.from === 'u';
  return `<div class="msg ${mine ? 'me' : 'them'}${fresh ? ' fresh' : ''}" data-id="${esc(m.id)}" data-text="${esc(m.text)}"><div class="bb">${mine ? '' : `<i class="who">${esc(m.name || 'الدعم')}</i>`}<p>${esc(m.text).replace(/\n/g, '<br>')}</p><span class="mt">${chatTime(m.t)}${mine ? CHK : ''}</span></div></div>`;
};
const orb = '<div class="orb" aria-hidden="true"><svg viewBox="0 0 80 80"><circle class="r r1" cx="40" cy="40" r="12"/><circle class="r r2" cx="40" cy="40" r="12"/><circle class="r r3" cx="40" cy="40" r="12"/><circle class="core" cx="40" cy="40" r="10"/><g class="orb-headset" transform="translate(28 28)"><path d="M3 14v-3a9 9 0 0 1 18 0v3"/><path d="M3 14h4v5H5a2 2 0 0 1-2-2z"/><path d="M21 14h-4v5h2a2 2 0 0 0 2-2z"/><path d="M7 19v1a3 3 0 0 0 3 3h4"/></g></svg></div>';
const chatTopics = ['مشكلة في كود', 'طلب أرقام جديدة', 'استفسار عن الأرباح', 'مشكلة في حسابي'];
const supportArt = '<div class="support-art" aria-hidden="true"><i class="support-ring"></i><i class="support-ring r2"></i><span class="support-art-icon">' + ico('chat') + '</span><i class="support-art-star">✦</i></div>';
function chatRetryRow(id) {
  return `<div class="chat-retry-row"><span>${ico('alert', 'sm')} لم يتم الإرسال</span><button class="chat-retry" data-act="chatretry" data-id="${esc(id)}" aria-label="إعادة إرسال الرسالة">${ico('refresh', 'sm')} إعادة المحاولة</button></div>`;
}
function setChatFailed(el) {
  if (!el) return;
  el.classList.remove('pending', 'sent'); el.classList.add('fail');
  el.querySelector('.chat-retry-row')?.remove();
  el.querySelector('.bb')?.insertAdjacentHTML('beforeend', chatRetryRow(el.dataset.id));
}
function setChatSent(el) {
  if (!el) return;
  el.classList.remove('pending', 'fail'); el.classList.add('sent');
  el.querySelector('.chat-retry-row')?.remove();
}
/* ======================= الإعدادات وAPI ======================= */
const swt = (k, on) => `<button class="sw${on ? ' on' : ''}" data-act="pref" data-k="${k}" role="switch" aria-checked="${on}"></button>`;
const stag = (html) => html.map((h, i) => `<div class="stg" style="--i:${i}">${h}</div>`).join('');
/* رسومات متحركة للإعدادات وAPI */
const ILL_SET = `<svg class="ill-art" viewBox="0 0 132 84" aria-hidden="true"><defs><linearGradient id="gsl" x1="0" x2="1"><stop offset="0" stop-color="#fff" stop-opacity=".95"/><stop offset="1" stop-color="#fff" stop-opacity=".55"/></linearGradient></defs>
  <g class="gear gA"><circle class="tooth" cx="44" cy="40" r="19" stroke-dasharray="4.97 4.97"/><circle class="gbody" cx="44" cy="40" r="15"/><circle class="ghole" cx="44" cy="40" r="6"/></g>
  <g class="gear gB"><circle class="tooth" cx="87" cy="25" r="12" stroke-dasharray="3.14 3.14"/><circle class="gbody" cx="87" cy="25" r="9"/><circle class="ghole" cx="87" cy="25" r="3.6"/></g>
  <g class="trk"><rect x="66" y="52" width="52" height="5" rx="2.5"/><rect class="fill" x="66" y="52" width="30" height="5" rx="2.5"/><circle class="knob" cx="96" cy="54.500" r="6.500"/></g>
  <g class="trk t2"><rect x="66" y="68" width="52" height="5" rx="2.5"/><rect class="fill" x="66" y="68" width="22" height="5" rx="2.5"/><circle class="knob k2" cx="88" cy="70.500" r="6.500"/></g></svg>`;
const ILL_API = `<svg class="ill-art" viewBox="0 0 220 84" aria-hidden="true">
  <path id="apipath" class="wire" d="M52 42 C 88 8, 132 8, 168 42"/><path class="wire flow" d="M52 42 C 88 8, 132 8, 168 42"/>
  <path class="wire w2" d="M168 46 C 132 76, 88 76, 52 46"/><path class="wire flow f2" d="M168 46 C 132 76, 88 76, 52 46"/>
  <g class="nd nL"><rect x="14" y="22" width="40" height="40" rx="12"/><text x="34" y="46" text-anchor="middle">NFS</text></g>
  <g class="nd nR"><rect x="166" y="22" width="40" height="40" rx="12"/><path class="pl" d="M176 44l24-10-7 22-5-9z M188 47l-1 8 4-5"/></g>
  <g class="chip"><rect x="80" y="30" width="60" height="24" rx="12"/><text x="110" y="46" text-anchor="middle">nfs_••••</text></g></svg>`;
const sCard = (icon, title, sub, inner, tone = '') => `<div class="scard ${tone}"><div class="sc-h"><span class="sc-i">${ico(icon, 'sm')}</span><div><b>${title}</b>${sub ? `<small>${sub}</small>` : ''}</div></div>${inner}</div>`;
function settingsHTML() {
  const p = getPrefs();
  const hd = `<div class="ban ban-set"><button class="xbtn" data-act="closeSheet" aria-label="إغلاق"><i class="xr"></i><svg viewBox="0 0 24 24" aria-hidden="true"><path class="x1" d="M7 7l10 10"/><path class="x2" d="M17 7L7 17"/></svg></button><i class="bub b1"></i><i class="bub b2"></i><i class="bub b3"></i><div class="ban-t"><h2>إعدادات الموقع</h2><small>تُحفظ في هذا المتصفح وتُطبَّق فوراً</small></div>${ILL_SET}</div>`;
  const managerChannelCard = LOCAL && isManager() ? sCard('users', 'مزامنة المديرين بدون خادم', 'مشاركة مشفّرة بين المدير الأول والثاني على متصفحين مختلفين', `<p class="sub">تتم مزامنة النطاقات والمستخدمين والأرقام والرسائل الواردة عبر قناة عامة مشفّرة. لا تتم مشاركة كلمات السر أو جلسات الدخول أو مفاتيح اللوحات. كل مدير يسجّل الدخول بحسابه المعتاد، ورابط المشاركة سرّي ويجب إرساله للمدير الثاني فقط.</p><button class="btn" data-act="openManagerSync">${ico('link', 'sm')} إعداد قناة المديرين</button>`, 'cool') : '';
  const themes = sCard('sliders', 'الثيم', 'اختر ألوان الموقع', `<div class="themes">${THEMES.map((t, i) => `<button class="th6${p.theme === t.id ? ' on' : ''}" style="--i:${i}" data-act="theme" data-v="${t.id}"><span class="ck"><svg viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg></span><i style="background:linear-gradient(135deg,${t.c[0]},${t.c[1]})${t.dark ? ',#14122b' : ''}"></i><b>${t.name}</b></button>`).join('')}</div>`);
  const view = sCard('eye', 'العرض والتنبيهات', 'الحركة والصوت وحجم الخط', `
    <div class="opt"><div><b>الحركات والانتقالات</b><small>أوقفها لأداء أخف على الأجهزة الضعيفة</small></div>${swt('motion', p.motion)}</div>
    <div class="opt"><div><b>نغمة عند وصول كود أو رسالة</b><small>صوت قصير مع كل تنبيه جديد</small></div>${swt('sound', p.sound)}</div>
    <div class="opt"><div><b>حجم الخط</b><small>يتغير فوراً</small></div><div class="seg">${[[0.9, 'صغير'], [1, 'عادي'], [1.12, 'كبير']].map(([v, l]) => `<button class="${Math.abs(p.size - v) < 0.01 ? 'on' : ''}" data-act="fsize" data-v="${v}">${l}</button>`).join('')}</div></div>`, 'cool');
  return `<div class="set-sheet">${hd}${stag([themes, view, ...(managerChannelCard ? [managerChannelCard] : [])])}</div>`;
}
/* ---- API: رابط الموقع + مفتاح يبدأ بـ nfs ---- */
const siteBase = (r) => (r.siteUrl || (/^https?:/.test(location.protocol) ? location.origin : '')).replace(/\/+$/, '');
function apiEndpoint(r) { return r.mode === 'push' ? r.read : (siteBase(r) || 'https://رابط-موقعك') + r.read; }
function apiSnip(r, tab) {
  const ep = apiEndpoint(r), key = r.key;
  if (r.mode === 'push') {
    if (tab === 'py') return `import requests, time\nURL = "${ep}"\nseen = set()\nwhile True:\n    for line in requests.get(URL, timeout=15).text.splitlines():\n        if not line.strip(): continue\n        m = __import__("json").loads(line)\n        if m.get("event") != "message": continue\n        d = __import__("json").loads(m["message"])\n        if d["id"] in seen: continue\n        seen.add(d["id"])\n        print(d["number"], d["app"], d["code"])\n    time.sleep(4)`;
    if (tab === 'js') return `const URL = "${ep}";\nconst seen = new Set();\nsetInterval(async () => {\n  const txt = await (await fetch(URL)).text();\n  for (const line of txt.split("\\n").filter(Boolean)) {\n    const m = JSON.parse(line); if (m.event !== "message") continue;\n    const d = JSON.parse(m.message);\n    if (seen.has(d.id)) continue; seen.add(d.id);\n    console.log(d.number, d.app, d.code);\n  }\n}, 4000);`;
    return `curl "${ep}"`;
  }
  if (tab === 'py') return `import requests, time\nURL = "${ep}"\nHEADERS = {"X-API-Key": "${key}"}\nseen = set()\nwhile True:\n    r = requests.get(URL, headers=HEADERS, params={"limit": 50}, timeout=15).json()\n    for m in r.get("items", []):\n        if m["id"] in seen: continue\n        seen.add(m["id"])\n        print(m["number"], m["app"], m["code"])  # أرسلها لبوتك هنا\n    time.sleep(4)`;
  if (tab === 'js') return `const URL = "${ep}", KEY = "${key}";\nconst seen = new Set();\nsetInterval(async () => {\n  const r = await (await fetch(URL + "?limit=50", { headers: { "X-API-Key": KEY } })).json();\n  for (const m of r.items || []) {\n    if (seen.has(m.id)) continue; seen.add(m.id);\n    console.log(m.number, m.app, m.code);\n  }\n}, 4000);`;
  return `curl -H "X-API-Key: ${key}" \\\n  "${ep}?limit=20"`;
}
const keyHTML = (k) => { const m = /^(nfs)(.*)$/.exec(k || ''); return m ? `<b class="kp">${m[1]}</b><span class="kr">${esc(m[2])}</span>` : esc(k); };
async function apiHTML() {
  const r = await api('/api/apikit'); S.apikit = r; S.apitab ||= 'curl';
  const push = r.mode === 'push', site = siteBase(r), ep = apiEndpoint(r), all = r.scope === 'all';
  const xbtn = `<button class="xbtn" data-act="closeSheet" aria-label="إغلاق"><i class="xr"></i><svg viewBox="0 0 24 24" aria-hidden="true"><path class="x1" d="M7 7l10 10"/><path class="x2" d="M17 7L7 17"/></svg></button>`;
  const hd = `<div class="ban ban-api">${xbtn}<i class="bub b1"></i><i class="bub b2"></i><i class="bub b3"></i><div class="ban-t"><h2>واجهة API الخاصة بك</h2><small>${all ? 'مفتاحك يقرأ كل الأكواد الواردة لجميع المستخدمين' : 'مفتاحك خاص بك: يقرأ الأكواد الواردة لأرقامك أنت فقط'}</small><div class="ban-pills"><span class="live ${r.on ? 'on' : ''}" id="apilive"><i></i>${r.on ? 'تعمل الآن' : 'متوقفة'}</span><span class="scope ${all ? 'all' : 'own'}">${ico(all ? 'shield' : 'user', 'sm')} ${all ? 'صلاحية كاملة' : 'حسابي فقط'}</span></div></div>${ILL_API}</div>`;
  if (r.unavailable) return `<div class="set-sheet">${hd}${stag([sCard('lock', 'مفتاحك غير جاهز بعد', 'هذه النسخة لا تحمل مفتاح API لحسابك', '<p class="sub">اطلب من المدير تصدير «نسخة للمستخدمين» جديدة، وسيظهر مفتاحك الخاص هنا بعد فتحها.</p>')])}</div>`;
  const sw = `<button class="sw${r.on ? ' on' : ''}" data-act="pref" data-k="apion" role="switch" aria-checked="${r.on}" ${r.locked ? 'disabled' : ''}></button>`;
  const power = `<div class="opt"><div><b>تفعيل API</b><small>${r.locked ? (r.on ? 'مفعّلة لحسابك ويديرها المدير' : 'متوقفة، يتحكم بها المدير') : r.on ? 'يتم نشر كل كود جديد للبوتات' : 'متوقفة، لن يُنشر شيء'}</small></div>${sw}</div>`;
  const urlInput = r.canEditUrl
    ? `<div class="urlrow"><div class="fld ltrf">${ico('link')}<input id="siteurl" class="ltr" placeholder="https://your-site.com" value="${esc(site)}" autocomplete="off" inputmode="url"></div><button class="mini-btn" data-act="apisaveurl">حفظ</button></div>${site ? '' : '<small class="hint">افتح الموقع عبر رابطه (http/https) أو اكتب الرابط هنا ليظهر في الأمثلة.</small>'}`
    : '';
  const siteCard = sCard('link', '١ · نقطة الاتصال', push ? 'رابط القراءة الخاص بقناتك' : 'الرابط الذي سيتصل به البوت', `${urlInput}<p class="sub">${push ? 'رابط القراءة (قناتك)' : 'نقطة الاتصال'}</p><div class="kv"><code id="apiurl">${esc(ep)}</code><button data-act="apicopy" data-t="${esc(ep)}">نسخ</button></div>`);
  const keyCard = sCard('key', '٢ · مفتاح API الخاص بك', 'فريد لحسابك، لا يشاركه أحد، ويبدأ بـ nfs', `<div class="keybox" id="keybox"><code class="keycode"><span class="kmask">••••••••••••••••••••••••••••••</span><span class="kfull">${keyHTML(r.key)}</span></code><button class="ib" data-act="apireveal" aria-label="إظهار المفتاح">${ico('eye', 'sm')}</button><button class="ib" data-act="apicopy" data-t="${esc(r.key)}" aria-label="نسخ المفتاح">${ico('copy', 'sm')}</button></div>
    <div class="keymeta"><span class="tag2">nfs_</span><span class="tag2">${(r.key || '').length} خانة</span><span class="tag2">${all ? 'كل الأكواد' : 'أكوادي فقط'}</span>${r.sent ? `<span class="tag2">${fmt(r.sent)} كود نُشر</span>` : ''}</div>
    ${SNAPLOCK() ? '' : `<button class="mini-btn wide danger" data-act="apiregen">${ico('refresh', 'sm')} إنشاء مفتاح جديد</button>`}`, 'cool');
  const tabs = [['curl', 'cURL'], ['py', 'Python'], ['js', 'JavaScript']];
  const useCard = sCard('api', '٣ · الاستخدام', push ? 'بوت يقرأ أكوادك من القناة' : 'أرسل المفتاح في ترويسة X-API-Key', `<div class="tabs2" role="tablist">${tabs.map(([k, l]) => `<button class="${S.apitab === k ? 'on' : ''}" data-act="apitab" data-v="${k}" role="tab">${l}</button>`).join('')}</div><pre class="snip" id="snip">${esc(apiSnip(r, S.apitab))}</pre>
    <div class="kv act"><button data-act="apicopysnip">${ico('copy', 'sm')} نسخ الكود</button><button data-act="apitest">${ico('signal', 'sm')} فحص الاتصال</button></div><div class="tres" id="tres"></div>`);
  return `<div class="set-sheet">${hd}${stag([power, siteCard, keyCard, useCard])}</div>`;
}
const SNAPLOCK = () => !!document.getElementById('nfs-snapshot');
Object.assign(ACT, {
  opensettings: () => openSheet(settingsHTML()),
  async openManagerSync() { await busy(null, async () => {
    const r = await api('/api/manager-sync');
    const base = location.href.split('#')[0];
    const share = r.enabled ? `${base}#nfsmanager=${encodeURIComponent(r.topic + '.' + r.key)}` : '';
    openSheet(`<div class="hd"><div><h3>قناة المديرين المشفّرة</h3><small class="mini">مزامنة بلا خادم خاص</small></div><button class="iconbtn" data-act="closeSheet" aria-label="إغلاق">${ico('close', 'sm')}</button></div>
      <div class="warn">${ico('shield', 'sm')}<span>القناة عامة لكن محتواها مشفّر. رابط المشاركة يحتوي مفتاح فك التشفير ويمنح الوصول إلى النطاقات والأرقام والأكواد ومعلومات الحسابات؛ أرسله للمدير الثاني فقط. لا تتم مشاركة كلمات السر أو جلسات الدخول أو مفاتيح لوحات SMS.</span></div>
      ${r.enabled ? `<div class="fld t"><label>رابط دعوة المدير الثاني</label><textarea id="managerShare" class="ltr" rows="4" readonly>${esc(share)}</textarea></div><div style="display:flex;gap:.5rem;flex-wrap:wrap"><button class="btn" data-act="copyManagerShare">${ico('copy', 'sm')} نسخ رابط الدعوة</button><button class="btn s" data-act="republishManagerSync">${ico('refresh', 'sm')} مزامنة الآن</button></div><p class="sub">${r.error ? esc(r.error) : 'القناة مفعّلة. افتح رابط الدعوة في المتصفح الآخر ثم سجّل الدخول بحساب المدير الثاني.'}</p>` : (isAdmin() ? `<p class="sub">أنشئ قناة أولاً، ثم انسخ رابط الدعوة وافتحه في متصفح المدير الثاني.</p><button class="btn" data-act="createManagerSync">${ico('plus', 'sm')} إنشاء قناة ومشاركة البيانات</button>` : `<p class="sub">لم تُضبط قناة لهذا المتصفح بعد. افتح رابط الدعوة الذي أرسله المدير الأول، ثم سجّل الدخول مجدداً.</p>`)}
      <small class="mini">تنبيه: لا تتم مشاركة جلسات الدخول تلقائياً. كل مدير يسجّل الدخول بكلمة سره المعتادة. تعمل القناة عند توفر الإنترنت، واحتفاظ خدمة الإشعارات العامة بالرسائل محدود.</small>`, { wide: true });
  }); },
  async createManagerSync(b) { await busy(b, async () => { const r = await api('/api/manager-sync', { method: 'POST', body: { create: true } }); if (!r.ok) throw new Error(r.error || 'تعذر إنشاء القناة'); toast('تم إنشاء القناة ونشر البيانات المشفّرة', 'okk'); ACT.openManagerSync(); }); },
  async republishManagerSync(b) { await busy(b, async () => { const r = await api('/api/manager-sync', { method: 'POST', body: { republish: true } }); toast(r.ok ? 'تمت مزامنة بيانات المديرين' : (r.error || 'تعذرت المزامنة'), r.ok ? 'okk' : 'err'); ACT.openManagerSync(); }); },
  async copyManagerShare() { const t = $('#managerShare')?.value || ''; if (!t) return toast('رابط المشاركة غير متاح', 'err'); await copyText(t); toast('تم نسخ رابط الدعوة؛ أرسله للمدير الثاني فقط', 'okk'); },
  async openapi() { try { openSheet(await apiHTML()); } catch (e) { toast(e.message || 'تعذر فتح API', 'err'); } },
  theme: (b) => { setPref('theme', b.dataset.v); $$('.th6').forEach((x) => x.classList.toggle('on', x === b)); },
  fsize: (b) => { setPref('size', Number(b.dataset.v)); $$('.seg button').forEach((x) => x.classList.toggle('on', x === b)); },
  async pref(b) {
    const k = b.dataset.k, on = !b.classList.contains('on');
    if (k === 'apion') { try { await api('/api/apikit', { method: 'POST', body: { on } }); b.classList.toggle('on', on); b.setAttribute('aria-checked', on); b.closest('.opt').querySelector('small').textContent = on ? 'يتم نشر كل كود جديد للبوتات' : 'متوقفة، لن يُنشر شيء'; const lv = $('#apilive'); if (lv) { lv.classList.toggle('on', on); lv.lastChild.textContent = on ? 'تعمل الآن' : 'متوقفة'; } } catch (e) { toast(e.message, 'err'); } return; }
    setPref(k, on); b.classList.toggle('on', on); b.setAttribute('aria-checked', on);
  },
  apicopy: async (b) => { await copyText(b.dataset.t); toast('تم النسخ', 'ok'); },
  async apiregen() { if (!(await confirmBox('مفتاح جديد', 'سيتوقف أي بوت يستخدم المفتاح القديم حتى تحدّثه.', 'إنشاء'))) return; await api('/api/apikit', { method: 'POST', body: { regen: true } }); openSheet(await apiHTML()); toast('تم إنشاء مفتاح nfs جديد', 'okk'); },
  async apisaveurl(b) { const v = ($('#siteurl').value || '').trim(); b.disabled = true; try { await api('/api/apikit', { method: 'POST', body: { siteUrl: v } }); openSheet(await apiHTML()); toast('تم حفظ رابط الموقع', 'okk'); } catch (e) { toast(e.message || 'تعذر الحفظ', 'err'); b.disabled = false; } },
  apireveal(b) { const k = $('#keybox'); const on = k.classList.toggle('show'); b.innerHTML = ico(on ? 'eyeoff' : 'eye', 'sm'); },
  apitab(b) { S.apitab = b.dataset.v; $$('.tabs2 button').forEach((x) => x.classList.toggle('on', x === b)); const sn = $('#snip'); sn.textContent = apiSnip(S.apikit, S.apitab); sn.classList.remove('swap'); void sn.offsetWidth; sn.classList.add('swap'); },
  async apicopysnip() { await copyText(apiSnip(S.apikit, S.apitab)); toast('تم نسخ الكود', 'ok'); },
  async apitest(b) {
    const box = $('#tres'); box.className = 'tres on'; box.innerHTML = '<div class="sig"><i></i><i></i><i></i><i></i></div><span>جارٍ النشر والقراءة من القناة...</span>'; b.disabled = true;
    try { const r = await api('/api/apikit/test', { method: 'POST' }); box.className = 'tres on ' + (r.ok ? 'ok' : 'bad'); box.innerHTML = `<i class="pulse"></i><span>${r.ok ? `تعمل بنجاح: نُشرت رسالة تجريبية وقُرئت خلال ${r.ms}ms` : 'نُشرت الرسالة لكن لم تُقرأ، تحقق من الاتصال'}</span>`; }
    catch (e) { box.className = 'tres on bad'; box.innerHTML = `<i class="pulse"></i><span>${esc(e.message || 'فشل الفحص')}</span>`; }
    b.disabled = false;
  },
});

async function chatPing() {
  if (!S.me || S.tab === 'chat') return;
  try {
    const r = await api('/api/chat'), mgr = isManager();
    const sig = mgr ? (r.threads || []).filter((x) => x.from === 'u').map((x) => x.uid + ':' + x.t).join('|') : (r.items || []).filter((x) => x.from === 's').map((x) => x.id).pop() || '';
    if (S.chatSig === undefined) { S.chatSig = sig; return; }
    if (sig && sig !== S.chatSig) { toast(mgr ? 'رسالة جديدة في صندوق الدعم' : 'رسالة جديدة من فريق الدعم', 'ok'); $('#nav .nv[data-t="chat"]')?.classList.add('dot'); }
    S.chatSig = sig;
  } catch { /* تجاهل */ }
}
async function refreshChatOld() {
  const l = $('#chatl'); if (!l || S.tab !== 'chat') return;
  const mgr = isManager(); if (mgr && !S.chatU) return;
  const r = await api('/api/chat' + (mgr ? '?u=' + S.chatU : '')); let n = 0;
  for (const m of r.items) { if (S.chatIds.has(m.id)) continue; S.chatIds.add(m.id); l.insertAdjacentHTML('beforeend', chatHTMLOld(m, mgr, true)); n++; }
  if (n) { l.scrollTo({ top: l.scrollHeight, behavior: 'smooth' }); l.parentElement.classList.remove('empty-room'); }
}
VIEWS.chat = async function () {
  const mgr = isManager(); $('#nav .nv[data-t="chat"]')?.classList.remove('dot');
  if (mgr && !S.chatU) {
    const r = await api('/api/chat'); S.chatSig = (r.threads || []).filter((x) => x.from === 'u').map((x) => x.uid + ':' + x.t).join('|');
    return topbar('متابعة الرسائل والردود', 'صندوق الدعم', `<span class="inbox-count">${fmt(r.threads.length)} محادثة</span>`) +
      `<div class="glass sup-banner support-inbox-banner">${orb}<div class="support-inbox-copy"><b>كل محادثات المستخدمين في مكان واحد</b><small>رسائل المستخدمين تصل إلى فريق الدعم، ويمكن فتح أي محادثة والرد مباشرة.</small></div><span class="inbox-total"><b>${fmt(r.threads.length)}</b><small>محادثة</small></span></div>` +
      (r.threads.length ? `<div class="thr">${r.threads.map((x, i) => `<button class="glass th" style="--k:${i}" data-act="chatopen" data-u="${x.uid}"><div class="av"><i>${esc((x.name || x.username || '?')[0].toUpperCase())}</i></div><div class="thread-copy"><b>${esc(x.name || x.username)}</b><small>${esc(x.last)}</small><span class="thread-sub">${x.from === 'u' ? 'رسالة جديدة من المستخدم' : 'آخر رد من الدعم'}</span></div>${x.from === 'u' ? '<i class="pip" aria-label="رسالة جديدة"></i>' : ''}<time>${timeAgo(x.t)}</time>${ico('chevron', 'sm')}</button>`).join('')}</div>` : `<div class="support-empty glass">${empty(ill.inbox, 'صندوق الدعم جاهز', 'ستظهر هنا محادثات المستخدمين فور وصول أول رسالة')}</div>`);
  }
  const r = await api('/api/chat' + (mgr ? '?u=' + S.chatU : '')); let n = 0;
  S.chatIds = new Set(r.items.map((m) => m.id));
  const who = mgr ? (r.user?.name || r.user?.username || 'مستخدم') : 'فريق الدعم';
  setTimeout(() => $('#chatl')?.scrollTo({ top: 1e9 }), 60);
  const aside = mgr
    ? `<aside class="support-info support-admin-info glass"><div class="support-heading">${supportArt}<div class="support-copy"><span class="support-kicker">لوحة فريق الدعم</span><h2>محادثة مباشرة</h2><p>اكتب ردك في المحادثة، وسيظهر للمستخدم ضمن نفس سلسلة الرسائل.</p></div></div><div class="support-state"><i class="state-dot"></i><div><b>${esc(who)}</b><small>${esc(r.user?.username ? '@' + r.user.username : 'المستخدم المحدد')}</small></div></div><div class="support-assurance">${ico('shield')}<div><b>رد واضح وآمن</b><small>تأكد من فهم الطلب قبل إرسال الحل، ولا تطلب من المستخدم مشاركة كلمة مروره.</small></div></div><button class="support-back" data-act="chatback">${ico('arrowright', 'sm')} العودة إلى صندوق المحادثات</button></aside>`
    : `<aside class="support-info glass"><div class="support-heading">${supportArt}<div class="support-copy"><span class="support-kicker">مركز مساعدة NFSsms</span><h2>خلّينا نحلّها معك</h2><p>اكتب استفسارك وسيتابعه فريق الدعم الأول والثاني. ستجد الرد هنا داخل المحادثة.</p></div></div><div class="support-state"><i class="state-dot"></i><div><b>قناة التواصل مفتوحة</b><small>رسالتك تصل لفريق الدعم مباشرة</small></div><span class="support-state-icon">${ico('messagesquare')}</span></div><div class="support-topics"><div class="support-section-head"><b>تواصل سريع</b><small>اختر موضوع رسالتك</small></div><div class="qchips" id="qchips">${chatTopics.map((t, i) => `<button class="qchip" style="--i:${i}" data-act="qchip" data-t="${t}">${t}${ico('arrowupleft', 'sm')}</button>`).join('')}</div></div><div class="support-assurance">${ico('shield')}<div><b>محادثتك خاصة</b><small>لا ترسل كلمة مرورك أو أكواد التحقق نفسها داخل رسالة الدعم.</small></div></div><div class="support-foot">${ico('clock', 'sm')} الردود الجديدة تظهر هنا عند وصولها</div></aside>`;
  // Lucide send glyph (ISC): https://lucide.dev/icons/send, bundled inline for offline use.
  const chatPanel = `<section class="chat glass${r.items.length ? '' : ' empty-room'}"><header class="sup-h"><i class="sh-b sb1"></i><i class="sh-b sb2"></i>${mgr ? '<button class="iconbtn" data-act="chatback" aria-label="العودة إلى صندوق الدعم">' + ico('arrowright') + '</button>' : ''}${orb}<div class="chat-heading"><b>${esc(who)}</b><small>${mgr ? 'رد مباشر إلى المستخدم' : 'الدعم الأول والثاني يستقبلان رسالتك'}</small></div><span class="onl"><i class="live"></i>الدعم</span></header>
    <div class="chat-l" id="chatl" aria-live="polite" aria-relevant="additions text">${r.items.map((m) => chatHTMLOld(m, mgr, false)).join('')}</div>
    <div class="hello"><svg viewBox="0 0 120 90" aria-hidden="true"><path class="d1" d="M10 70c20-40 40-40 50-20s30 20 50-30"/><circle class="d2" cx="60" cy="50" r="6"/></svg><b>ابدأ المحادثة</b><span>${mgr ? 'أرسل ردك الأول لهذا المستخدم' : 'اكتب استفسارك وسيظهر الرد في هذه المساحة'}</span><div class="typing" aria-hidden="true"><i></i><i></i><i></i></div></div>
    <div class="chat-compose"><div class="chat-c"><textarea id="chatin" rows="1" maxlength="2000" placeholder="اكتب رسالتك هنا…" aria-label="نص الرسالة" aria-describedby="chatHelp" dir="auto"></textarea><button class="send" data-act="chatsend" aria-label="إرسال الرسالة" title="إرسال الرسالة"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></svg></button></div><div class="chat-compose-meta" id="chatHelp"><span>${ico('cornerdownleft', 'sm')} Enter للإرسال · Shift+Enter لسطر جديد</span><span id="chatcount">0 / 2000</span></div></div></section>`;
  return topbar(mgr ? 'الرد على المستخدم' : 'دعم مباشر عند الحاجة', mgr ? 'محادثة الدعم' : 'مركز التواصل') + `<section class="support-layout${mgr ? ' admin-chat' : ''}">${aside}${chatPanel}</section>`;
};
Object.assign(ACT, {
  chatopen: (b) => { S.chatU = Number(b.dataset.u); go('chat'); },
  chatback: () => { S.chatU = null; go('chat'); },
  qchip(b) { const i = $('#chatin'); if (!i || i.disabled) return; i.value = b.dataset.t + ': '; i.focus(); i.dispatchEvent(new Event('input', { bubbles: true })); b.parentElement.classList.add('gone'); },
  async chatsend() {
    const inp = $('#chatin'), l = $('#chatl'), sb = $('.chat-c .send');
    if (!inp || !l || !sb || S.chatSending) return;
    const text = inp.value.trim(); if (!text) { inp.focus(); return; }
    const mgr = isManager();
    const id = 'c' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
    const item = { id, from: mgr ? 's' : 'u', name: S.me?.name || S.me?.username || 'مستخدم', text, t: Date.now() };
    S.chatIds ||= new Set(); S.chatIds.add(id); S.chatSending = true;
    l.insertAdjacentHTML('beforeend', chatHTMLOld(item, mgr, true));
    const el = l.lastElementChild; el.classList.add('pending'); l.parentElement.classList.remove('empty-room');
    inp.value = ''; inp.style.height = ''; inp.disabled = true;
    sb.disabled = true; sb.setAttribute('aria-busy', 'true'); sb.classList.add('is-sending'); sb.setAttribute('aria-label', 'جارٍ إرسال الرسالة');
    $('#chatcount').textContent = '0 / 2000'; $('#qchips')?.classList.add('gone');
    sb.classList.add('fly'); setTimeout(() => sb?.classList.remove('fly'), 800);
    l.scrollTo({ top: l.scrollHeight, behavior: 'smooth' });
    try {
      await api('/api/chat', { method: 'POST', body: { id, text, to: mgr ? S.chatU : undefined } });
      setChatSent(el);
    } catch (e) {
      setChatFailed(el); toast(e.message || 'تعذر الإرسال. جرّب إعادة المحاولة من الرسالة.', 'err');
    } finally {
      S.chatSending = false;
      if (inp.isConnected) { inp.disabled = false; inp.focus(); }
      if (sb.isConnected) { sb.disabled = false; sb.removeAttribute('aria-busy'); sb.classList.remove('is-sending'); sb.setAttribute('aria-label', 'إرسال الرسالة'); sb.title = 'إرسال الرسالة'; }
    }
  },
  async chatretry(b) {
    if (S.chatSending) return;
    const id = b.dataset.id, el = $$('#chatl .msg').find((m) => m.dataset.id === id);
    if (!el || el.classList.contains('pending')) return;
    const text = el.dataset.text || el.querySelector('.bb p')?.innerText || '';
    if (!text.trim()) { toast('لا يوجد نص لإعادة إرساله', 'err'); return; }
    const retry = el.querySelector('.chat-retry'); if (retry) { retry.disabled = true; retry.innerHTML = `${ico('refresh', 'sm')} جارٍ الإرسال`; }
    const inp = $('#chatin'), sb = $('.chat-c .send');
    S.chatSending = true;
    if (inp) inp.disabled = true;
    if (sb) { sb.disabled = true; sb.setAttribute('aria-busy', 'true'); sb.classList.add('is-sending'); }
    el.querySelector('.chat-retry-row')?.remove(); el.classList.remove('fail', 'sent'); el.classList.add('pending');
    try {
      await api('/api/chat', { method: 'POST', body: { id, text, to: isManager() ? S.chatU : undefined } });
      setChatSent(el); toast('تم إرسال الرسالة بنجاح', 'okk');
    } catch (e) {
      setChatFailed(el); toast(e.message || 'ما زال الإرسال غير مكتمل. يمكنك المحاولة مجدداً.', 'err');
    } finally {
      S.chatSending = false;
      if (inp?.isConnected) inp.disabled = false;
      if (sb?.isConnected) { sb.disabled = false; sb.removeAttribute('aria-busy'); sb.classList.remove('is-sending'); }
    }
  },
});
addEventListener('keydown', (e) => { if (e.target?.id === 'chatin' && e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); ACT.chatsend(); } });
addEventListener('input', (e) => {
  if (e.target?.id === 'chatin') {
    e.target.style.height = 'auto'; e.target.style.height = Math.min(e.target.scrollHeight, 120) + 'px';
    const count = $('#chatcount'); if (count) count.textContent = `${e.target.value.length} / 2000`;
  }
});

/* ======================= شاشة التواصل (ملء الشاشة) ======================= */
// شعار الدعم: مربع بحواف دائرية بسماعة رأس ونقطة اتصال خضراء
const CX_LOGO = '<span class="cx-logo" aria-hidden="true"><svg viewBox="0 0 48 48"><defs><linearGradient id="cxlg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ff3b5c"/><stop offset=".58" stop-color="#ff965b"/><stop offset="1" stop-color="#8c78ff"/></linearGradient></defs><rect width="48" height="48" rx="15" fill="url(#cxlg)"/><path d="M13.5 23a10.5 10.5 0 0 1 21 0" fill="none" stroke="#fff" stroke-width="2.6" stroke-linecap="round"/><rect x="10" y="22" width="6" height="10" rx="3" fill="#fff"/><rect x="32" y="22" width="6" height="10" rx="3" fill="#fff"/><path d="M35 31.5c0 3.6-3.2 5.5-8 5.5" fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round"/><circle cx="25.5" cy="37" r="2.4" fill="#fff"/></svg><i class="cx-dot"></i></span>';
const chatViewOld = VIEWS.chat;
const FILE_LOCAL_MAX = 40 * 1024, FILE_MAX = 5 * 1024 * 1024;
const fmtSize = (n) => (n > 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB');
const SV = (d) => `<svg viewBox="0 0 24 24" aria-hidden="true">${d}</svg>`;
const I_PLUS = SV('<path d="M12 5v14M5 12h14"/>'), I_SEND = SV('<path d="M5 12h14M13 6l6 6-6 6"/>'), I_X = SV('<path d="M6 6l12 12M18 6L6 18"/>');
const I_IMG = SV('<rect x="3" y="4" width="18" height="16" rx="3"/><circle cx="9" cy="10" r="1.8"/><path d="M4 18l5-5 4 4 3-3 4 4"/>'), I_VID = SV('<rect x="3" y="6" width="13" height="12" rx="3"/><path d="M16 11l5-3v8l-5-3z"/>'), I_FIL = SV('<path d="M14 3H7a2 2 0 00-2 2v14a2 2 0 002 2h10a2 2 0 002-2V8z"/><path d="M14 3v5h5M9 13h6M9 17h4"/>');
const fileHTML = (f) => {
  if (!f) return '';
  const u = f.url || (f.id ? `/api/chat/file/${encodeURIComponent(f.id)}` : '');
  if (!u) return `<div class="att wait"><i class="spn"></i><span>${esc(f.name)}<small>جارٍ الاستلام</small></span></div>`;
  if (/^image\//.test(f.type)) return `<a class="att img" href="${u}" target="_blank" rel="noopener"><img src="${u}" alt="${esc(f.name)}" loading="lazy"></a>`;
  if (/^video\//.test(f.type)) return `<video class="att vid" src="${u}" controls preload="metadata" playsinline></video>`;
  return `<a class="att file" href="${u}" download="${esc(f.name)}">${I_FIL}<span><b>${esc(f.name)}</b><small>${fmtSize(f.size || 0)}</small></span></a>`;
};
const chatHTML = (m, mgr, fresh) => {
  const mine = mgr ? m.from === 's' : m.from === 'u';
  return `<div class="cm ${mine ? 'me' : 'them'}${fresh ? ' fresh' : ''}" data-id="${esc(m.id)}"><div class="cb">${mine ? '' : `<i class="who">${esc(m.name || 'الدعم')}</i>`}${fileHTML(m.file)}${m.text ? `<p>${esc(m.text).replace(/\n/g, '<br>')}</p>` : ''}<span class="mt">${chatTime(m.t)}${mine ? CHK : ''}</span></div></div>`;
};
async function refreshChat() {
  const l = $('#cxl'); if (!l || S.tab !== 'chat') return;
  const mgr = isManager(); if (mgr && !S.chatU) return;
  const r = await api('/api/chat' + (mgr ? '?u=' + S.chatU : '')); let n = 0;
  for (const m of r.items) {
    if (S.chatIds.has(m.id)) { const el = l.querySelector(`[data-id="${CSS.escape(m.id)}"]`); if (el && m.file && el.querySelector('.att.wait') && (m.file.url || m.file.id)) el.outerHTML = chatHTML(m, mgr, false); continue; }
    S.chatIds.add(m.id); l.insertAdjacentHTML('beforeend', chatHTML(m, mgr, true)); n++;
  }
  if (n) { l.scrollTo({ top: l.scrollHeight, behavior: 'smooth' }); l.closest('.cx').classList.remove('empty-room'); }
}
VIEWS.chat = async function () {
  const mgr = isManager(); $('#nav .nv[data-t="chat"]')?.classList.remove('dot');
  if (mgr && !S.chatU) return chatViewOld();
  const r = await api('/api/chat' + (mgr ? '?u=' + S.chatU : '')); S.chatIds = new Set(r.items.map((m) => m.id)); S.cxFile = null;
  const who = mgr ? (r.user?.name || r.user?.username || 'مستخدم') : 'فريق الدعم';
  setTimeout(() => $('#cxl')?.scrollTo({ top: 1e9 }), 60);
  return `<section class="cx${r.items.length ? '' : ' empty-room'}">
    <header class="cx-h"><div class="cx-card">${mgr ? `<button class="iconbtn" data-act="chatback" aria-label="رجوع">${ico('arrowright')}</button>` : ''}${CX_LOGO}<div class="cx-t"><b>${esc(who)}</b><small>${mgr ? 'رد مباشر إلى المستخدم' : 'الدعم الأول والثاني يستقبلان رسالتك'}</small></div><span class="cx-live"><i></i>متصل</span></div></header>
    <div class="cx-l" id="cxl" aria-live="polite">${r.items.map((m) => chatHTML(m, mgr, false)).join('')}</div>
    <div class="cx-hello"><svg viewBox="0 0 120 90" aria-hidden="true"><path class="d1" d="M10 70c20-40 40-40 50-20s30 20 50-30"/><circle class="d2" cx="60" cy="50" r="6"/></svg><b>ابدأ المحادثة</b><span>اكتب رسالتك أو أرفق صورة وسنردّ عليك هنا</span></div>
    <div class="cx-dock"><div class="cx-menu" id="cxmenu"><button data-act="cxpick" data-k="image" style="--i:0">${I_IMG}<span>صورة</span></button><button data-act="cxpick" data-k="video" style="--i:1">${I_VID}<span>فيديو</span></button><button data-act="cxpick" data-k="file" style="--i:2">${I_FIL}<span>ملف</span></button></div>
      <div class="cx-pre" id="cxpre"></div>
      <div class="cx-box"><button class="cx-plus" id="cxplus" data-act="cxplus" aria-label="إرفاق" aria-expanded="false">${I_PLUS}</button><textarea id="cxin" rows="1" maxlength="2000" placeholder="اكتب رسالتك"></textarea><button class="cx-send" data-act="cxsend" aria-label="إرسال">${I_SEND}</button></div></div>
    <input type="file" id="cxfile" hidden></section>`;
};
const cxMenu = (open) => { $('#cxmenu')?.classList.toggle('open', open); const p = $('#cxplus'); p?.classList.toggle('open', open); p?.setAttribute('aria-expanded', open); };
async function shrinkImage(file, maxBytes) {
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise((ok, no) => { const i = new Image(); i.onload = () => ok(i); i.onerror = () => no(new Error('تعذر قراءة الصورة')); i.src = url; });
    let q = 0.78, dim = 1400;
    for (let k = 0; k < 10; k++) {
      const sc = Math.min(1, dim / Math.max(img.naturalWidth, img.naturalHeight)), c = document.createElement('canvas');
      c.width = Math.max(1, Math.round(img.naturalWidth * sc)); c.height = Math.max(1, Math.round(img.naturalHeight * sc)); c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      const d = c.toDataURL('image/jpeg', q); if (d.length * 0.75 <= maxBytes) return d;
      q = Math.max(0.35, q - 0.1); dim = Math.round(dim * 0.78);
    }
    throw new Error('الصورة كبيرة جداً');
  } finally { URL.revokeObjectURL(url); }
}
const readData = (f) => new Promise((ok, no) => { const r = new FileReader(); r.onload = () => ok(r.result); r.onerror = () => no(new Error('تعذر قراءة الملف')); r.readAsDataURL(f); });
Object.assign(ACT, {
  cxplus: () => cxMenu(!$('#cxmenu')?.classList.contains('open')),
  cxpick(b) { const f = $('#cxfile'); f.accept = { image: 'image/*', video: 'video/*', file: '' }[b.dataset.k] || ''; f.value = ''; cxMenu(false); f.click(); },
  cxunpick() { S.cxFile = null; const p = $('#cxpre'); p.classList.remove('on'); setTimeout(() => { p.innerHTML = ''; }, 300); },
  async cxsend() {
    const inp = $('#cxin'), l = $('#cxl'); if (!inp || !l) return;
    const text = inp.value.trim(), f = S.cxFile; if (!text && !f) return; const mgr = isManager();
    const id = 'c' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
    inp.value = ''; inp.style.height = ''; S.cxFile = null; cxMenu(false); const pre = $('#cxpre'); pre.classList.remove('on'); setTimeout(() => { pre.innerHTML = ''; }, 300);
    S.chatIds.add(id);
    l.insertAdjacentHTML('beforeend', chatHTML({ id, from: mgr ? 's' : 'u', name: S.me.name, text, t: Date.now(), file: f ? { name: f.name, type: f.type, size: f.size, url: f.data } : undefined }, mgr, true));
    const el = l.lastElementChild; el.classList.add('pending'); l.closest('.cx').classList.remove('empty-room');
    const sb = $('.cx-send'); sb?.classList.add('fly'); setTimeout(() => sb?.classList.remove('fly'), 750);
    l.scrollTo({ top: l.scrollHeight, behavior: 'smooth' });
    try { await api('/api/chat', { method: 'POST', body: { id, text, to: mgr ? S.chatU : undefined, file: f || undefined } }); el.classList.remove('pending'); el.classList.add('sent'); }
    catch (e) { el.classList.remove('pending'); el.classList.add('fail'); toast(e.message || 'تعذر الإرسال', 'err'); }
  },
});
addEventListener('change', async (e) => {
  if (e.target?.id !== 'cxfile' || !e.target.files?.[0]) return;
  const f = e.target.files[0], max = LOCAL ? FILE_LOCAL_MAX : FILE_MAX, pre = $('#cxpre');
  try {
    let data, type = f.type || 'application/octet-stream', size = f.size;
    if (/^image\//.test(type) && !/gif|svg/.test(type)) { data = await shrinkImage(f, LOCAL ? FILE_LOCAL_MAX : 900 * 1024); type = 'image/jpeg'; size = Math.round(data.length * 0.75); }
    else { if (f.size > max) throw new Error(LOCAL ? 'بدون خادم: الصور تُصغَّر تلقائياً، أما الفيديو والملفات فحتى 40KB' : 'الحد الأقصى للملف 5MB'); data = await readData(f); }
    S.cxFile = { name: f.name, type, size, data };
    pre.innerHTML = `<div class="pv">${/^image\//.test(type) ? `<img src="${data}" alt="">` : /^video\//.test(type) ? I_VID : I_FIL}<span><b>${esc(f.name)}</b><small>${fmtSize(size)}</small></span><button data-act="cxunpick" aria-label="إزالة">${I_X}</button></div>`; requestAnimationFrame(() => pre.classList.add('on'));
  } catch (err) { toast(err.message || 'تعذر إرفاق الملف', 'err'); }
});
addEventListener('keydown', (e) => { if (e.target?.id === 'cxin' && e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); ACT.cxsend(); } if (e.key === 'Escape') cxMenu(false); });
addEventListener('input', (e) => { if (e.target?.id === 'cxin') { e.target.style.height = 'auto'; e.target.style.height = Math.min(e.target.scrollHeight, 130) + 'px'; } });
addEventListener('click', (e) => { if (!e.target.closest?.('.cx-menu,.cx-plus')) cxMenu(false); });


document.addEventListener('submit', (e) => {
  if (e.target?.id === 'userSearchForm') { e.preventDefault(); ACT.searchUsers($('#userSearchBtn')); }
});
document.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && e.target?.id === 'userEmail') { e.preventDefault(); ACT.searchUsers($('#userSearchBtn')); }
});
document.addEventListener('click', (e) => {
  const b = e.target.closest('[data-act]');
  if (b && ACT[b.dataset.act]) { if (b.tagName === 'A') return; ACT[b.dataset.act](b, e); }
});

/* ======================= التحديث المباشر ======================= */
let beepCtx = null;
function beep() {
  try { beepCtx ||= new (window.AudioContext || window.webkitAudioContext)(); const o = beepCtx.createOscillator(), g = beepCtx.createGain(); o.type = 'sine'; o.frequency.value = 880; g.gain.setValueAtTime(0.0001, beepCtx.currentTime); g.gain.exponentialRampToValueAtTime(0.2, beepCtx.currentTime + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, beepCtx.currentTime + 0.35); o.connect(g).connect(beepCtx.destination); o.start(); o.stop(beepCtx.currentTime + 0.4); } catch { /* تجاهل */ }
}
let ticking = false, tickAgain = false;
async function tickCodes() {
  if (!S.me) return;
  if (ticking) { tickAgain = true; return; }
  ticking = true;
  try {
    try {
      const r = await api('/api/codes' + (isManager() ? '?scope=' + S.scope : ''));
      const ids = r.items.map((i) => i.id);
      chatPing(); if (S.tab === 'chat') refreshChat();
      if (r.rev != null) {
        const known = window.__nfsRev;
        if (known == null) window.__nfsRev = String(r.rev);
        else if (String(r.rev) !== String(known)) {
          const typing = /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement?.tagName || '');
          if (!sheetOpen() && !typing && ['home', 'doms', 'users'].includes(S.tab)) { window.__nfsRev = String(r.rev); go(S.tab, { quiet: true }); }
        }
      }
      if (S.seen) {
        const fresh = r.items.filter((i) => !S.seen.has(i.id) && i.c);
        if (fresh.length) {
          fresh.forEach((i) => S.fresh.add(i.id));
          const f = fresh[0];
          toast(`كود جديد ${f.c} · ${APP_NAMES[f.a] || ''}`, 'okk', f.a); beep();
          if (document.hidden && window.Notification?.permission === 'granted') { try { new Notification(`كود ${f.c}`, { body: `${APP_NAMES[f.a] || ''} · +${f.n}`, tag: f.id }); } catch { /* تجاهل */ } }
          S.lastCodes = r.items;
          if (!sheetOpen() && ['home', 'codes', 'doms'].includes(S.tab)) { if (S.tab === 'codes') { const l = $('#codelist'); if (l) l.innerHTML = codeList(); } else go(S.tab, { quiet: true }); }
          setTimeout(() => fresh.forEach((i) => S.fresh.delete(i.id)), 3000);
        }
      }
      S.seen = new Set(ids);
      if (S.tab === 'codes') { const pill = $('#page .top .livepill'); if (pill) pill.outerHTML = botPill(r.bot); }
    } catch { /* تجاهل */ }
  } finally { ticking = false; if (tickAgain) { tickAgain = false; tickCodes(); } }
}
function startPoll() {
  stopPoll();
  try { if (window.Notification && Notification.permission === 'default') Notification.requestPermission().catch(() => {}); } catch { /* تجاهل */ }
  S.poll = setInterval(() => {
    if (!S.me) return;
    S.tick = (S.tick || 0) + 1; if (S.tick % 6 === 0 && !document.hidden) checkAnn();
    tickCodes();
  }, 4000);
}
function stopPoll() { clearInterval(S.poll); S.poll = null; }
// وصول كود جديد (من البوت أو من خدمة الإشعارات أو من تبويب آخر) → تحديث فوري بدون انتظار
addEventListener('nfs:new', () => { if (S.me) tickCodes(); });
document.addEventListener('visibilitychange', () => { if (!document.hidden && S.me) tickCodes(); });

/* ======================= البدء ======================= */
(async function init() {
  try {
    const r = await api('/api/me');
    await enterApp(r.user);
  } catch {
    if (hasClerkAuth()) {
      try {
        const clerk = await getClerk();
        if (clerk.isSignedIn && clerk.session) await completeClerkLogin();
        else showLogin();
      } catch { showLogin(); }
    } else showLogin();
  }
  setTimeout(() => $('#splash').classList.add('off'), 600);
})();
