window.NFS_API = 'local';
window.NFS_CLERK_PUBLISHABLE_KEY = '';
// Supabase: المفتاح المنشور (publishable) جاهز. ضع رابط المشروع (Project URL) مرة واحدة فقط ليعمل كل شيء:
window.NFS_SYNC = '';
