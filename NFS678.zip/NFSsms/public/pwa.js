// تثبيت التطبيق (PWA): تسجيل الـ service worker + زر "تثبيت التطبيق".
if (/^https?:$/.test(location.protocol) && document.querySelector('link[rel="manifest"]')) {
  if ('serviceWorker' in navigator) addEventListener('load', () => navigator.serviceWorker.register('sw.js').catch(() => {}));

  const standalone = () => matchMedia('(display-mode: standalone)').matches || navigator.standalone;
  let deferred = null, btn = null;
  const css = '#pwaInstall{position:fixed;z-index:90;inset-inline:1rem;bottom:calc(1rem + env(safe-area-inset-bottom));max-width:26rem;margin-inline:auto;display:flex;align-items:center;gap:.8rem;padding:.7rem .8rem;border-radius:1.2rem;background:#111;color:#fff;box-shadow:0 10px 30px rgba(0,0,0,.35);font:600 .95rem/1.4 inherit;direction:rtl}#pwaInstall img{width:2.6rem;height:2.6rem;border-radius:.7rem}#pwaInstall span{flex:1}#pwaInstall button{border:0;border-radius:.8rem;padding:.55rem 1rem;font:inherit;cursor:pointer}#pwaInstall .go{background:#fff;color:#000}#pwaInstall .x{background:transparent;color:#aaa;padding:.55rem}';
  function show(text, withBtn) {
    if (btn || standalone() || sessionStorage.getItem('pwaDismiss')) return;
    document.head.insertAdjacentHTML('beforeend', `<style>${css}</style>`);
    document.body.insertAdjacentHTML('beforeend', `<div id="pwaInstall"><img src="icons/icon-192.png" alt=""><span>${text}</span>${withBtn ? '<button class="go">تثبيت</button>' : ''}<button class="x" aria-label="إغلاق">✕</button></div>`);
    btn = document.getElementById('pwaInstall');
    btn.querySelector('.x').onclick = () => { sessionStorage.setItem('pwaDismiss', '1'); btn.remove(); };
    const go = btn.querySelector('.go');
    if (go) go.onclick = async () => { btn.remove(); deferred.prompt(); await deferred.userChoice.catch(() => {}); deferred = null; };
  }
  addEventListener('beforeinstallprompt', (e) => { e.preventDefault(); deferred = e; show('ثبّت NFSsms كتطبيق على جهازك', true); });
  addEventListener('appinstalled', () => { btn?.remove(); deferred = null; });
  // iOS لا يدعم beforeinstallprompt: نعرض تعليمات يدوية
  if (/iphone|ipad|ipod/i.test(navigator.userAgent) && !standalone()) addEventListener('load', () => setTimeout(() => show('للتثبيت: اضغط زر المشاركة ثم «إضافة إلى الشاشة الرئيسية»', false), 2500));
}
