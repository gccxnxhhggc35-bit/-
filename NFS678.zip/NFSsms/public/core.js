// أدوات مشتركة للواجهة
import { appIcon, ico } from './icons.js';
import { localApi, canExport, startBot } from './local-api.js';

export const $ = (s, r = document) => r.querySelector(s);
export const $$ = (s, r = document) => [...r.querySelectorAll(s)];
export const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export const fmt = (n, f = 0) => Number(n || 0).toLocaleString('en', { minimumFractionDigits: f, maximumFractionDigits: f });
export const phone = (n) => '+' + n;
export const tz = () => new Date().getTimezoneOffset();

let onUnauth = () => {};
export const setUnauth = (fn) => { onUnauth = fn; };

// عنوان الخادم: فارغ = نفس الموقع. للاستضافة الثابتة ضع رابط الخادم في config.js (window.NFS_API)
// القيمة 'local' = وضع بدون خادم: الدخول والبيانات داخل المتصفح (انظر local-api.js)
export let LOCAL = String(window.NFS_API || '').trim() === 'local';
const API = LOCAL ? '' : String(window.NFS_API || '').replace(/\/+$/, '');
let TOKEN = null;
try { if (API) TOKEN = localStorage.getItem('nfs_token'); } catch {}
export const setToken = (t) => { TOKEN = t || null; try { if (API) { t ? localStorage.setItem('nfs_token', t) : localStorage.removeItem('nfs_token'); } } catch {} };
const authHeaders = (extra = {}) => ({ ...extra, ...(API && TOKEN ? { Authorization: 'Bearer ' + TOKEN } : {}) });

export async function api(path, { method = 'GET', body } = {}) {
  if (LOCAL) {
    try { return await localApi(path, { method, body }); } catch (e) {
      if (e.status === 401 && !path.endsWith('/login') && !path.endsWith('/me')) onUnauth();
      throw e;
    }
  }
  let res;
  try {
    res = await fetch(API + path, { method, credentials: API ? 'omit' : 'same-origin', headers: authHeaders(body ? { 'Content-Type': 'application/json' } : {}), body: body ? JSON.stringify(body) : undefined });
  } catch {
    throw new Error('تعذر الاتصال بالخادم' + (API ? ' (تأكد من رابط الخادم في config.js وأنه يعمل بـ HTTPS)' : ''));
  }
  // لا تحوّل جلسة Clerk تلقائياً إلى API محلي عند غياب الخادم؛ ذلك كان يؤدي إلى «مسار غير معروف» بعد قبول رمز البريد.
  if (!API && !(res.headers.get('content-type') || '').includes('json')) {
    if (window.NFS_CLERK_PUBLISHABLE_KEY && String(window.NFS_CLERK_PUBLISHABLE_KEY).startsWith('pk_')) {
      throw new Error('تم قبول الطلب لكن خادم NFSsms غير متاح. افتح اللوحة عبر خادم Node أو اضبط رابط الخادم في config.js باستخدام build-static.mjs.');
    }
    LOCAL = true; startBot();
    return api(path, { method, body });
  }
  if (method !== 'GET' && res.headers.get('x-rev')) window.__nfsRev = res.headers.get('x-rev');
  const data = await res.json().catch(() => ({}));
  if (res.status === 401 && !path.endsWith('/login') && !path.endsWith('/me')) onUnauth();
  if (!res.ok) throw new Error(data.error || 'حدث خطأ');
  return data;
}

// تنزيل ملف من الخادم (يعمل مع الدخول بالتوكن أيضاً)
export async function download(path, filename) {
  if (LOCAL) {
    const r = await localApi(path);
    const url = URL.createObjectURL(new Blob(['\ufeff' + r.raw], { type: r.type || 'text/plain' }));
    const a = document.createElement('a'); a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
    return;
  }
  const res = await fetch(API + path, { credentials: API ? 'omit' : 'same-origin', headers: authHeaders() });
  if (!res.ok) throw new Error('تعذر تنزيل الملف');
  const url = URL.createObjectURL(await res.blob());
  const a = document.createElement('a'); a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

/* الوقت */
export function timeAgo(t) {
  const s = Math.max(0, (Date.now() - t) / 1000);
  const f = (n, one, two, few, many) => (n === 1 ? `قبل ${one}` : n === 2 ? `قبل ${two}` : n <= 10 ? `قبل ${n} ${few}` : `قبل ${n} ${many}`);
  if (s < 45) return 'الآن';
  const m = Math.round(s / 60);
  if (m < 60) return f(m, 'دقيقة', 'دقيقتين', 'دقائق', 'دقيقة');
  const h = Math.round(m / 60);
  if (h < 24) return f(h, 'ساعة', 'ساعتين', 'ساعات', 'ساعة');
  const d = Math.round(h / 24);
  if (d < 30) return f(d, 'يوم', 'يومين', 'أيام', 'يوماً');
  return new Date(t).toLocaleDateString('ar-EG-u-nu-latn');
}

/* الإشعار */
let toastTimer;
import { beep } from './prefs.js';
export function toast(msg, kind = '', appKey = null) {
  if (kind === 'ok') beep();
  const t = $('#toast');
  t.className = kind;
  t.innerHTML = `${appKey ? appIcon(appKey, 29) : ''}<span>${esc(msg)}</span>`;
  requestAnimationFrame(() => t.classList.add('on'));
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('on'), 2600);
}

export async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
  } catch {
    const ta = document.createElement('textarea');
    ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.select(); document.execCommand('copy'); ta.remove();
  }
}

/* النوافذ */
let sheetEl = null;
export function openSheet(html, { wide = false } = {}) {
  closeSheet();
  sheetEl = document.createElement('div');
  sheetEl.id = 'sheetw';
  sheetEl.innerHTML = `<div class="sheet glass ${wide ? 'wide' : ''}" role="dialog" aria-modal="true"><div class="grab"></div>${html}</div>`;
  sheetEl.addEventListener('mousedown', (e) => { if (e.target === sheetEl) closeSheet(); });
  document.body.appendChild(sheetEl);
  return sheetEl.firstElementChild;
}
export function closeSheet() { if (sheetEl) { sheetEl.remove(); sheetEl = null; } }
export const sheetOpen = () => !!sheetEl;
export const sheetBody = () => sheetEl?.firstElementChild;
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeSheet(); });

export function confirmBox(title, msg, okLabel = 'تأكيد', danger = true) {
  return new Promise((resolve) => {
    const w = document.createElement('div');
    w.id = 'sheetw'; w.style.zIndex = 70;
    w.innerHTML = `<div class="sheet glass" style="max-width:26rem"><div class="grab"></div><h3>${esc(title)}</h3><p class="mini" style="margin:.5rem 0 1.2rem;font-size:.95rem">${esc(msg)}</p><div style="display:flex;gap:.6rem"><button class="btn ${danger ? '' : 'cool'}" data-ok>${esc(okLabel)}</button><button class="btn s" data-no>إلغاء</button></div></div>`;
    const done = (v) => { w.remove(); resolve(v); };
    w.addEventListener('mousedown', (e) => { if (e.target === w) done(false); });
    w.querySelector('[data-ok]').onclick = () => done(true);
    w.querySelector('[data-no]').onclick = () => done(false);
    document.body.appendChild(w);
  });
}

/* مؤثرات */
export function initFx() {
  document.addEventListener('pointerdown', (e) => {
    const b = e.target.closest('.btn');
    if (!b) return;
    const r = b.getBoundingClientRect(), d = Math.max(r.width, r.height);
    const s = document.createElement('i');
    s.className = 'ripple';
    s.style.cssText = `width:${d}px;height:${d}px;left:${e.clientX - r.left - d / 2}px;top:${e.clientY - r.top - d / 2}px`;
    b.appendChild(s);
    setTimeout(() => s.remove(), 700);
  });
  const sp = $('#sparks');
  const cols = ['#ffb347', '#ff3b5c', '#6ec1ff', '#25d366'];
  for (let i = 0; i < 9; i++) {
    const e = document.createElement('i');
    e.className = 'sparkle';
    e.style.cssText = `left:${(i * 11 + 5) % 100}%;top:${60 + (i * 7) % 40}%;animation-delay:${-i * 1.1}s;animation-duration:${8 + (i % 4) * 2}s;background:${cols[i % 4]};width:${6 + (i % 3) * 3}px;height:${6 + (i % 3) * 3}px`;
    sp.appendChild(e);
  }
}

/* العدّ التصاعدي والحلقات */
export function animateMount(root, quiet = false) {
  $$('[data-count]', root).forEach((el) => {
    const to = +el.dataset.count, f = +el.dataset.f || 0, t0 = performance.now();
    if (!to || quiet) { el.textContent = fmt(to, f); return; }
    const step = (t) => {
      const p = Math.min(1, (t - t0) / 1200);
      el.textContent = fmt(to * (1 - Math.pow(1 - p, 3)), f);
      if (p < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  });
  const apply = () => {
    $$('[data-d]', root).forEach((c) => { if (quiet) c.style.transition = 'none'; c.style.strokeDasharray = c.dataset.d; });
    $$('[data-w]', root).forEach((c) => { if (quiet) c.style.transition = 'none'; c.style.width = c.dataset.w; });
  };
  if (quiet) apply(); else requestAnimationFrame(() => requestAnimationFrame(apply));
}

export function donut(segs, big, small) {
  const total = segs.reduce((a, s) => a + s.v, 0);
  let acc = 0;
  const circles = total ? segs.filter((s) => s.v > 0).map((s) => {
    const pct = (s.v / total) * 100, gap = segs.filter((x) => x.v > 0).length > 1 ? 1.4 : 0;
    const c = `<circle class="seg1" cx="18" cy="18" r="15.9155" stroke="${s.color}" stroke-dasharray="0 100" data-d="${Math.max(0.1, pct - gap)} ${100 - Math.max(0.1, pct - gap)}" stroke-dashoffset="${-acc}"/>`;
    acc += pct;
    return c;
  }).join('') : '';
  return `<div class="donut"><svg viewBox="0 0 36 36"><circle class="bgc" cx="18" cy="18" r="15.9155"/>${circles}</svg><div class="mid"><b data-count="${total}">0</b><small>${esc(small)}</small></div></div>`;
}

export function bars(series) {
  const max = Math.max(1, ...series.map((s) => s.n));
  return `<div class="bars">${series.map((s, i) => {
    const label = new Date(s.day).toLocaleDateString('ar', { weekday: 'short' });
    return `<div title="${s.n}"><em>${s.n}</em><i class="${s.n ? '' : 'zero'}" style="--h:${s.n ? Math.max(10, (s.n / max) * 100) : 3}%;--k:${i}"></i>${esc(label)}</div>`;
  }).join('')}</div>`;
}

export const empty = (illHtml, title, sub = '') => `<div class="empty">${illHtml}<b>${esc(title)}</b><span>${esc(sub)}</span></div>`;
export const skeleton = (n = 4, big = false) => Array.from({ length: n }, () => `<div class="skel ${big ? 'big' : ''}"></div>`).join('');
export { ico };

export { canExport };
export function saveText(text, filename, type = 'text/html') {
  const url = URL.createObjectURL(new Blob([text], { type: type + ';charset=utf-8' }));
  const a = document.createElement('a'); a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}
