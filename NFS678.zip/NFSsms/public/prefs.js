// تفضيلات الواجهة: الثيم والحركة والصوت وحجم الخط. تُحفظ في هذا المتصفح وتُطبَّق فور فتح الصفحة.
export const THEMES = [
  { id: 'ruby', name: 'ياقوت', c: ['#ff3b5c', '#ff8a5c'], rgb: '255,59,92' },
  { id: 'ocean', name: 'محيط', c: ['#2f7bff', '#12c2c9'], rgb: '47,123,255' },
  { id: 'emerald', name: 'زمرد', c: ['#10b36a', '#7bd957'], rgb: '16,179,106' },
  { id: 'amethyst', name: 'جمشت', c: ['#8f5bff', '#e05cff'], rgb: '143,91,255' },
  { id: 'amber', name: 'عنبر', c: ['#ff9f1a', '#ff5e3a'], rgb: '255,159,26' },
  { id: 'night', name: 'ليل', c: ['#7c6cff', '#2fd4ff'], rgb: '124,108,255', dark: true },
];
const KEY = 'nfs_prefs', P = { theme: 'ruby', motion: true, sound: true, size: 1 };
try { Object.assign(P, JSON.parse(localStorage.getItem(KEY) || '{}')); } catch { /* تجاهل */ }
export const getPrefs = () => P;
export function applyPrefs() {
  const t = THEMES.find((x) => x.id === P.theme) || THEMES[0], r = document.documentElement;
  r.dataset.theme = t.id; r.dataset.motion = P.motion ? 'on' : 'off';
  r.style.setProperty('--red', t.c[0]); r.style.setProperty('--orange', t.c[1]); r.style.setProperty('--rr', t.rgb);
  r.style.fontSize = Math.round(P.size * 100) + '%';
  document.querySelector('meta[name=theme-color]')?.setAttribute('content', t.dark ? '#14122b' : '#fffaf5');
}
export function setPref(k, v) { P[k] = v; try { localStorage.setItem(KEY, JSON.stringify(P)); } catch { /* تجاهل */ } applyPrefs(); }
export function beep() {
  if (!P.sound) return;
  try { const c = new (window.AudioContext || window.webkitAudioContext)(), o = c.createOscillator(), g = c.createGain(); o.type = 'sine'; o.frequency.value = 880;
    g.gain.setValueAtTime(0.0001, c.currentTime); g.gain.exponentialRampToValueAtTime(0.15, c.currentTime + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, c.currentTime + 0.35);
    o.connect(g); g.connect(c.destination); o.start(); o.stop(c.currentTime + 0.4); } catch { /* تجاهل */ }
}
applyPrefs();
