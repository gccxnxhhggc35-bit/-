// رسومات التطبيقات والأيقونات والرسوم التوضيحية (SVG مدمجة، بدون إيموجي)

export const APP_NAMES = {
  wa: 'واتساب', tg: 'تيليجرام', fb: 'فيسبوك', ig: 'انستغرام', tt: 'تيك توك', sn: 'سناب شات',
  im: 'إيمو', yt: 'يوتيوب', go: 'جوجل', x: 'إكس (تويتر)', vb: 'فايبر', ds: 'ديسكورد', ot: 'أخرى',
};
export const APP_KEYS = Object.keys(APP_NAMES);
export const APP_COLORS = {
  wa: '#25d366', tg: '#2aabee', fb: '#1877f2', ig: '#d62976', tt: '#ff2d55', sn: '#f7c800',
  im: '#1a9bf0', yt: '#ff0033', go: '#4285f4', x: '#3b3b46', vb: '#7360f2', ds: '#5865f2', ot: '#8a93a6',
};

const grad = (id, a, b, x2 = 1, y2 = 1) =>
  `<linearGradient id="${id}" x1="0" y1="0" x2="${x2}" y2="${y2}"><stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${b}"/></linearGradient>`;
const tile = (id) => `<rect width="64" height="64" rx="16" fill="url(#${id})"/>`;
const HANDSET = 'M24.8 22.5c-.7 0-1.600.3-2.300 1.100-1.300 1.400-1.700 3.400-.3 5.700 2 3.400 4.900 6.200 8.500 7.800 2.500 1.100 4.700.7 5.800-.6.800-.9.900-1.800.6-2.200l-3.500-1.800c-.5-.3-1.100 0-1.400.5l-.9 1.100c-.3.3-.7.4-1.100.2-1.700-.7-3.900-2.600-5-4.800-.1-.4 0-.7.200-1l1-1.100c.3-.4.400-.9.200-1.300l-1.700-3.500c-.2-.4-.5-.5-.9-.5z';

const APP_ART = {
  wa: grad('g-wa', '#5cf08a', '#0f9d4d') + tile('g-wa') +
    '<path d="M32 13.500c-10.200 0-18.500 8.200-18.500 18.300 0 3.300.9 6.400 2.500 9.100l-2.500 9.600 9.900-2.500c2.600 1.400 5.500 2.200 8.600 2.200 10.200 0 18.500-8.200 18.500-18.300S42.200 13.500 32 13.500z" fill="#fff"/>' +
    `<path d="${HANDSET}" fill="#17ae57"/>`,
  tg: grad('g-tg', '#3bb4ea', '#1c8fc7') + tile('g-tg') +
    '<path d="M47.500 17.500L14.200 30.300c-1.600.6-1.500 1.700-.3 2.100l8.500 2.600 3.200 9.800c.4 1.100.7 1.200 1.700.8l4.700-3.900 8.700 6.400c1.600.9 2.700.4 3.100-1.500l5.700-26.800c.5-2.100-.8-3-2.700-2.300z" fill="#fff"/><path d="M24.600 36.500l15.400-9.800-10.800 11.900-.5 6.200z" fill="#c6d9e8"/>',
  fb: grad('g-fb', '#3d97ff', '#0a58d2') + tile('g-fb') +
    '<path d="M35.500 52V35h5.600l.9-6.600h-6.500v-4.200c0-1.900.6-3.200 3.300-3.200h3.500v-5.900c-.6-.1-2.700-.3-5.100-.3-5 0-8.500 3.100-8.500 8.700v4.900H18v6.600h5.700V52z" fill="#fff"/>',
  ig: grad('g-ig', '#fdc468', '#4f5bd5', 1, 1).replace('<stop offset="1"', '<stop offset=".35" stop-color="#e1306c"/><stop offset=".7" stop-color="#b02fb7"/><stop offset="1"') + tile('g-ig') +
    '<rect x="16" y="16" width="32" height="32" rx="10" fill="none" stroke="#fff" stroke-width="3.600"/><circle cx="32" cy="32" r="7.500" fill="none" stroke="#fff" stroke-width="3.600"/><circle cx="41.500" cy="22.500" r="2.300" fill="#fff"/>',
  tt: '<rect width="64" height="64" rx="16" fill="#0d0d12"/>' + ['#25f4ee:-1.800:-1.400', '#fe2c55:1.800:1.400', '#ffffff:0:0'].map((s) => {
    const [c, dx, dy] = s.split(':');
    return `<path transform="translate(${dx} ${dy})" fill="${c}" d="M35 14h5.200c.3 4 2.800 6.800 6.800 7.300v5.300c-2.500.1-4.800-.7-6.800-2.100v10.600c0 6.600-5.300 10.400-10.700 10.400-5.600 0-9.800-4.200-9.800-9.600 0-6.100 5.200-10.300 11.300-9.600v5.500c-3-.7-6 .9-6 4.100 0 2.600 2 4.300 4.400 4.300 2.700 0 4.600-1.900 4.600-5.100z"/>`;
  }).join(''),
  sn: '<rect width="64" height="64" rx="16" fill="#fffc00"/>' +
    '<path d="M32 15c-5 0-8.500 3.800-8.500 8.800 0 1.500.2 2.700.3 4-.8.2-1.700.2-2.500.1-.8 0-1.400.8-.8 1.400 1 .9 2.300 1.300 3.400 1.700-.2 1.200-1.600 2.600-3.300 3.400-.8.4-.6 1.400.3 1.700 1.500.5 3.200.5 4.200 1.200.6.4.7 1.500 1.500 1.900 1.300.6 2.800-.7 5.400-.7s4.100 1.300 5.400.7c.8-.4.9-1.500 1.500-1.900 1-.7 2.700-.7 4.200-1.200.9-.3 1.100-1.300.3-1.700-1.700-.8-3.100-2.200-3.300-3.400 1.100-.4 2.400-.8 3.400-1.700.6-.6 0-1.400-.8-1.400-.8.1-1.700.1-2.500-.1.1-1.300.3-2.500.3-4C40.500 18.800 37 15 32 15z" fill="#fff" stroke="#16161d" stroke-width="2.200" stroke-linejoin="round"/>',
  im: grad('g-im', '#35bcff', '#0a74cf') + tile('g-im') +
    '<path d="M32 14c-10.500 0-19 7.500-19 16.800 0 5 2.500 9.400 6.400 12.500L17 50l8-3.300c2.200.6 4.400.9 7 .9 10.500 0 19-7.500 19-16.800S42.500 14 32 14z" fill="#fff"/><text x="32" y="36.500" text-anchor="middle" font-family="Arial,sans-serif" font-weight="800" font-size="15" fill="#0a74cf">imo</text>',
  yt: grad('g-yt', '#ff3b3b', '#c4001a') + tile('g-yt') +
    '<rect x="11" y="18" width="42" height="28" rx="9" fill="#fff"/><path d="M28 25.500v13l11.500-6.500z" fill="#e60023"/>',
  go: '<rect width="64" height="64" rx="16" fill="#fff"/><rect x=".75" y=".75" width="62.500" height="62.500" rx="15.300" fill="none" stroke="#e3e6ee" stroke-width="1.500"/>' +
    '<linearGradient id="g-go" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#4285f4"/><stop offset=".35" stop-color="#ea4335"/><stop offset=".65" stop-color="#fbbc05"/><stop offset="1" stop-color="#34a853"/></linearGradient>' +
    '<text x="32" y="46" text-anchor="middle" font-family="Arial,sans-serif" font-weight="800" font-size="40" fill="url(#g-go)">G</text>',
  x: grad('g-x', '#2a2a30', '#050507') + tile('g-x') +
    '<path d="M19 17.500h7.800l7.800 10.600L44 17.500h3.500L36.400 30.300 47.500 46.500h-7.800l-8.400-11.300L21.600 46.500h-3.500L29.500 33z" fill="#fff"/>',
  vb: grad('g-vb', '#9a82ff', '#5636c0') + tile('g-vb') +
    '<path d="M32 13c-10.500 0-19 7-19 16 0 5.200 2.800 9.800 7.200 12.800V50l6.800-4.200c1.600.3 3.200.5 5 .5 10.500 0 19-7 19-16S42.500 13 32 13z" fill="#fff"/>' + `<path transform="translate(1 -1)" d="${HANDSET}" fill="#6a49d8"/>`,
  ds: grad('g-ds', '#7480ff', '#4450df') + tile('g-ds') +
    '<path d="M44 20c-2-1-4-1.600-6.300-2l-.8 1.600c-2-.3-3.900-.3-5.800 0L30.300 18c-2.300.4-4.300 1-6.300 2-4 6-5 11.700-4.500 17.200 2.400 1.800 5 2.900 7.600 3.600l1.600-2.600c-.9-.3-1.700-.7-2.500-1.200l.6-.5c4.800 2.200 10 2.200 14.800 0l.6.500c-.8.500-1.600.9-2.500 1.200l1.600 2.600c2.600-.7 5.200-1.800 7.600-3.600.6-6.400-1-12-4.500-17.200z" fill="#fff"/><circle cx="27.500" cy="31" r="2.800" fill="#5662e8"/><circle cx="36.500" cy="31" r="2.800" fill="#5662e8"/>',
  ot: grad('g-ot', '#8e98ad', '#4b5469') + tile('g-ot') +
    '<path d="M32 15c-9.400 0-17 6.600-17 14.800 0 4.500 2.300 8.500 5.900 11.200L19.500 49l7.600-3.200c1.600.4 3.200.6 4.900.6 9.400 0 17-6.600 17-14.800S41.400 15 32 15z" fill="#fff"/><circle cx="24.500" cy="30.500" r="2.400" fill="#5b6479"/><circle cx="32" cy="30.500" r="2.400" fill="#5b6479"/><circle cx="39.500" cy="30.500" r="2.400" fill="#5b6479"/>',
  // أيقونات اللوحات
  pn_prime: grad('g-pp', '#1b2a52', '#0b1226') + tile('g-pp') +
    '<path d="M32 12l17 9.800v19.600L32 52 15 41.400V21.800z" fill="none" stroke="#5be0c3" stroke-width="3" stroke-linejoin="round"/><path d="M27 41V23h8.500a5.500 5.500 0 010 11H27" fill="none" stroke="#fff" stroke-width="3.400" stroke-linecap="round" stroke-linejoin="round"/>',
  pn_thirdwave: grad('g-pt', '#27c1e6', '#1566d6') + tile('g-pt') +
    '<path d="M12 26c5-6 9-6 13 0s8 6 13 0 9-6 14 0M12 36c5-6 9-6 13 0s8 6 13 0 9-6 14 0M12 46c5-6 9-6 13 0s8 6 13 0 9-6 14 0" fill="none" stroke="#fff" stroke-width="3.400" stroke-linecap="round" opacity=".95"/>',
  pn_royal: grad('g-pr', '#ffd35a', '#e08a12') + tile('g-pr') +
    '<path d="M14 46h36l2-22-10 8-10-14-10 14-10-8z" fill="#fff"/><rect x="14" y="48" width="36" height="4.500" rx="2.200" fill="#fff"/><circle cx="32" cy="16" r="2.600" fill="#fff"/>',
  pn_generic: grad('g-pg', '#5b6b8c', '#2e3a55') + tile('g-pg') +
    '<path d="M20 36a17 17 0 0124 0M25.500 41a9 9 0 0113 0" fill="none" stroke="#fff" stroke-width="3.400" stroke-linecap="round"/><circle cx="32" cy="46.500" r="3" fill="#5be0c3"/><path d="M14 28a25 25 0 0136 0" fill="none" stroke="#fff" stroke-width="3.400" stroke-linecap="round" opacity=".5"/>',
};

const UI = {
  api: '<path d="M8 4c-2 0-3 1-3 3v2c0 1.2-1 3-2.5 3 1.500 0 2.500 1.800 2.500 3v2c0 2 1 3 3 3M16 4c2 0 3 1 3 3v2c0 1.200 1 3 2.500 3-1.500 0-2.500 1.800-2.500 3v2c0 2-1 3-3 3"/>',
  apps: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
  mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
  // Lucide headset glyph (ISC): https://lucide.dev/icons/headset
  chat: '<path d="M3 14v-3a9 9 0 0 1 18 0v3"/><path d="M3 14h4v5H5a2 2 0 0 1-2-2z"/><path d="M21 14h-4v5h2a2 2 0 0 0 2-2z"/><path d="M7 19v1a3 3 0 0 0 3 3h4"/>',
  home: '<path d="M3 11l9-8 9 8v9a1 1 0 01-1 1h-5v-6H9v6H4a1 1 0 01-1-1z"/>',
  codes: '<path d="M21 12a8.500 8.500 0 01-12.200 7.600L3.500 21l1.400-4.900A8.500 8.500 0 1121 12z"/><path d="M8.500 12h.01M12 12h.01M15.500 12h.01" stroke-width="2.600"/>',
  doms: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 010 18M12 3a14 14 0 000 18"/>',
  users: '<circle cx="9" cy="8" r="3.500"/><path d="M2.500 20a6.500 6.500 0 0113 0"/><circle cx="17.500" cy="9" r="2.500"/><path d="M17 14.500a5 5 0 014.500 5"/>',
  panels: '<rect x="3" y="4" width="18" height="6.500" rx="2"/><rect x="3" y="13.500" width="18" height="6.500" rx="2"/><path d="M7 7.250h.01M7 16.750h.01M11 7.250h6M11 16.750h6"/>',
  me: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0116 0"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  upload: '<path d="M12 16V4M7 9l5-5 5 5M4 16v3a1 1 0 001 1h14a1 1 0 001-1v-3"/>',
  download: '<path d="M12 4v12M7 11l5 5 5-5M4 20h16"/>',
  copy: '<rect x="9" y="9" width="11" height="11" rx="2.500"/><path d="M5 15V6a2 2 0 012-2h9"/>',
  check: '<path d="M4.500 12.500l5 5 10-11"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.500-3.500"/>',
  trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 12a2 2 0 002 2h6a2 2 0 002-2l1-12M9 7V4h6v3"/>',
  edit: '<path d="M4 20h4L19 9a2.800 2.800 0 00-4-4L4 16z"/><path d="M13.500 6.500l4 4"/>',
  logout: '<path d="M15 4h3a2 2 0 012 2v12a2 2 0 01-2 2h-3M10 8l-4 4 4 4M6 12h10"/>',
  bolt: '<path d="M13 2L4 14h7l-1 8 9-12h-7z"/>',
  megaphone: '<path d="M3 10.500v3a1 1 0 001 1h2.500l5.500 4.500V5L6.500 9.500H4a1 1 0 00-1 1z"/><path d="M16 9a4.500 4.500 0 010 6M18.800 6a8.500 8.500 0 010 12"/>',
  refresh: '<path d="M20 11a8 8 0 00-14.500-3.500L4 9M4 4v5h5M4 13a8 8 0 0014.500 3.500L20 15M20 20v-5h-5"/>',
  signal: '<path d="M4 18h.01M8 18v-4M12 18V10M16 18V6M20 18V3"/>',
  phone: '<rect x="6.500" y="2.500" width="11" height="19" rx="3"/><path d="M11 18.500h2"/>',
  eye: '<path d="M2 12s3.600-7 10-7 10 7 10 7-3.600 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  eyeoff: '<path d="M3 3l18 18M10.600 6.100A9.800 9.800 0 0112 6c6.400 0 10 6 10 6a17 17 0 01-3.200 3.800M6.600 7.600C3.800 9.300 2 12 2 12s3.600 7 10 7c1.600 0 3-.4 4.300-1M9.900 9.900a3 3 0 004.200 4.200"/>',
  close: '<path d="M6 6l12 12M18 6L6 18"/>',
  key: '<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M16 7l3 3M14 9l2 2"/>',
  chart: '<path d="M4 20V10M10 20V4M16 20v-8M22 20H2"/>',
  wallet: '<path d="M3 7a2 2 0 012-2h13v4"/><rect x="3" y="7" width="18" height="13" rx="3"/><circle cx="16.500" cy="13.500" r="1.200"/>',
  inbox: '<path d="M3 13l3-8h12l3 8v5a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><path d="M3 13h5l1.500 2.500h5L16 13h5"/>',
  link: '<path d="M10 14a4 4 0 005.700 0l3-3a4 4 0 00-5.700-5.700l-1 1M14 10a4 4 0 00-5.700 0l-3 3a4 4 0 005.700 5.700l1-1"/>',
  userplus: '<circle cx="10" cy="8" r="4"/><path d="M3 21a7 7 0 0112-4.900M19 8v6M16 11h6"/>',
  shield: '<path d="M12 3l8 3v6c0 4.500-3.400 8-8 9-4.600-1-8-4.500-8-9V6z"/><path d="M8.500 12l2.500 2.500 4.500-5"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  lock: '<rect x="4.500" y="10.500" width="15" height="10" rx="3"/><path d="M8 10.500V8a4 4 0 018 0v2.500"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0116 0"/>',
  hash: '<path d="M5 9h15M4 15h15M10 3L8 21M16 3l-2 21"/>',
  play: '<path d="M7 4.500v15l12-7.500z"/>',
  sliders: '<path d="M4 7h10M18 7h2M4 17h2M10 17h10M14 4v6M6 14v6"/>',
  file: '<path d="M14 3H7a2 2 0 00-2 2v14a2 2 0 002 2h10a2 2 0 002-2V8z"/><path d="M14 3v5h5M9 13h6M9 17h4"/>',
  tag: '<path d="M3 12V4h8l10 10-8 8z"/><circle cx="7.500" cy="8.500" r="1.200"/>',
  ban: '<circle cx="12" cy="12" r="9"/><path d="M5.600 5.600l12.800 12.800"/>',
  crown: '<path d="M4 18l-1.500-9 5.500 4 4-7 4 7 5.500-4L20 18z"/>',
  alert: '<circle cx="12" cy="12" r="9"/><path d="M12 8v5M12 16.5h.01"/>',
  chevron: '<path d="m9 18 6-6-6-6"/>',
  arrowright: '<path d="M5 12h14M13 6l6 6-6 6"/>',
  arrowupleft: '<path d="M7 17V7h10M7 7l10 10"/>',
  cornerdownleft: '<path d="M19 7v5a4 4 0 0 1-4 4H5M12 10l-7 6 7 6"/>',
  messagesquare: '<path d="M21 11.5a8.4 8.4 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.4 8.4 0 0 1-3.8-.9L3 21l1.9-5.7a8.4 8.4 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.4 8.4 0 0 1 3.8-.9h.5a8.5 8.5 0 0 1 8 8z"/>',
};

export function sprite() {
  const apps = Object.entries(APP_ART).map(([k, v]) => `<symbol id="app-${k}" viewBox="0 0 64 64">${v}</symbol>`).join('');
  const ui = Object.entries(UI).map(([k, v]) => `<symbol id="i-${k}" viewBox="0 0 24 24">${v}</symbol>`).join('');
  const shared = '<linearGradient id="il1" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ff3b5c"/><stop offset="1" stop-color="#ff8a5c"/></linearGradient>';
  return `<svg width="0" height="0" style="position:absolute" aria-hidden="true"><defs>${shared}${apps}${ui}</defs></svg>`;
}

export const ico = (k, cls = '') => `<svg class="i ${cls}" aria-hidden="true"><use href="#i-${k}"/></svg>`;
export const appIcon = (k, size = 44, cls = '') => {
  const key = APP_ART[k] ? k : 'ot';
  return `<span class="app ${cls}" style="--s:${size}px" title="${APP_NAMES[key] || ''}"><svg viewBox="0 0 64 64"><use href="#app-${key}"/></svg></span>`;
};
export const panelIcon = (p, size = 48) => {
  const key = /prime/i.test(p.name + p.id) || p.type === 'primehub' ? 'pn_prime' : /third/i.test(p.name + p.id) ? 'pn_thirdwave' : /royal/i.test(p.name + p.id) ? 'pn_royal' : 'pn_generic';
  return `<span class="app" style="--s:${size}px"><svg viewBox="0 0 64 64"><use href="#app-${key}"/></svg></span>`;
};

/* رسوم توضيحية متحركة للحالات الفارغة */
export const ill = {
  inbox: `<svg class="ill" viewBox="0 0 200 150" aria-hidden="true">
    <ellipse class="il-shadow" cx="100" cy="132" rx="46" ry="7" fill="#1a1a2e" opacity=".08"/>
    <g class="il-float"><rect x="48" y="42" width="104" height="72" rx="14" fill="#fff" stroke="#ffd2da" stroke-width="2"/><path d="M52 52l48 34 48-34" fill="none" stroke="url(#il1)" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
    <rect x="70" y="26" width="60" height="36" rx="10" fill="url(#il1)" class="il-pop"/><text x="100" y="50" text-anchor="middle" font-family="TD,sans-serif" font-weight="900" font-size="17" fill="#fff" letter-spacing="3">• • • •</text></g>
    <circle class="il-spark s1" cx="40" cy="40" r="4" fill="#ffb347"/><circle class="il-spark s2" cx="162" cy="56" r="3" fill="#6ec1ff"/><circle class="il-spark s3" cx="150" cy="24" r="2.500" fill="#ff3b5c"/></svg>`,
  phone: `<svg class="ill" viewBox="0 0 200 150" aria-hidden="true"><ellipse class="il-shadow" cx="100" cy="134" rx="40" ry="6" fill="#1a1a2e" opacity=".08"/>
    <g class="il-float"><rect x="70" y="14" width="60" height="112" rx="14" fill="#fff" stroke="#ffd2da" stroke-width="2"/><rect x="78" y="26" width="44" height="84" rx="8" fill="#fff4f6"/>
    <circle cx="100" cy="68" r="16" fill="url(#il1)" class="il-pop"/><path d="M100 60v16M92 68h16" stroke="#fff" stroke-width="4" stroke-linecap="round"/><rect x="92" y="117" width="16" height="3" rx="1.500" fill="#ffd2da"/></g>
    <circle class="il-spark s1" cx="52" cy="50" r="4" fill="#25d366"/><circle class="il-spark s2" cx="150" cy="40" r="3" fill="#2aabee"/><circle class="il-spark s3" cx="146" cy="96" r="3" fill="#ffb347"/></svg>`,
  globe: `<svg class="ill" viewBox="0 0 200 150" aria-hidden="true"><ellipse class="il-shadow" cx="100" cy="134" rx="44" ry="6" fill="#1a1a2e" opacity=".08"/>
    <g class="il-float"><circle cx="100" cy="68" r="46" fill="#fff" stroke="#ffd2da" stroke-width="2"/><ellipse cx="100" cy="68" rx="20" ry="46" fill="none" stroke="#ffc1cc" stroke-width="2.500"/><path d="M56 52h88M54 84h92M100 22v92" stroke="#ffc1cc" stroke-width="2.500" fill="none"/></g>
    <g class="il-orbit"><circle cx="100" cy="14" r="7" fill="url(#il1)"/></g></svg>`,
  users: `<svg class="ill" viewBox="0 0 200 150" aria-hidden="true"><ellipse class="il-shadow" cx="100" cy="134" rx="52" ry="6" fill="#1a1a2e" opacity=".08"/>
    <g class="il-float"><circle cx="100" cy="52" r="20" fill="url(#il1)"/><path d="M62 112a38 30 0 0176 0z" fill="url(#il1)"/><circle cx="52" cy="66" r="14" fill="#ffd2da"/><path d="M26 112a26 22 0 0152 0z" fill="#ffd2da"/><circle cx="148" cy="66" r="14" fill="#cfe6ff"/><path d="M122 112a26 22 0 0152 0z" fill="#cfe6ff"/></g></svg>`,
  hero: `<svg class="ill hero-phone" viewBox="0 0 220 300" aria-hidden="true"><defs><linearGradient id="hp1" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ff3b5c"/><stop offset="1" stop-color="#ff8a5c"/></linearGradient><linearGradient id="hp2" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#25203a"/><stop offset="1" stop-color="#14122a"/></linearGradient></defs>
    <rect x="30" y="12" width="160" height="276" rx="30" fill="url(#hp2)"/><rect x="38" y="22" width="144" height="256" rx="23" fill="#fff8f5"/><rect x="88" y="28" width="44" height="8" rx="4" fill="#14122a"/>
    <g class="hp-b1"><rect x="52" y="62" width="104" height="46" rx="16" fill="#fff" stroke="#ffe0e6"/><circle cx="72" cy="85" r="10" fill="#25d366"/><rect x="88" y="76" width="52" height="7" rx="3.500" fill="#e8e8f0"/><rect x="88" y="90" width="34" height="7" rx="3.500" fill="#f0f0f6"/></g>
    <g class="hp-b2"><rect x="64" y="124" width="104" height="58" rx="18" fill="url(#hp1)"/><text class="hp-c c1" x="116" y="160" text-anchor="middle" font-family="TD,sans-serif" font-weight="900" font-size="20" fill="#fff" letter-spacing="3">482 913</text><text class="hp-c c2" x="116" y="160" text-anchor="middle" font-family="TD,sans-serif" font-weight="900" font-size="20" fill="#fff" letter-spacing="3">207 645</text><text class="hp-c c3" x="116" y="160" text-anchor="middle" font-family="TD,sans-serif" font-weight="900" font-size="20" fill="#fff" letter-spacing="3">731 058</text></g>
    <g class="hp-b3"><rect x="52" y="198" width="96" height="40" rx="15" fill="#fff" stroke="#ffe0e6"/><circle cx="70" cy="218" r="9" fill="#2aabee"/><rect x="85" y="210" width="46" height="7" rx="3.500" fill="#e8e8f0"/><rect x="85" y="223" width="28" height="6" rx="3" fill="#f0f0f6"/></g>
    <rect x="86" y="260" width="48" height="5" rx="2.500" fill="#e2dce4"/></svg>`,
};
