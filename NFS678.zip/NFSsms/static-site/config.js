window.NFS_API = "local";
window.NFS_CLERK_PUBLISHABLE_KEY = "pk_test_ZmlybS1oaXBwby00MTExLmNsZXJrLmFjY291bnRzLmRldiQ";
window.NFS_SUPABASE_KEY = "sb_publishable_vYDZRPlJ8EW4r-xoClsVJQ_mjWPoxEZ";
window.NFS_SUPABASE_URL = "https://ilhmquzuenmslamqzyuw.supabase.co";
window.NFS_SYNC = "";
