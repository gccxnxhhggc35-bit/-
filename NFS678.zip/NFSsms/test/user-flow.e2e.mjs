// مسار المستخدم كاملاً: طلب أرقام ← موافقة ← وصول الكود لمتصفح صاحب الرقم فقط
import http from 'node:http'; import { spawn } from 'node:child_process'; import fs from 'node:fs'; import os from 'node:os'; import path from 'node:path'; import crypto from 'node:crypto'; import assert from 'node:assert/strict';
const { chromium } = await import(process.env.PW_MODULE || '/home/claude/.npm-global/lib/node_modules/playwright/index.mjs');
const ROOT = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'nfsu-')); const msgs = [];
const panel = http.createServer((q, r) => { r.writeHead(200, { 'Content-Type': 'application/json' }); r.end(JSON.stringify({ data: msgs })); });
await new Promise((r) => panel.listen(0, r));
const PORT = 4300 + Math.floor(Math.random() * 80), base = `http://127.0.0.1:${PORT}`;
const sha = (t) => crypto.createHash('sha256').update(t).digest('hex');
const tokA = 'tokA' + 'a'.repeat(60), tokB = 'tokB' + 'b'.repeat(60);
const mk = (id, u, n) => ({ id, username: u, name: n, role: 'user', disabled: false, createdAt: Date.now() });
fs.writeFileSync(path.join(dir, 'core.json'), JSON.stringify({ users: [mk(1000, 'ahmed', 'أحمد'), mk(1001, 'sara', 'سارة')], domains: [], requests: [], panels: [{ id: 'mock', name: 'Mock', type: 'generic', url: `http://127.0.0.1:${panel.address().port}`, key: 'k', path: '/m', authHeader: 'X-API-Key', authScheme: '', enabled: true }],
  sessions: { [sha(tokA)]: { userId: 1000, exp: Date.now() + 1e9 }, [sha(tokB)]: { userId: 1001, exp: Date.now() + 1e9 } },
  settings: { activePanel: 'mock', botOn: true, pollSeconds: 3, pricePerCode: 0 }, seq: { user: 1001, domain: 0, request: 0, panel: 0, announcement: 0 }, announcements: [] }));
const srv = spawn('node', ['server.js'], { cwd: ROOT, env: { ...process.env, CLERK_SECRET_KEY: '', DATA_DIR: dir, PORT: String(PORT) }, stdio: 'pipe' });
await new Promise((r) => setTimeout(r, 1500));
const call = async (t, p, m = 'GET', b) => { const r = await fetch(base + p, { method: m, headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${t}` }, body: b ? JSON.stringify(b) : undefined }); const j = await r.json(); if (!r.ok) throw new Error(p + ' ' + j.error); return j; };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const owner = (await (await fetch(base + '/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: 'saleh', password: 'saleh' }) })).json()).token;
const dom = (await call(owner, '/api/domains', 'POST', { name: 'sy', apps: ['wa'], access: '*' })).item.id;
await call(owner, `/api/domains/${dom}/numbers/import`, 'POST', { text: '963944000001\n963944000002\n963944000003\n963944000004' });

// المتصفحان: أحمد (Chromium 141) وسارة (Chrome 131)
const open = async (opts, tok) => { const br = await chromium.launch(opts); const ctx = await br.newContext({ viewport: { width: 390, height: 800 }, locale: 'ar' }); await ctx.addCookies([{ name: 'nfs_sid', value: tok, url: base }]); const page = await ctx.newPage(); const errs = []; page.on('pageerror', (e) => errs.push(String(e))); await page.route('**/config.js', (r) => r.fulfill({ contentType: 'text/javascript', body: "window.NFS_API='';" })); await page.goto(base); await page.waitForSelector('#main'); return { br, page, errs }; };
const A = await open({}, tokA), B = await open({ executablePath: '/home/claude/.cache/puppeteer/chrome/linux-131.0.6778.204/chrome-linux64/chrome' }, tokB);
const txt = (s) => s.page.evaluate(() => document.querySelector('#main').innerText);

// 1) أحمد يطلب رقمين، سارة رقماً واحداً؛ المشرف يوافق
await call(tokA, '/api/requests', 'POST', { domainId: dom, app: 'wa', count: 2 });
await call(tokB, '/api/requests', 'POST', { domainId: dom, app: 'wa', count: 1 });
const reqs = (await call(owner, '/api/requests')).items.filter((r) => r.status === 'pending'); assert.equal(reqs.length, 2);
for (const r of reqs) await call(owner, `/api/requests/${r.id}/decide`, 'POST', { accept: true });
const mineA = (await call(tokA, '/api/my/numbers')).items.map((x) => x.n), mineB = (await call(tokB, '/api/my/numbers')).items.map((x) => x.n);
assert.equal(mineA.length, 2); assert.equal(mineB.length, 1); assert.equal(mineA.filter((n) => mineB.includes(n)).length, 0);
console.log('✔ الموافقة وزّعت الأرقام: أحمد', mineA.length, '، سارة', mineB.length, '(بدون تداخل)');

// 2) متصفح كل مستخدم يعرض أرقامه الجديدة تلقائياً بعد الموافقة
await A.page.click('#nav .nv[data-t="doms"]'); await B.page.click('#nav .nv[data-t="doms"]'); await sleep(1200);

// 3) تصل رسائل لرقم أحمد ولرقم سارة (ساعة اللوحة متقدمة 3 ساعات) ثم رقم غير موزَّع
await call(owner, '/api/bot/run', 'POST'); await sleep(300);
msgs.push({ id: 'a1', number: '+' + mineA[0], sender: 'WhatsApp', content: 'Your WhatsApp code: 111-222', time: Date.now() + 3 * 3600e3 });
msgs.push({ id: 'b1', number: mineB[0], sender: 'WhatsApp', content: 'Your WhatsApp code: 333-444', time: Date.now() - 3 * 3600e3 });
msgs.push({ id: 'u1', number: '963944000004', sender: 'WhatsApp', content: 'Your WhatsApp code: 999-888', time: Date.now() });
await call(owner, '/api/bot/run', 'POST');
await A.page.click('#nav .nv[data-t="codes"]'); await B.page.click('#nav .nv[data-t="codes"]');
const t0 = Date.now(); let ok = { A: 0, B: 0 };
while (Date.now() - t0 < 15000 && !(ok.A && ok.B)) { for (const [k, s, c] of [['A', A, '111222'], ['B', B, '333444']]) if (!ok[k] && (await txt(s)).includes(c)) ok[k] = Date.now() - t0; await sleep(250); }
const ta = await txt(A), tb = await txt(B);
console.log('✔ كود أحمد وصل لمتصفحه (ms):', ok.A, '| كود سارة وصل لمتصفحها (ms):', ok.B);
assert.ok(ok.A && ok.B); assert.ok(!ta.includes('333444') && !ta.includes('999888'), 'أحمد لا يرى كود غيره'); assert.ok(!tb.includes('111222') && !tb.includes('999888'), 'سارة لا ترى كود غيرها');
console.log('✔ لا يرى أي مستخدم كود غيره، ولا كود رقم غير موزَّع');
// 4) رقم أُرجع للمخزون ثم وُزّع لشخص آخر: لا تنتقل الأكواد القديمة
const rel = (await call(owner, `/api/users/1000/numbers`)).items[0]; await call(owner, '/api/numbers/release', 'POST', { ids: [rel.id] });
assert.equal((await call(tokA, '/api/codes')).items.some((i) => i.c === '111222') && (await call(tokA, '/api/my/numbers')).items.some((x) => x.id === rel.id), false);
console.log('✔ بعد إرجاع الرقم للمخزون لا يبقى كوده لدى صاحبه السابق');

// 5) التواصل: المستخدم يرسل من متصفحه، فتصل للمدير، والرد يعود (واجهة حقيقية)
const adm = await (async () => { const br = await chromium.launch(); const ctx = await br.newContext({ viewport: { width: 390, height: 800 }, locale: 'ar' }); await ctx.addCookies([{ name: 'nfs_sid', value: owner, url: base }]); const page = await ctx.newPage(); await page.route('**/config.js', (r) => r.fulfill({ contentType: 'text/javascript', body: "window.NFS_API='';" })); await page.goto(base); await page.waitForSelector('#main'); return { br, page }; })();
await A.page.click('#nav .nv[data-t="chat"]'); await sleep(900);
await A.page.fill('#cxin', 'السلام عليكم، لم يصلني كود الرقم'); await A.page.click('.cx-send');
await sleep(300); await A.page.screenshot({ path: '/home/claude/shots/chat-user-sending.png' });
await adm.page.click('#nav .nv[data-t="chat"]');
const tt = Date.now(); while (Date.now() - tt < 15000 && !(await adm.page.locator('.th').count())) await sleep(300);
assert.ok(await adm.page.locator('.th').count(), 'الرسالة وصلت لصندوق الدعم');
await adm.page.click('.th'); await sleep(900); await adm.page.fill('#cxin', 'أهلاً بك، تم التحقق وسنساعدك الآن'); await adm.page.click('.cx-send');
const t2 = Date.now(); while (Date.now() - t2 < 15000 && !(await A.page.locator('.cm.them').count())) await sleep(300);
assert.ok(await A.page.locator('.cm.them').count(), 'رد الدعم وصل لمتصفح المستخدم');
await sleep(500); await A.page.screenshot({ path: '/home/claude/shots/chat-user-reply.png' }); await adm.page.screenshot({ path: '/home/claude/shots/chat-admin.png' });
console.log('✔ التواصل: رسالة المستخدم وصلت للدعم، والرد وصل للمستخدم، في متصفحين حقيقيين');

// 6) مرفق صورة: القائمة (+) ثم إرفاق وإرسال، فتصل للدعم بملف حقيقي
await A.page.click('#cxplus'); await sleep(700); await A.page.screenshot({ path: '/home/claude/shots/chat-menu.png' });
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAFUlEQVR42mP8z8BQz0AEYBxVSF+FABJADveWkH6oAAAAAElFTkSuQmCC', 'base64');
await A.page.setInputFiles('#cxfile', { name: 'صورة.png', mimeType: 'image/png', buffer: PNG }); await sleep(900);
await A.page.screenshot({ path: '/home/claude/shots/chat-preview.png' });
await A.page.fill('#cxin', 'هذه صورة المشكلة'); await A.page.click('.cx-send'); await sleep(1500);
await adm.page.reload(); await adm.page.waitForSelector('#main'); await adm.page.click('#nav .nv[data-t="chat"]'); await sleep(600); await adm.page.click('.th'); await sleep(1200);
const imgOk = await adm.page.evaluate(() => { const i = document.querySelector('.cm .att.img img'); return !!i && i.complete && i.naturalWidth > 0; });
assert.ok(imgOk, 'الصورة المرفقة ظهرت عند الدعم محمّلة فعلاً');
await adm.page.screenshot({ path: '/home/claude/shots/chat-admin-img.png' });
console.log('✔ المرفقات: القائمة (+) وإرفاق صورة وإرسالها ووصولها للدعم محمّلة، في متصفحين حقيقيين');
await adm.br.close();
console.log('أخطاء الصفحات:', [...A.errs, ...B.errs].length || 'لا يوجد');
await A.page.screenshot({ path: '/home/claude/shots/user-A-codes.png' });
await A.br.close(); await B.br.close(); srv.kill(); panel.close();
