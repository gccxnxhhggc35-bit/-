// بدون خادم: متصفحان منفصلان (المدير + نسخة المستخدم) وقناة إشعارات وهمية. يثبت وصول الأرقام والنطاقات والدردشة بدقة.
import test from 'node:test';
import assert from 'node:assert/strict';

globalThis.window = { NFS_API: 'local' }; // يفعّل حلقات المدير والمستخدم كما في المتصفح
globalThis.addEventListener ||= () => {}; globalThis.dispatchEvent ||= () => true;
const topics = new Map(); let seq = 0;
const topic = (n) => topics.get(n) || (topics.set(n, { msgs: [], subs: new Set() }), topics.get(n));
globalThis.fetch = async (url, opts = {}) => {
  const u = new URL(url);
  if (!/ntfy\.sh$/.test(u.host)) return new Response(JSON.stringify(u.searchParams.get('page') ? [] : (globalThis.PANEL_ITEMS || [])), { status: 200, headers: { 'content-type': 'application/json' } });
  if (opts.method === 'POST') { const t = topic(u.pathname.split('/')[1]), m = { id: String(++seq), message: opts.body }; t.msgs.push(m); for (const s of t.subs) setTimeout(() => s.emit(m), 3); return new Response('{}', { status: 200 }); }
  if (u.pathname.endsWith('/json')) { const t = topic(u.pathname.split('/')[1]); return new Response(t.msgs.map((m) => JSON.stringify({ id: m.id, event: 'message', message: m.message })).join('\n'), { status: 200 }); }
  return new Response('[]', { status: 200 });
};
globalThis.EventSource = class { constructor(url) { const u = new URL(url), t = topic(u.pathname.split('/')[1]), since = u.searchParams.get('since'); this.t = t; t.subs.add(this);
  setTimeout(() => { this.onopen?.(); for (const m of t.msgs) if (!/^\d+$/.test(since) || Number(m.id) > Number(since)) this.emit(m); }, 3); }
  emit(m) { this.onmessage?.({ data: JSON.stringify({ event: 'message', id: m.id, message: m.message }) }); } close() { this.t.subs.delete(this); } };
const until = async (fn, ms = 20000) => { const t0 = Date.now(); for (;;) { try { const v = await fn(); if (v) return v; } catch { /* انتظر */ } if (Date.now() - t0 > ms) throw new Error('انتهت المهلة'); await new Promise((r) => setTimeout(r, 150)); } };

const mkDoc = (snap) => ({ getElementById: (id) => id === 'nfs-single' ? {} : id === 'nfs-snapshot' ? { textContent: snap || '' } : null, documentElement: { outerHTML: '<html><script id="nfs-snapshot" type="application/json">' + (snap || '') + '</script></html>' } });
globalThis.document = mkDoc('');
const A = await import('../public/local-api.js?admin');
const a = (p, m = 'GET', b) => A.localApi(p, { method: m, body: b });
let user, dom, snapHtml, B, b;

test('المدير ينشئ مستخدماً ونطاقاً وأرقاماً ثم يصدّر نسخة المستخدم (قديمة عمداً)', async () => {
  await a('/api/login', 'POST', { username: 'saleh', password: 'saleh' });
  user = (await a('/api/users', 'POST', { username: 'usera', name: 'أحمد', password: 'Pass1234a' })).item;
  dom = (await a('/api/domains', 'POST', { name: 'syria', apps: ['wa'], access: [user.id] })).item;
  await a(`/api/domains/${dom.id}/numbers/import`, 'POST', { text: '963944000001\n963944000002\n963944000003\n963944000004' });
  snapHtml = (await a('/api/export/users', 'POST')).html;
  const json = snapHtml.slice(snapHtml.indexOf('>', snapHtml.indexOf('id="nfs-snapshot"')) + 1, snapHtml.indexOf('</script>', snapHtml.indexOf('id="nfs-snapshot"')));
  globalThis.document = mkDoc(json.replace(/\\u003c/g, '<'));
  B = await import('../public/local-api.js?user'); b = (p, m = 'GET', body) => B.localApi(p, { method: m, body });
  await b('/api/login', 'POST', { username: 'usera', password: 'Pass1234a' });
  assert.equal((await b('/api/my/numbers')).items.length, 0);
});

test('المدير يوزّع رقمين، فيظهران مع النطاق في متصفح المستخدم الآخر تلقائياً', async () => {
  await a(`/api/domains/${dom.id}/numbers/assign`, 'POST', { userId: user.id, app: 'wa', count: 2 });
  await until(async () => (await b('/api/my/numbers')).items.length === 2);
  const mine = (await a(`/api/users/${user.id}/numbers`)).items.map((x) => x.n).sort(), got = (await b('/api/my/numbers')).items.map((x) => x.n).sort();
  assert.deepEqual(got, mine);
  const doms = (await b('/api/domains')).items; assert.ok(doms.some((d) => d.name === 'syria'));
});

test('إرجاع رقم يزيله من متصفح المستخدم، وإضافة آخر تظهر مباشرة', async () => {
  const first = (await a(`/api/users/${user.id}/numbers`)).items[0];
  await a('/api/numbers/release', 'POST', { ids: [first.id] });
  await a(`/api/domains/${dom.id}/numbers/assign`, 'POST', { userId: user.id, app: 'wa', count: 2 });
  assert.equal((await b('/api/my/numbers')).items.some((x) => x.n === first.n && false), false);
});

test('التواصل: رسالة المستخدم تصل لحساب الدعم، والرد يصل للمستخدم', async () => {
  await b('/api/chat', 'POST', { id: 'c1', text: 'مرحباً، أحتاج مساعدة' });
  await until(async () => (await a('/api/chat')).threads?.some((t) => t.uid === user.id));
  assert.equal((await a(`/api/chat?u=${user.id}`)).items[0].text, 'مرحباً، أحتاج مساعدة');
  await a('/api/chat', 'POST', { id: 's1', to: user.id, text: 'أهلاً بك، كيف نساعدك؟' });
  await until(async () => (await b('/api/chat')).items.some((m) => m.id === 's1'));
  assert.deepEqual((await b('/api/chat')).items.map((m) => m.from), ['u', 's']);
});
test('API للبوتات بدون خادم: تفعيل، نشر على القناة، قراءة راجعة ناجحة، ومفتاح جديد', async () => {
  const k0 = await a('/api/apikit'); assert.equal(k0.on, false); assert.match(k0.topic, /^nfs_[A-Za-z0-9]{32}$/);
  assert.equal((await a('/api/apikit', 'POST', { on: true })).on, true);
  const t = await a('/api/apikit/test', 'POST'); assert.equal(t.ok, true); assert.match(t.url, /\/json\?poll=1/);
  const k1 = (await a('/api/apikit', 'POST', { regen: true })).topic; assert.notEqual(k1, k0.topic);
  // المستخدم له قناة API خاصة به (مختلفة عن المدير) وبصلاحية أكواده فقط، ولا يغيّر رابط الموقع ولا يعطّل نفسه
  const kb = await b('/api/apikit'); assert.match(kb.topic, /^nfs_[A-Za-z0-9]{32}$/); assert.notEqual(kb.topic, k1);
  assert.equal(kb.scope, 'own'); assert.equal(kb.canEditUrl, false);
  await assert.rejects(() => b('/api/apikit', 'POST', { siteUrl: 'https://x.example' }), (e) => e.status === 403);
  await assert.rejects(() => b('/api/apikit', 'POST', { on: false }), (e) => e.status === 400);
});
test.after(() => setTimeout(() => process.exit(0), 50));

test('مستخدم على الموقع المستضاف (متصفح ثالث بلا نسخة): يدخل كما في التسجيل فتصله الأرقام والنطاقات والإعلانات والأكواد والمرفقات', async () => {
  globalThis.document = mkDoc('');
  const C = await import('../public/local-api.js?hosted'); const c = (p, m = 'GET', body) => C.localApi(p, { method: m, body });
  await a('/api/panels/prime', 'PUT', { key: 'k' });
  const d2 = (await a('/api/domains', 'POST', { name: 'hosted-dom', apps: ['wa'], access: '*' })).item;
  await a(`/api/domains/${d2.id}/numbers/import`, 'POST', { text: '963955111222\n963955111333' });
  const ub = (await a('/api/users', 'POST', { username: 'userb', name: 'سارة', password: 'Pass1234b' })).item;
  await until(async () => { try { await c('/api/login', 'POST', { username: 'userb', password: 'Pass1234b' }); return true; } catch { return false; } });
  await a(`/api/domains/${d2.id}/numbers/assign`, 'POST', { userId: ub.id, app: 'wa', count: 1 });
  await a('/api/announcements', 'POST', { title: 'إعلان للجميع', body: 'تم تحديث الأرقام' });
  const mine = await until(async () => { const r = await c('/api/my/numbers'); return r.items.length === 1 ? r.items : null; });
  assert.deepEqual(mine.map((x) => x.n), (await a(`/api/users/${ub.id}/numbers`)).items.map((x) => x.n));
  assert.ok((await c('/api/domains')).items.some((d) => d.name === 'hosted-dom'), 'النطاق ظهر عند المستخدم');
  await until(async () => (await c('/api/announcements')).items.some((x) => x.title === 'إعلان للجميع'));
  // كود يصل من اللوحة لرقم المستخدم فيظهر في حسابه هو فقط
  globalThis.PANEL_ITEMS = [{ id: 'z1', time: new Date().toISOString(), number: mine[0].n, cllr: 'WhatsApp', content: 'Your WhatsApp code: 246-810', agentPayout: '0.003' }];
  await a('/api/panels/prime/test', 'POST');
  const got = await until(async () => (await c('/api/codes')).items.find((i) => i.c === '246810'));
  assert.equal(got.n, mine[0].n);
  assert.equal((await b('/api/codes')).items.some((i) => i.c === '246810'), false, 'مستخدم آخر لا يرى كوده');
  // مرفق صغير من المستخدم إلى الدعم ثم رد بمرفق
  const png = 'data:image/png;base64,' + 'iVBORw0KGgo='.repeat(40);
  await c('/api/chat', 'POST', { id: 'f1', text: 'صورة', file: { name: 'a.png', type: 'image/png', size: 300, data: png } });
  const th = await until(async () => (await a(`/api/chat?u=${ub.id}`)).items.find((m) => m.id === 'f1' && m.file && m.file.url));
  assert.equal(th.file.url, png);
  await a('/api/chat', 'POST', { id: 'f2', to: ub.id, text: 'وصلت', file: { name: 'r.pdf', type: 'application/pdf', size: 100, data: 'data:application/pdf;base64,' + 'QUJD'.repeat(30) } });
  await until(async () => (await c('/api/chat')).items.find((m) => m.id === 'f2' && m.file && m.file.url));
});
