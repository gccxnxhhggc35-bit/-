import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createStore } from '../lib/store.js';
import { verifyPassword } from '../lib/auth.js';

test('server store seeds 1Whisper as a separate limited administrator', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'nfssms-limited-admin-'));
  const oldAdminPassword = process.env.ADMIN_PASSWORD;
  const oldLimitedPassword = process.env.LIMITED_ADMIN_PASSWORD;
  const oldUsername = process.env.ADMIN_USERNAME;
  delete process.env.ADMIN_PASSWORD;
  delete process.env.ADMIN_USERNAME;
  delete process.env.LIMITED_ADMIN_PASSWORD;
  try {
    const store = createStore(dir, { panels: [], activePanel: null });
    const manager = store.core.users.find((u) => String(u.username).toLowerCase() === '1whisper');
    const fullAdmin = store.core.users.find((u) => u.role === 'admin');
    assert.ok(manager, 'limited manager should be seeded');
    assert.equal(manager.username, '1Whisper');
    assert.equal(manager.role, 'limited_admin');
    assert.notEqual(manager.role, fullAdmin?.role);
    assert.equal(await verifyPassword(manager, '1Whisper'), true);
    assert.equal(await verifyPassword(manager, 'incorrect'), false);
    store.flush();
    const persisted = JSON.parse(fs.readFileSync(path.join(dir, 'core.json'), 'utf8'));
    assert.equal(persisted.users.find((u) => u.username === '1Whisper')?.role, 'limited_admin');
  } finally {
    if (oldAdminPassword === undefined) delete process.env.ADMIN_PASSWORD; else process.env.ADMIN_PASSWORD = oldAdminPassword;
    if (oldUsername === undefined) delete process.env.ADMIN_USERNAME; else process.env.ADMIN_USERNAME = oldUsername;
    if (oldLimitedPassword === undefined) delete process.env.LIMITED_ADMIN_PASSWORD; else process.env.LIMITED_ADMIN_PASSWORD = oldLimitedPassword;
    fs.rmSync(dir, { recursive: true, force: true });
  }
});


test('configured saleh account is seeded as full administrator with username/password access', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'nfssms-saleh-admin-'));
  const oldAdminPassword = process.env.ADMIN_PASSWORD;
  const oldUsername = process.env.ADMIN_USERNAME;
  delete process.env.ADMIN_PASSWORD;
  delete process.env.ADMIN_USERNAME;
  try {
    const store = createStore(dir, { panels: [], activePanel: null, adminUsername: 'saleh', adminPassword: 'saleh' });
    const admin = store.core.users.find((u) => String(u.username || '').toLowerCase() === 'saleh');
    assert.ok(admin, 'saleh should be seeded');
    assert.equal(admin.role, 'admin');
    assert.equal(admin.disabled, false);
    assert.equal(store.adminUsername, 'saleh');
    assert.equal(await verifyPassword(admin, 'saleh'), true);
    assert.equal(await verifyPassword(admin, 'wrong'), false);
    store.flush();
    const persisted = JSON.parse(fs.readFileSync(path.join(dir, 'core.json'), 'utf8'));
    assert.equal(persisted.users.find((u) => u.username === 'saleh')?.role, 'admin');
  } finally {
    if (oldAdminPassword === undefined) delete process.env.ADMIN_PASSWORD; else process.env.ADMIN_PASSWORD = oldAdminPassword;
    if (oldUsername === undefined) delete process.env.ADMIN_USERNAME; else process.env.ADMIN_USERNAME = oldUsername;
    fs.rmSync(dir, { recursive: true, force: true });
  }
});
