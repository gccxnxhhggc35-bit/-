import test from 'node:test';
import assert from 'node:assert/strict';

globalThis.addEventListener ||= () => {};
const apiMod = await import('../public/local-api.js?numbers-replace');
const api = (path, method = 'GET', body) => apiMod.localApi(path, { method, body });

test('تجديد الأرقام يستبدل القديم ذرياً ويعيد الأرقام الجديدة للمخزون المتاح', async () => {
  await api('/api/login', 'POST', { username: 'saleh', password: 'saleh' });
  const user = (await api('/api/users', 'POST', { username: 'renewuser', name: 'Renew User', password: 'RenewPass123' })).item;
  const d = (await api('/api/domains', 'POST', { name: 'renew-range', apps: ['wa'], access: '*' })).item;
  await api(`/api/domains/${d.id}/numbers/import`, 'POST', { text: '491511110001\n491511110002\n491511110003\n491511110004' });
  await api(`/api/domains/${d.id}/numbers/assign`, 'POST', { userId: user.id, app: 'wa', count: 1 });
  const old = (await api(`/api/domains/${d.id}/numbers?filter=all&offset=0&limit=100`)).items;
  const r = await api(`/api/domains/${d.id}/numbers/replace`, 'POST', {
    ids: old.map((x) => x.id),
    text: '491511220001\n491511220002\n491511220003\n491511220003\ninvalid-number',
  });
  assert.equal(r.replaced, 4);
  assert.equal(r.added, 3);
  assert.equal(r.unassigned, 1);
  const after = (await api(`/api/domains/${d.id}/numbers?filter=all&offset=0&limit=100`)).items;
  assert.deepEqual(after.map((x) => x.n).sort(), ['491511220001', '491511220002', '491511220003']);
  assert.ok(after.every((x) => x.u == null));
  assert.equal((await api(`/api/users/${user.id}/numbers`)).items.length, 0);
});

test('إذا كانت الأرقام الجديدة كلها مكررة خارج الاختيار فلن يُحذف القديم', async () => {
  const d1 = (await api('/api/domains')).items.find((x) => x.name === 'renew-range');
  const d2 = (await api('/api/domains', 'POST', { name: 'other-range', apps: ['wa'], access: '*' })).item;
  await api(`/api/domains/${d2.id}/numbers/import`, 'POST', { text: '491511330001' });
  await api(`/api/domains/${d1.id}/numbers/import`, 'POST', { text: '491511440001\n491511440002' });
  const old = (await api(`/api/domains/${d1.id}/numbers?filter=all&offset=0&limit=100`)).items;
  await assert.rejects(() => api(`/api/domains/${d1.id}/numbers/replace`, 'POST', { ids: old.map((x) => x.id), text: '491511330001' }), /كل الأرقام الجديدة موجودة مسبقاً/);
  const after = (await api(`/api/domains/${d1.id}/numbers?filter=all&offset=0&limit=100`)).items;
  assert.deepEqual(after.map((x) => x.n).sort(), ['491511220001', '491511220002', '491511220003', '491511440001', '491511440002'].sort());
});
