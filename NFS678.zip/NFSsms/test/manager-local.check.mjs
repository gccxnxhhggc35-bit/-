// المدير رقم 2 (1Whisper) في وضع الملف الواحد: صلاحيات محدودة + رسالة الدعم عند فشل الدخول
import test from 'node:test';
import assert from 'node:assert/strict';

globalThis.addEventListener ||= () => {};
globalThis.fetch = async () => new Response('[]', { status: 200 });
const mod = await import('../public/local-api.js?browser=manager');
const api = (p, m = 'GET', b) => mod.localApi(p, { method: m, body: b });
const fails = async (fn, status) => { try { await fn(); } catch (e) { assert.equal(e.status, status); return e; } assert.fail('كان يجب أن يفشل'); };

test('1Whisper يدخل بكلمة السر 1Whisper ويرى الترافيك والنطاقات ويدير المستخدمين', async () => {
  const r = await api('/api/login', 'POST', { username: '1Whisper', password: '1Whisper' });
  assert.equal(r.user.role, 'limited_admin');
  await api('/api/domains', 'POST', { name: 'test.example', apps: ['wa'], access: '*' });
  const doms = await api('/api/domains');
  assert.equal(doms.items.length, 1);
  assert.equal(typeof doms.items[0].total, 'number', 'يرى العدادات الكاملة');
  await api('/api/domains/1', 'PATCH', { name: 'test2.example' });
  await api('/api/domains/1/numbers/import', 'POST', { text: '+963911111111\n+963922222222' });
  const created = await api('/api/users', 'POST', { username: 'ahmed', name: 'أحمد', password: 'Pass1234a' });
  assert.equal(created.item.role, 'user');
  const users = await api('/api/users');
  assert.deepEqual(users.items.map((u) => u.username), ['ahmed'], 'لا يظهر المديران في القائمة');
  assert.ok((await api('/api/codes?scope=all')).items);
  assert.ok((await api('/api/stats')).users >= 1);
});

test('1Whisper ينشر إعلاناً ويحذف أرقاماً ونطاقاً، لكن لا يملك اللوحات والإعدادات والتصدير', async () => {
  await api('/api/login', 'POST', { username: '1whisper', password: '1Whisper' });
  await api('/api/announcements', 'POST', { title: 'x', body: 'y' });
  await api('/api/numbers/delete', 'POST', { ids: [] });
  await api('/api/domains/1', 'DELETE');
  await fails(() => api('/api/panels'), 403);
  await fails(() => api('/api/settings', 'POST', { pricePerCode: 5 }), 403);
  await fails(() => api('/api/bot/run', 'POST'), 403);
  await fails(() => api('/api/export/users', 'POST'), 403);
  await fails(() => api('/api/users/1', 'PATCH', { password: 'Abcdefg12' }), 404, 'لا يمس المديرين');
});

test('مستخدم عادي لا يستطيع استخدام مسارات المشرف، وفشل الدخول يعرض رسالة الدعم', async () => {
  await api('/api/login', 'POST', { username: 'ahmed', password: 'Pass1234a' });
  await fails(() => api('/api/users'), 403);
  await fails(() => api('/api/domains', 'POST', { name: 'a.b', apps: ['wa'] }), 403);
  const e = await fails(() => api('/api/login', 'POST', { username: 'nobody', password: 'whatever1' }), 401);
  assert.equal(e.message, 'حدث خطأ، تواصل مع الدعم عبر تيليجرام @NFSsms');
});
