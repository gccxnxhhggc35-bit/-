// حساب ينشئه المدير في متصفح، ويدخل به المستخدم من متصفح آخر بدون خادم ودون رسالة خطأ
import test from 'node:test';
import assert from 'node:assert/strict';

globalThis.addEventListener ||= () => {};
// قناة ntfy وهمية: تخزّن الرسائل لكل قناة وتعيدها بصيغة NDJSON
const channels = new Map();
globalThis.fetch = async (url, opts = {}) => {
  const u = new URL(url);
  if (u.hostname !== 'ntfy.sh') return new Response('[]', { status: 200 });
  const topic = u.pathname.split('/')[1];
  if (opts.method === 'POST') { (channels.get(topic) || channels.set(topic, []).get(topic)).push(opts.body); return new Response('{}', { status: 200 }); }
  const lines = (channels.get(topic) || []).map((m, i) => JSON.stringify({ id: String(i), event: 'message', topic, message: m }));
  return new Response(lines.join('\n'), { status: 200 });
};
// نسختان من الوحدة = متصفحان بتخزينين منفصلين
const admin = await import('../public/local-api.js?browser=admin');
const other = await import('../public/local-api.js?browser=user');
const A = (p, m = 'GET', b) => admin.localApi(p, { method: m, body: b });
const B = (p, m = 'GET', b) => other.localApi(p, { method: m, body: b });
const tick = () => new Promise((r) => setTimeout(r, 20));

test('المستخدم يدخل من متصفح آخر بحساب أنشأه المدير ويُحفظ في متصفحه', async () => {
  await A('/api/login', 'POST', { username: 'saleh', password: 'saleh' });
  await A('/api/users', 'POST', { username: 'ahmed', name: 'أحمد', password: 'Pass1234a' });
  await tick();
  assert.equal(channels.size, 1, 'نُشر سجل الحساب');
  assert.equal([...channels.values()].flat().join('').includes('Pass1234a'), false, 'كلمة السر لا تظهر نصاً');
  assert.equal([...channels.values()].flat().join('').includes('ahmed'), false, 'اسم المستخدم لا يظهر نصاً');

  const r = await B('/api/login', 'POST', { username: 'Ahmed ', password: 'Pass1234a' });
  assert.equal(r.user.username, 'ahmed');
  assert.equal(r.user.role, 'user');
  assert.equal((await B('/api/me')).user.name, 'أحمد');

  // صار الحساب محفوظاً محلياً: يدخل ثانية حتى لو انقطعت القناة
  channels.clear();
  await B('/api/logout', 'POST');
  assert.equal((await B('/api/login', 'POST', { username: 'ahmed', password: 'Pass1234a' })).user.username, 'ahmed');
});

test('كلمة سر خاطئة أو حساب غير موجود يُرفض', async () => {
  await assert.rejects(() => B('/api/login', 'POST', { username: 'ahmed', password: 'Wrong1234' }), { status: 401 });
  await assert.rejects(() => B('/api/login', 'POST', { username: 'nobody', password: 'Pass1234a' }), { status: 401 });
});

test('تغيير كلمة السر من المدير ينتقل للمتصفح الآخر عند أول دخول بالكلمة الجديدة', async () => {
  const id = (await A('/api/users')).items.find((u) => u.username === 'ahmed').id;
  await A(`/api/users/${id}`, 'PATCH', { password: 'NewPass5678b' });
  await tick();
  await B('/api/logout', 'POST');
  const r = await B('/api/login', 'POST', { username: 'ahmed', password: 'NewPass5678b' });
  assert.equal(r.user.username, 'ahmed');
});

test('لا يمكن انتحال حساب المدير عبر القناة العامة', async () => {
  await assert.rejects(() => B('/api/login', 'POST', { username: 'saleh', password: 'x12345678' }), { status: 401 });
});
