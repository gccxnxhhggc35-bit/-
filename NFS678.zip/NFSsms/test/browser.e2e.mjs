// اختبار متصفحات حقيقية: متصفحان مستقلان (مدير + مشرف محدود) يتابعان نفس الخادم
// تشغيل: node test/browser.e2e.mjs   (يحتاج playwright ومتصفحين مثبتين)
import http from 'node:http';
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';
const { chromium } = await import(process.env.PW_MODULE || '/home/claude/.npm-global/lib/node_modules/playwright/index.mjs');

const ROOT = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const SHOTS = process.env.SHOTS || '/home/claude/shots'; fs.mkdirSync(SHOTS, { recursive: true });
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'nfsb-'));
const msgs = [];
const panel = http.createServer((q, r) => { r.writeHead(200, { 'Content-Type': 'application/json' }); r.end(JSON.stringify({ data: msgs })); });
await new Promise((r) => panel.listen(0, r));
const PORT = 4100 + Math.floor(Math.random() * 80), base = `http://127.0.0.1:${PORT}`;
const cfg = JSON.parse(fs.readFileSync(path.join(ROOT, 'config.json'), 'utf8'));
Object.assign(cfg, { port: PORT, activePanel: 'mock', panels: [{ id: 'mock', name: 'Mock', type: 'generic', url: `http://127.0.0.1:${panel.address().port}`, key: 'k', path: '/m', authHeader: 'X-API-Key', authScheme: '', enabled: true }] });
const orig = fs.readFileSync(path.join(ROOT, 'config.json'), 'utf8');
fs.writeFileSync(path.join(ROOT, 'config.json'), JSON.stringify(cfg));
const srv = spawn('node', ['server.js'], { cwd: ROOT, env: { ...process.env, CLERK_SECRET_KEY: '', DATA_DIR: dir, PORT: String(PORT) }, stdio: 'pipe' });
await new Promise((r) => setTimeout(r, 1500)); fs.writeFileSync(path.join(ROOT, 'config.json'), orig);

const api = async (tok, p, m = 'GET', b) => { const r = await fetch(base + p, { method: m, headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${tok}` }, body: b ? JSON.stringify(b) : undefined }); const j = await r.json(); if (!r.ok) throw new Error(p + ' ' + j.error); return j; };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const owner = (await (await fetch(base + '/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: 'saleh', password: 'saleh' }) })).json()).token;
const dom = (await api(owner, '/api/domains', 'POST', { name: 'syria-wa', apps: ['wa', 'tg'], access: '*' })).item.id;
await api(owner, `/api/domains/${dom}/numbers/import`, 'POST', { text: '963944111222\n963944111333' });
const user = (await api(owner, '/api/users', 'POST', { username: 'ahmed', name: 'أحمد', password: 'Pass1234a' })).item.id;

const browsers = [
  { name: 'A-playwright-chromium', launch: () => chromium.launch() },
  { name: 'B-chrome-131', launch: () => chromium.launch({ executablePath: process.env.CHROME2 || '/home/claude/.cache/puppeteer/chrome/linux-131.0.6778.204/chrome-linux64/chrome' }) },
];
async function openAs(b, username, password, viewport) {
  const br = await b.launch(); const ctx = await br.newContext({ viewport, locale: 'ar' }); const page = await ctx.newPage();
  const errors = []; page.on('pageerror', (e) => errors.push(String(e))); page.on('console', (m) => m.type() === 'error' && !/favicon|Failed to load resource/.test(m.text()) && errors.push(m.text()));
  await page.route('**/config.js', (r) => r.fulfill({ contentType: 'text/javascript', body: "window.NFS_API='';" })); // بدون Clerk في الاختبار
  await page.goto(base); await page.fill('#u', username); await page.fill('#p', password); await page.click('#lb');
  await page.waitForSelector('#main', { timeout: 8000 });
  return { br, page, errors, ua: await page.evaluate(() => navigator.userAgent) };
}
const results = [];
for (const [i, b] of browsers.entries()) {
  // المتصفح الأول: المدير (سطح مكتب). المتصفح الثاني: المشرف المحدود (جوال)
  const isOwner = i === 0;
  const s = await openAs(b, isOwner ? 'saleh' : '1Whisper', isOwner ? 'saleh' : '1Whisper', isOwner ? { width: 1280, height: 800 } : { width: 390, height: 800 });
  s.name = b.name; results.push(s);
}
const [A, B] = results;
const tab = async (s, name) => { await s.page.click(`#nav .nv[data-t="${name}"]`); await sleep(1000); };
const bodyText = (s) => s.page.evaluate(() => document.querySelector('#main').innerText);
await A.page.screenshot({ path: `${SHOTS}/${process.env.TAG || 'run'}-A-doms.png` }); await B.page.screenshot({ path: `${SHOTS}/${process.env.TAG || 'run'}-B-doms.png` });

// 1) المدير يضيف أرقاماً → تظهر في متصفح المشرف الثاني تلقائياً بدون أي ضغطة
const t0 = Date.now();
await api(owner, `/api/domains/${dom}/numbers/import`, 'POST', { text: '963944111444\n963944111555\n963944111666' });
let seen = false; while (Date.now() - t0 < 12000) { if (/\b5\b|٥/.test(await bodyText(B))) { seen = true; break; } await sleep(300); }
console.log(seen ? `✔ متصفح المشرف الثاني التقط الأرقام الجديدة بعد ${Date.now() - t0}ms بدون تحديث يدوي` : '✘ لم تظهر الأرقام الجديدة في متصفح المشرف'); assert.ok(seen);

// 2) توزيع رقم لمستخدم ثم وصول كود → يظهر عند المدير والمشرف في الترافيك مع إشعار
await api(owner, `/api/domains/${dom}/numbers/assign`, 'POST', { userId: user, app: 'wa', count: 1 });
const num = (await api(owner, `/api/users/${user}/numbers`)).items[0].n;
await tab(A, 'codes'); await tab(B, 'codes');
msgs.push({ id: 'x1', number: '+' + num, sender: 'WhatsApp', content: 'Your WhatsApp code: 654-321', time: Date.now() - 2 * 3600e3 });
const t1 = Date.now(); let got = { A: false, B: false };
while (Date.now() - t1 < 20000 && !(got.A && got.B)) { for (const [k, s] of [['A', A], ['B', B]]) if (!got[k] && (await bodyText(s)).includes('654321')) got[k] = Date.now() - t1; await sleep(300); }
console.log('✔/✘ وصول الكود (ms):', JSON.stringify(got)); assert.ok(got.A && got.B);
await A.page.screenshot({ path: `${SHOTS}/${process.env.TAG || 'run'}-A-codes.png` }); await B.page.screenshot({ path: `${SHOTS}/${process.env.TAG || 'run'}-B-codes.png` });
await tab(B, 'home'); await B.page.screenshot({ path: `${SHOTS}/${process.env.TAG || 'run'}-B-home.png` });
for (const s of results) console.log(s.name, '|', s.ua.match(/(Chrome|HeadlessChrome)\/[\d.]+/)?.[0], '| أخطاء الصفحة:', s.errors.length ? s.errors.join(' ; ') : 'لا يوجد');
await Promise.all(results.map((s) => s.br.close())); srv.kill(); panel.close();
