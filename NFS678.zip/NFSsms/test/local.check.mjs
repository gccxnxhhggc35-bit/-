// اختبارات الوضع بدون خادم: توزيع الأكواد على أصحاب الأرقام والإيصال المشفّر لأجهزتهم
import test from 'node:test';
import assert from 'node:assert/strict';

globalThis.addEventListener ||= () => {};
const posted = [];
const PANEL = [
  { id: 'a1', time: '2026-10-21T15:17:05Z', number: '4790697243', cllr: 'TikTok', content: '[#]يُعد [TikTok] 706426 بمثابة رمز التحقق', agentPayout: '0.003' },
  { id: 'a2', time: '2026-10-22T21:04:43Z', number: '22375742265', cllr: 'WhatsApp', content: 'Your WhatsApp code: 528-973\\nDon\\\'t share', agentPayout: '0.007' },
];
let panelItems = PANEL;
globalThis.fetch = async (url, opts = {}) => {
  if (opts.method === 'POST') { posted.push(JSON.parse(opts.body)); return new Response('{}', { status: 200 }); }
  const page = new URL(url).searchParams.get('page');
  return new Response(JSON.stringify(page ? [] : panelItems), { status: 200, headers: { 'content-type': 'application/json' } });
};
const { localApi, seal, unseal, pushKey, pushRid } = await import('../public/local-api.js');
const api = (path, method = 'GET', body) => localApi(path, { method, body });

test('الفحص يوزّع كل أكواد اللوحة على أصحاب الأرقام ويرسلها مشفّرة لأصحابها فقط', async () => {
  await api('/api/login', 'POST', { username: 'saleh', password: 'saleh' });
  await api('/api/panels/prime', 'PUT', { key: 'k' });
  const a = (await api('/api/users', 'POST', { username: 'usera', name: 'A', password: 'Pass1234a' })).item;
  const b = (await api('/api/users', 'POST', { username: 'userb', name: 'B', password: 'Pass1234b' })).item;
  const d = (await api('/api/domains', 'POST', { name: 'r1', apps: ['wa', 'tt'], access: '*' })).item;
  await api(`/api/domains/${d.id}/numbers/import`, 'POST', { text: '4790697243\n22375742265' });
  // الرقمان يُوزَّعان بعد وصول رسائلهما، ومع ذلك تُحتسب الأكواد لصاحب الرقم
  await api(`/api/domains/${d.id}/numbers/assign`, 'POST', { userId: a.id, app: 'tt', count: 1 });
  await api(`/api/domains/${d.id}/numbers/assign`, 'POST', { userId: b.id, app: 'wa', count: 1 });
  const r = await api('/api/panels/prime/test', 'POST');
  assert.equal(r.ok, true);
  assert.equal(r.codes, 2);
  assert.equal(r.delivered, 2);
  assert.deepEqual(r.users.map((u) => [u.username, u.n]).sort(), [['usera', 1], ['userb', 1]]);
  const wa = r.items.find((i) => i.n === '22375742265');
  assert.equal(wa.c, '528973');
  assert.equal(wa.pay, 0.007);
  assert.equal(wa.x.includes('\\n'), false);

  // الإيصال: صاحب الرقم فقط يفك كوده بمفتاحه المشتق من كلمة سره
  const boxes = posted.flatMap((p) => p.i || []);
  assert.ok(boxes.length >= 2); // صندوقا الأكواد + صناديق الحالة المشفّرة للمستخدمين
});

test('إلغاء توزيع الرقم يمنع انتقال أكواده القديمة للمالك الجديد', async () => {
  const nums = (await api('/api/domains/1/numbers?filter=assigned')).items;
  const n = nums.find((x) => x.n === '4790697243');
  await api('/api/numbers/release', 'POST', { ids: [n.id] });
  const b = (await api('/api/users')).items.find((u) => u.username === 'userb');
  await api('/api/domains/1/numbers/assign', 'POST', { userId: b.id, app: 'tt', count: 1 });
  const codes = (await api('/api/codes?scope=owned')).items;
  assert.equal(codes.some((c) => c.n === '4790697243'), false);
});

test('التشفير: المفتاح الصحيح يفك، والخاطئ لا يفك', () => {
  const pk = pushKey('Pass1234a', 'abcd'), other = pushKey('wrong', 'abcd');
  assert.notEqual(pushRid(pk), pushRid(other));
  const box = seal(pk, '{"c":"528973"}');
  assert.equal(unseal(pk, box), '{"c":"528973"}');
  assert.equal(unseal(other, box), null);
});

test('المدير يرى أرقام المستخدم ويرجعها للمخزون العام أو يحذفها', async () => {
  await api('/api/login', 'POST', { username: 'saleh', password: 'saleh' });
  const u = (await api('/api/users', 'POST', { username: 'userc', name: 'C', password: 'Pass1234c' })).item;
  const d = (await api('/api/domains', 'POST', { name: 'r2', apps: ['wa'], access: '*' })).item;
  await api(`/api/domains/${d.id}/numbers/import`, 'POST', { text: '9647700000001\n9647700000002\n9647700000003' });
  await api(`/api/domains/${d.id}/numbers/assign`, 'POST', { userId: u.id, app: 'wa', count: 3 });
  const r = await api(`/api/users/${u.id}/numbers`);
  assert.equal(r.items.length, 3);
  assert.equal(r.items[0].dn, 'r2');
  const rel = await api('/api/numbers/release', 'POST', { ids: [r.items[0].id] });
  assert.equal(rel.released, 1);
  const del = await api('/api/numbers/delete', 'POST', { ids: [r.items[1].id] });
  assert.equal(del.deleted, 1);
  assert.equal((await api(`/api/users/${u.id}/numbers`)).items.length, 1);
  const dom = (await api('/api/domains')).items.find((x) => x.id === d.id);
  assert.equal(dom.free, 1);
  await assert.rejects(() => api('/api/users/99999/numbers'));
});
