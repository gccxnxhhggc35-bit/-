import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const app = readFileSync(new URL('../public/app.js', import.meta.url), 'utf8');
const css = readFileSync(new URL('../public/app.css', import.meta.url), 'utf8');

test('واجهة Clerk تعرض قسم إنشاء حساب واضحاً ويحوّل الزر إلى نموذج التسجيل', () => {
  assert.match(app, /id="clerkSignupPanel"/);
  assert.match(app, /ليس لديك حساب بعد\؟/);
  assert.match(app, /id="clerkCreateAccount"/);
  assert.match(app, /\$\('#clerkCreateAccount'\)\.onclick\s*=\s*startSignup/);
  assert.match(app, /prepareEmailAddressVerification\(\{\s*strategy:\s*'email_code'/);
  assert.match(app, /attemptEmailAddressVerification\(\{\s*code\s*\}/);
});

test('لا تعرض واجهة الدخول المحلية رسالة إعداد مطولة أو زر تسجيل لا يعمل', () => {
  assert.doesNotMatch(app, /لإنشاء حساب بالبريد وكلمة السر والتحقق برمز/);
  assert.doesNotMatch(app, /id="localSignupPanel"|id="localCreateAccount"/);
  assert.match(app, /id="clerkCreateAccount"/);
  assert.match(css, /\.signup-action\{width:auto;min-height:2\.35rem/);
});
