import test from 'node:test';
import assert from 'node:assert/strict';

globalThis.addEventListener ||= () => {};
globalThis.dispatchEvent ||= (() => true);
const channels = new Map(); let seq = 0;
const topic = (name) => channels.get(name) || (channels.set(name, { messages: [], subscribers: new Set() }), channels.get(name));
globalThis.fetch = async (url, opts = {}) => {
  const u = new URL(url);
  if (u.hostname !== 'ntfy.sh') return new Response(JSON.stringify(globalThis.PANEL_ITEMS || []), { status: 200, headers: { 'content-type': 'application/json' } });
  const name = u.pathname.split('/')[1];
  if (opts.method === 'POST') {
    const msg = { id: String(++seq), message: typeof opts.body === 'string' ? opts.body : String(opts.body) };
    const t = topic(name); t.messages.push(msg);
    for (const s of t.subscribers) setTimeout(() => s.emit(msg), 1);
    return new Response('{}', { status: 200 });
  }
  if (u.pathname.endsWith('/json')) return new Response(topic(name).messages.map((m) => JSON.stringify({ id: m.id, event: 'message', message: m.message })).join('\n'), { status: 200 });
  return new Response('[]', { status: 200 });
};
globalThis.EventSource = class {
  constructor(url) { const u = new URL(url); this.name = u.pathname.split('/')[1]; this.t = topic(this.name); this.t.subscribers.add(this); setTimeout(() => { this.onopen?.(); for (const m of this.t.messages) this.emit(m); }, 1); }
  emit(m) { this.onmessage?.({ data: JSON.stringify({ event: 'message', id: m.id, message: m.message }) }); }
  close() { this.t.subscribers.delete(this); }
};
const wait = (ms = 20) => new Promise((r) => setTimeout(r, ms));

const A = await import('../public/local-api.js?manager-channel-a');
const a = (p, method = 'GET', body) => A.localApi(p, { method, body });

test('قناة المديرين المشفّرة تنقل النطاق والحساب والأرقام والأكواد إلى متصفح المدير الثاني دون مشاركة كلمات السر أو المفاتيح', async () => {
  await a('/api/login', 'POST', { username: 'saleh', password: 'saleh' });
  const channel = await a('/api/manager-sync', 'POST', { create: true });
  assert.equal(channel.enabled, true);
  assert.match(channel.topic, /^nfs-mgr-[a-f0-9]{24}$/);
  assert.match(channel.key, /^[a-f0-9]{64}$/);
  const user = (await a('/api/users', 'POST', { username: 'shareduser', name: 'Shared User', password: 'SharedPass123' })).item;
  const d = (await a('/api/domains', 'POST', { name: 'shared-range', apps: ['tt'], access: '*' })).item;
  await a(`/api/domains/${d.id}/numbers/import`, 'POST', { text: '4790697243' });
  await a(`/api/domains/${d.id}/numbers/assign`, 'POST', { userId: user.id, app: 'tt', count: 1 });
  globalThis.PANEL_ITEMS = [{ id: 'shared-sms-1', time: '2026-10-26T17:00:00Z', number: '4790697243', cllr: 'TikTok', content: 'TikTok verification code: 706426' }];
  const panelResult = await a('/api/panels/prime/test', 'POST');
  assert.equal(panelResult.ok, true);
  assert.equal(panelResult.codes, 1);
  const republished = await a('/api/manager-sync', 'POST', { republish: true });
  assert.equal(republished.ok, true);
  await wait(30);

  // استيراد رابط الدعوة مثل فتحه في متصفح آخر: يبدأ المتصفح الثاني بقواعد محلية مستقلة.
  globalThis.location = { hash: '#nfsmanager=' + encodeURIComponent(channel.topic + '.' + channel.key), pathname: '/index.html', search: '', href: 'https://app.example/index.html#nfsmanager=' + encodeURIComponent(channel.topic + '.' + channel.key), origin: 'https://app.example', protocol: 'https:' };
  globalThis.history = { replaceState() {} };
  const B = await import('../public/local-api.js?manager-channel-b');
  const b = (p, method = 'GET', body) => B.localApi(p, { method, body });
  const login = await b('/api/login', 'POST', { username: '1whisper', password: '1Whisper' });
  assert.equal(login.user.role, 'limited_admin');
  const synced = await b('/api/domains');
  assert.ok(synced.items.some((x) => x.name === 'shared-range'));
  const remoteUsers = await b('/api/users');
  assert.ok(remoteUsers.items.some((x) => x.username === 'shareduser'));
  const remoteNumbers = await b(`/api/domains/${d.id}/numbers?filter=all&offset=0&limit=100`);
  assert.deepEqual(remoteNumbers.items.map((x) => x.n), ['4790697243']);
  const codes = await b('/api/codes');
  assert.ok(codes.items.some((x) => x.n === '4790697243' && x.c === '706426'));

  // لا تُنشر بيانات الدخول أو نص الكود بشكل واضح على القناة العامة.
  const all = [...channels.values()].flatMap((x) => x.messages.map((m) => m.message)).join('\n');
  assert.equal(all.includes('SharedPass123'), false);
  assert.equal(all.includes('706426'), false);
  assert.equal(all.includes('X-API-Key'), false);
});

test.after(() => setTimeout(() => process.exit(0), 40));
