// اختبار شامل: وصول الكود لصاحب الرقم، ورؤية المشرف المحدود للأرقام والأكواد، وانحراف ساعة اللوحة
import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const ROOT = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'nfs-'));
const msgs = []; // رسائل اللوحة الوهمية
const panel = http.createServer((req, res) => { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ data: msgs })); });
await new Promise((r) => panel.listen(0, r));
const PP = panel.address().port, PORT = 3900 + Math.floor(Math.random() * 90);
const cfg = JSON.parse(fs.readFileSync(path.join(ROOT, 'config.json'), 'utf8'));
cfg.panels = [{ id: 'mock', name: 'Mock', type: 'generic', url: `http://127.0.0.1:${PP}`, key: 'k', path: '/m', authHeader: 'X-API-Key', authScheme: '', enabled: true }];
cfg.activePanel = 'mock'; cfg.port = PORT;
fs.writeFileSync(path.join(dir, 'config.json'), JSON.stringify(cfg));
const origCfg = fs.readFileSync(path.join(ROOT, 'config.json'), 'utf8');
fs.writeFileSync(path.join(ROOT, 'config.json'), JSON.stringify(cfg)); // config مؤقت يشير للوحة الوهمية
const srv2 = spawn('node', ['server.js'], { cwd: ROOT, env: { ...process.env, CLERK_SECRET_KEY: '', DATA_DIR: dir, PORT: String(PORT) }, stdio: 'pipe' });
await new Promise((r) => setTimeout(r, 1500));
fs.writeFileSync(path.join(ROOT, 'config.json'), origCfg);
test.after(() => { srv2.kill(); panel.close(); });

const call = async (tok, p, method = 'GET', body) => {
  const r = await fetch(`http://127.0.0.1:${PORT}${p}`, { method, headers: { 'Content-Type': 'application/json', ...(tok ? { Authorization: `Bearer ${tok}` } : {}) }, body: body ? JSON.stringify(body) : undefined });
  const j = await r.json(); if (!r.ok) throw Object.assign(new Error(j.error), { status: r.status }); return { ...j, _rev: r.headers.get('x-rev') };
};
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let owner, lim, domId, userId;

test('دخول المدير والمشرف المحدود', async () => {
  owner = (await call(null, '/api/login', 'POST', { username: 'saleh', password: 'saleh' })).token;
  lim = (await call(null, '/api/login', 'POST', { username: '1Whisper', password: '1Whisper' })).token;
  assert.ok(owner && lim);
});

test('المشرف المحدود يضيف نطاقاً وأرقاماً ويراها هو والمدير فوراً', async () => {
  domId = (await call(lim, '/api/domains', 'POST', { name: 'testdom', apps: ['wa', 'tg'], access: '*' })).item.id;
  const imp = await call(lim, `/api/domains/${domId}/numbers/import`, 'POST', { text: '+963944111222\n963944111333\n963944111444' });
  assert.equal(imp.added, 3);
  const mine = (await call(lim, '/api/domains')).items.find((d) => d.id === domId);
  assert.equal(mine.total, 3); assert.equal(mine.free, 3);
  const theirs = (await call(owner, '/api/domains')).items.find((d) => d.id === domId);
  assert.equal(theirs.total, 3);
  const st = await call(lim, '/api/stats?tz=0');
  assert.equal(st.numbers, 3, 'إحصائيات المشرف المحدود تظهر الأرقام'); assert.equal(st.free, 3);
});

test('rev يتغير عندما يضيف مدير أرقاماً، ليلتقطها متصفح المشرف الآخر', async () => {
  const before = (await call(lim, '/api/codes')).rev;
  await call(owner, `/api/domains/${domId}/numbers/import`, 'POST', { text: '963944111555' });
  const after = (await call(lim, '/api/codes')).rev;
  assert.notEqual(before, after);
  const still = (await call(lim, '/api/codes')).rev; assert.equal(after, still, 'لا يتغير بلا تغييرات (لا تحديثات زائدة)');
});

test('وصول الكود لصاحب الرقم الموزَّع، وللمشرف المحدود في الترافيك، وليس لغيره', async () => {
  await call(owner, '/api/settings', 'POST', { pollSeconds: 3 });
  // مستخدم محلي: نُنشئه مباشرة في الملف عبر API المدير
  const u = await call(owner, '/api/users', 'POST', { username: 'ahmed', name: 'أحمد', password: 'Pass1234a' });
  const u2 = await call(owner, '/api/users', 'POST', { username: 'sara', name: 'سارة', password: 'Pass1234a' });
  userId = u.item.id;
  await call(owner, `/api/domains/${domId}/numbers/assign`, 'POST', { userId, app: 'wa', count: 1 });
  const nums = (await call(owner, `/api/users/${userId}/numbers`)).items; assert.equal(nums.length, 1);
  const myNumber = nums[0].n;
  // رسالة وصلت بعد التوزيع، وساعة اللوحة متأخرة 3 ساعات (انحراف منطقة زمنية)
  msgs.push({ id: 'm1', number: '+' + myNumber, sender: 'WhatsApp', content: 'Your WhatsApp code: 123-456', time: Date.now() - 3 * 3600e3 });
  await call(owner, '/api/bot/run', 'POST'); await sleep(300);
  const login = async (username) => (await call(null, '/api/login', 'POST', { username, password: 'Pass1234a' })).token;
  // المستخدمون المحليون لا يدخلون إلا عبر Clerk في هذا الإعداد؛ ننشئ جلسة من الملف عبر مسار المدير غير متاح، لذلك نتحقق من جهة المدير والمشرف
  const mgrCodes = await call(lim, '/api/codes?scope=owned');
  assert.ok(mgrCodes.items.some((i) => i.c === '123456' && i.u === 'ahmed'), 'الكود ظهر عند المشرف المحدود منسوباً لصاحبه');
  const ownerCodes = await call(owner, '/api/codes?scope=owned');
  assert.ok(ownerCodes.items.some((i) => i.c === '123456' && i.u === 'ahmed'));
  const st = await call(lim, '/api/stats?tz=0'); assert.ok(st.codes >= 1, 'إحصائيات المشرف تحسب الأكواد');
  const un = (await call(owner, '/api/codes?scope=unowned')).items; assert.equal(un.some((i) => i.c === '123456'), false);
});

test('API مع الخادم: لكل حساب مفتاح مستقل، وإيقاف أو تجديد مفتاح لا يمس غيره', async () => {
  const get = (key, hdr = true) => fetch(`http://127.0.0.1:${PORT}/api/v1/messages${hdr ? '' : `?key=${key}`}`, hdr && key ? { headers: { 'X-API-Key': key } } : undefined);
  const k1 = await call(owner, '/api/apikit'), k2 = await call(lim, '/api/apikit');
  assert.match(k1.key, /^nfs_[A-Za-z0-9]{32}$/); assert.match(k2.key, /^nfs_[A-Za-z0-9]{32}$/);
  assert.notEqual(k1.key, k2.key, 'كل حساب له مفتاح مختلف');
  assert.equal(k1.scope, 'all'); assert.equal(k1.canEditUrl, true);
  assert.equal((await get('')).status, 403, 'بلا مفتاح');
  assert.equal((await get('nfs_' + 'x'.repeat(32))).status, 403, 'مفتاح غير موجود');
  assert.equal((await get('wrong')).status, 403);
  const r1 = await (await get(k1.key)).json();
  assert.ok(r1.items.some((i) => i.code === '123456' && i.user === 'ahmed'), 'مفتاح المدير يرى الكود مع صاحبه');
  const r2 = await (await get(k2.key, false)).json().catch(() => null);
  const r2b = await (await get(k2.key)).json();
  assert.ok(r2b.items.some((i) => i.code === '123456'), 'مفتاح المشرف يرى كل الأكواد');
  await call(owner, '/api/apikit', 'POST', { on: false });
  assert.equal((await get(k1.key)).status, 403, 'إيقاف API يوقف المفتاح');
  assert.equal((await get(k2.key)).status, 200, 'إيقاف مفتاح المدير لا يؤثر على غيره');
  await call(owner, '/api/apikit', 'POST', { on: true });
  const old = k1.key, nk = (await call(owner, '/api/apikit', 'POST', { regen: true })).key;
  assert.notEqual(nk, old); assert.equal((await get(old)).status, 403, 'المفتاح القديم يتعطل'); assert.equal((await get(nk)).status, 200);
});
function lim_() { return lim; }

test('مرفقات الدردشة مع الخادم: رفع، وتنزيل لصاحب المحادثة والمشرف فقط', async () => {
  const user = (await call(owner, '/api/users', 'POST', { username: 'filer', name: 'ملف', password: 'Pass1234a' })).item;
  const other = (await call(owner, '/api/users', 'POST', { username: 'other', name: 'آخر', password: 'Pass1234a' })).item;
  assert.ok(user.id && other.id);
  const data = 'data:image/png;base64,' + Buffer.from('PNGDATA-' + 'x'.repeat(50)).toString('base64');
  const r = await call(owner, '/api/chat', 'POST', { id: 'sf1', to: user.id, text: 'مرفق', file: { name: 'a.png', type: 'image/png', size: 58, data } });
  assert.ok(r.item.file.id);
  const get = (tok) => fetch(`http://127.0.0.1:${PORT}/api/chat/file/${r.item.file.id}`, { headers: { Authorization: `Bearer ${tok}` } });
  const ok = await get(owner); assert.equal(ok.status, 200); assert.equal(ok.headers.get('content-type'), 'image/png'); assert.match(await ok.text(), /^PNGDATA-/);
  await assert.rejects(() => call(owner, '/api/chat', 'POST', { to: user.id, text: 'x', file: { name: 'b.exe', type: 'application/x', data: 'not-a-data-url' } }), /غير صالح/);
});
