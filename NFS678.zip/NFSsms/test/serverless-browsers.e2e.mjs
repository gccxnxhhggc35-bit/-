// اختبار حقيقي بلا خادم: متصفح المدير + متصفح المستخدم (متصفحان مختلفان)، وقناة الإشعارات تُحاكى بينهما.
// تشغيل: node test/serverless-browsers.e2e.mjs
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path'; import assert from 'node:assert/strict';
const { chromium } = await import(process.env.PW_MODULE || '/home/claude/.npm-global/lib/node_modules/playwright/index.mjs');
const ROOT = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..', 'static-site');
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.png': 'image/png', '.ico': 'image/x-icon', '.woff2': 'font/woff2', '.webmanifest': 'application/manifest+json' };
const site = http.createServer((q, r) => { let f = path.join(ROOT, decodeURIComponent(q.url.split('?')[0])); if (f.endsWith('/')) f += 'index.html'; fs.readFile(f, (e, b) => { if (e) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream' }); r.end(b); }); });
await new Promise((r) => site.listen(0, r)); const BASE = `http://127.0.0.1:${site.address().port}`;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
// ---- ntfy.sh وهمية مشتركة بين المتصفحين ----
const topics = new Map(); let seq = 0; let PANEL = [];
const T = (n) => topics.get(n) || (topics.set(n, []), topics.get(n));
const cors = { 'access-control-allow-origin': '*', 'access-control-allow-headers': '*', 'access-control-allow-methods': '*' };
async function wire(ctx) {
  await ctx.route('https://ntfy.sh/**', async (route) => {
    const req = route.request(), u = new URL(req.url()), parts = u.pathname.split('/').filter(Boolean), topic = parts[0], kind = parts[1];
    if (req.method() === 'OPTIONS') return route.fulfill({ status: 204, headers: cors });
    if (req.method() === 'POST') { const m = { id: String(++seq), time: Math.floor(Date.now() / 1000), event: 'message', topic, message: req.postData() || '' }; T(topic).push(m); return route.fulfill({ status: 200, headers: { ...cors, 'content-type': 'application/json' }, body: JSON.stringify(m) }); }
    const since = u.searchParams.get('since'), list = T(topic).filter((m) => !/^\d+$/.test(since || '') || Number(m.id) > Number(since));
    if (kind === 'sse') return route.fulfill({ status: 200, headers: { ...cors, 'content-type': 'text/event-stream' }, body: list.map((m) => `event: message\ndata: ${JSON.stringify(m)}\n\n`).join('') || ': keepalive\n\n' });
    return route.fulfill({ status: 200, headers: { ...cors, 'content-type': 'application/x-ndjson' }, body: list.map((m) => JSON.stringify(m)).join('\n') });
  });
  // اللوحة: أي مضيف خارجي غير ntfy يردّ بعناصر اللوحة
  await ctx.route((url) => !/127\.0\.0\.1|ntfy\.sh/.test(url.host), (route) => { const page = new URL(route.request().url()).searchParams.get('page'); route.fulfill({ status: 200, headers: { ...cors, 'content-type': 'application/json' }, body: JSON.stringify(page ? [] : PANEL) }); });
}
async function open(launch, vp) {
  const br = await launch(), ctx = await br.newContext({ viewport: vp, locale: 'ar' }); await wire(ctx);
  const page = await ctx.newPage(), errs = []; page.on('pageerror', (e) => errs.push(String(e)));
  await page.addInitScript(() => { window.__NFS_TEST = 1; }); await page.goto(BASE); return { br, ctx, page, errs };
}
const login = async (s, u, p) => { await s.page.fill('#u', u); await s.page.fill('#p', p); await s.page.click('#lb'); await s.page.waitForSelector('#main', { timeout: 20000 }); };
const api = (s, path_, method = 'GET', body) => s.page.evaluate(([p, m, b]) => window.__nfsLocalApi(p, { method: m, body: b }), [path_, method, body]);
const until = async (fn, ms = 45000, what = '') => { const t0 = Date.now(); for (;;) { try { const v = await fn(); if (v) return v; } catch { /* انتظر */ } if (Date.now() - t0 > ms) throw new Error('انتهت المهلة: ' + what); await sleep(300); } };

const CH2 = process.env.CHROME2 || '/home/claude/.cache/puppeteer/chrome/linux-131.0.6778.204/chrome-linux64/chrome';
const A = await open(() => chromium.launch(), { width: 1280, height: 820 });                                // المدير: Chromium 141
const B = await open(() => chromium.launch({ executablePath: CH2 }), { width: 390, height: 800 });          // المستخدم: Chrome 131 (متصفح آخر)
const C = await open(() => chromium.launch(), { width: 390, height: 800 });                                  // مستخدم آخر (لا يجب أن يرى شيئاً)
await login(A, 'saleh', 'saleh');
await api(A, '/api/panels/prime', 'PUT', { key: 'k' });
const dom = (await api(A, '/api/domains', 'POST', { name: 'syria-wa', apps: ['wa'], access: '*' })).item;
await api(A, `/api/domains/${dom.id}/numbers/import`, 'POST', { text: '963944111222\n963944111333\n963944111444' });
const ub = (await api(A, '/api/users', 'POST', { username: 'userb', name: 'سارة', password: 'Pass1234b' })).item;
const uc = (await api(A, '/api/users', 'POST', { username: 'userc', name: 'خالد', password: 'Pass1234c' })).item;

const t0 = Date.now();
await until(async () => { await B.page.fill('#u', 'userb'); await B.page.fill('#p', 'Pass1234b'); await B.page.click('#lb'); return B.page.waitForSelector('#main', { timeout: 6000 }).then(() => true, () => false); }, 60000, 'دخول المستخدم من متصفح آخر');
console.log(`✔ المستخدم دخل من متصفح آخر بحسابه (مثل التسجيل) بعد ${Date.now() - t0}ms`);
await login(C, 'userc', 'Pass1234c');

// المدير يضيف رقمين للمستخدم + إعلان
await api(A, `/api/domains/${dom.id}/numbers/assign`, 'POST', { userId: ub.id, app: 'wa', count: 2 });
await api(A, '/api/announcements', 'POST', { title: 'إعلان من المدير', body: 'تم تفعيل أرقام جديدة' });
const t1 = Date.now();
const mine = await until(async () => { const r = await api(B, '/api/my/numbers'); return r.items.length === 2 ? r.items : null; }, 60000, 'وصول الأرقام');
console.log(`✔ الأرقام ظهرت في حساب المستخدم بمتصفحه الآخر بعد ${Date.now() - t1}ms:`, mine.map((x) => x.n).join(' ، '));
await until(async () => (await api(B, '/api/domains')).items.some((d) => d.name === 'syria-wa'), 30000, 'وصول النطاق'); console.log('✔ النطاق ظهر عنده');
await until(async () => (await api(B, '/api/announcements')).items.some((x) => x.title === 'إعلان من المدير'), 30000, 'وصول الإعلان'); console.log('✔ الإعلان وصله');
assert.equal((await api(C, '/api/my/numbers')).items.length, 0, 'المستخدم الآخر لا يرى أرقام غيره');
// واجهة المستخدم الفعلية تعرض الأرقام
await B.page.click('#nav .nv[data-t="doms"]'); await sleep(1500); await B.page.screenshot({ path: '/home/claude/shots/sl-user-numbers.png' });

// كود يصل من اللوحة إلى أحد أرقامه: يظهر في صفحة الأكواد عنده فقط
PANEL = [{ id: 'q1', time: new Date().toISOString(), number: mine[0].n, cllr: 'WhatsApp', content: 'Your WhatsApp code: 482-915', agentPayout: '0.003' }];
const t2 = Date.now();
await until(async () => { await B.page.click('#nav .nv[data-t="codes"]'); await sleep(700); return (await B.page.evaluate(() => document.querySelector('#main').innerText)).includes('482915'); }, 90000, 'وصول الكود لصفحة الأكواد');
console.log(`✔ الكود وصل لصفحة الأكواد في حساب المستخدم بمتصفحه الآخر بعد ${Date.now() - t2}ms`);
await B.page.screenshot({ path: '/home/claude/shots/sl-user-codes.png' });
assert.ok(!(await api(C, '/api/codes')).items.some((i) => i.c === '482915'), 'مستخدم آخر لا يرى الكود');
console.log('✔ مستخدم آخر لا يرى الكود');
// المدير يرى الكود منسوباً لصاحبه
assert.ok((await api(A, '/api/codes?scope=owned')).items.some((i) => i.c === '482915' && i.u === 'userb'));
// متصفح رابع يفتح الحساب نفسه لاحقاً: يجب أن يرى الأرقام والكود الموجودين مسبقاً دون أي إجراء من المدير
const D = await open(() => chromium.launch({ executablePath: CH2 }), { width: 390, height: 800 });
await until(async () => { await D.page.fill('#u', 'userb'); await D.page.fill('#p', 'Pass1234b'); await D.page.click('#lb'); return D.page.waitForSelector('#main', { timeout: 6000 }).then(() => true, () => false); }, 60000, 'دخول متصفح جديد');
await until(async () => (await api(D, '/api/my/numbers')).items.length === 2, 60000, 'أرقام المتصفح الجديد');
await until(async () => (await api(D, '/api/codes')).items.some((i) => i.c === '482915'), 60000, 'كود المتصفح الجديد');
console.log('✔ متصفح جديد لنفس الحساب رأى الأرقام والكود السابقين فور الدخول');
await D.page.screenshot({ path: '/home/claude/shots/sl-new-browser.png' }); await D.br.close();
console.log('أخطاء الصفحات:', [...A.errs, ...B.errs, ...C.errs].join(' | ') || 'لا يوجد');
await Promise.all([A, B, C].map((s) => s.br.close())); site.close();
