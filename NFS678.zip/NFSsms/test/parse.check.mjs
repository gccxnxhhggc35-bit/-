import test from 'node:test';
import assert from 'node:assert/strict';
import { extractCode, detectApp, parseNumbers, digitsOnly, cleanText } from '../lib/parse.js';
import { findList, normalizeItem } from '../lib/panels.js';

test('كود واتساب بشرطة يُدمج', () => {
  assert.equal(extractCode('<#> Your WhatsApp account is being registered\nYour WhatsApp code: 448-916\n4sgLq1p5sV6'), '448916');
});
test('كود تيك توك قبل العبارة', () => {
  assert.equal(extractCode('\u001b<TikTok\u001b> 252402 is your verification code, valid for 5 minutes.'), '252402');
});
test('كود عربي', () => {
  assert.equal(extractCode('[#]يُعد [TikTok] 706426 بمثابة رمز التحقق الخاص بك'), '706426');
});
test('الأرقام العربية الهندية تُحوّل', () => {
  assert.equal(extractCode('رمز التحقق الخاص بك ١٢٣٤٥٦'), '123456');
});
test('لا كود في رسالة بلا أرقام', () => {
  assert.equal(extractCode('Welcome to the service'), null);
});
test('تحديد التطبيق', () => {
  assert.equal(detectApp('WhatsApp', ''), 'wa');
  assert.equal(detectApp('', 'Your Telegram code: 12345'), 'tg');
  assert.equal(detectApp('TikTok', ''), 'tt');
  assert.equal(detectApp('XYZ', 'hello'), 'ot');
});
test('تحليل الأرقام: مسافات وأرقام عربية وتكرار ومرفوض', () => {
  const r = parseNumbers('+963 944 111 222\n٠٠١٢٨٤٣٤٠٢٤٩٢\n4790697243, 4790697243\n999\nabc 12\n');
  assert.deepEqual(r.valid.sort(), ['12843402492', '4790697243', '963944111222'].sort());
  assert.equal(r.invalid, 2);
});
test('عدة أرقام في سطر واحد', () => {
  assert.deepEqual(parseNumbers('4790697243 4791182471').valid.sort(), ['4790697243', '4791182471']);
});
test('digitsOnly يزيل 00 البادئة', () => {
  assert.equal(digitsOnly('0044 7911 123456'), '447911123456');
  assert.equal(cleanText('a\u001bb'), 'a b');
});
test('تطبيع رسالة لوحة عامة', () => {
  const list = findList({ data: { items: [{ id: 5, phone: '+1555', text: 'code 1234', from: 'FB', created_at: '2026-01-01T00:00:00Z' }] } });
  const it = normalizeItem(list[0]);
  assert.equal(it.pid, '5'); assert.equal(it.number, '+1555'); assert.equal(it.sender, 'FB');
});

import { tgNumber } from '../lib/parse.js';
test('tgNumber: استخراج الرقم من رسالة تيليجرام', () => {
  assert.equal(tgNumber('📱 Number: +966 512 345 678\nWhatsApp code 123-456\n2026-10-23 11:00', '123456'), '966512345678');
  assert.equal(tgNumber('رقم: 963944111222\nكود: 554433', '554433'), '963944111222');
  assert.equal(tgNumber('Your code is 4455667 for +12025550123', '4455667'), '12025550123');
  assert.equal(tgNumber('code 123456 only'), null);
  assert.equal(tgNumber('٩٦٦٥١٢٣٤٥٦٧٨ كود ١٢٣٤٥٦', '123456'), '966512345678');
});
