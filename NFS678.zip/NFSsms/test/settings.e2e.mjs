// اختبار متصفحات حقيقية: متصفحان مستقلان (مدير + مشرف محدود) يتابعان نفس الخادم
// تشغيل: node test/browser.e2e.mjs   (يحتاج playwright ومتصفحين مثبتين)
import http from 'node:http';
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';
const { chromium } = await import(process.env.PW_MODULE || '/home/claude/.npm-global/lib/node_modules/playwright/index.mjs');

const ROOT = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const SHOTS = process.env.SHOTS || '/home/claude/shots'; fs.mkdirSync(SHOTS, { recursive: true });
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'nfsb-'));
const msgs = [];
const panel = http.createServer((q, r) => { r.writeHead(200, { 'Content-Type': 'application/json' }); r.end(JSON.stringify({ data: msgs })); });
await new Promise((r) => panel.listen(0, r));
const PORT = 4100 + Math.floor(Math.random() * 80), base = `http://127.0.0.1:${PORT}`;
const cfg = JSON.parse(fs.readFileSync(path.join(ROOT, 'config.json'), 'utf8'));
Object.assign(cfg, { port: PORT, activePanel: 'mock', panels: [{ id: 'mock', name: 'Mock', type: 'generic', url: `http://127.0.0.1:${panel.address().port}`, key: 'k', path: '/m', authHeader: 'X-API-Key', authScheme: '', enabled: true }] });
const orig = fs.readFileSync(path.join(ROOT, 'config.json'), 'utf8');
fs.writeFileSync(path.join(ROOT, 'config.json'), JSON.stringify(cfg));
const srv = spawn('node', ['server.js'], { cwd: ROOT, env: { ...process.env, CLERK_SECRET_KEY: '', DATA_DIR: dir, PORT: String(PORT) }, stdio: 'pipe' });
await new Promise((r) => setTimeout(r, 1500)); fs.writeFileSync(path.join(ROOT, 'config.json'), orig);

const api = async (tok, p, m = 'GET', b) => { const r = await fetch(base + p, { method: m, headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${tok}` }, body: b ? JSON.stringify(b) : undefined }); const j = await r.json(); if (!r.ok) throw new Error(p + ' ' + j.error); return j; };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const SH = '/home/claude/shots';
async function run(name, launch, viewport, tag) {
  const br = await launch(), ctx = await br.newContext({ viewport, locale: 'ar' }), page = await ctx.newPage(); const errs = [];
  page.on('pageerror', (e) => errs.push(String(e)));
  await page.route('**/config.js', (r) => r.fulfill({ contentType: 'text/javascript', body: "window.NFS_API='';" }));
  await page.goto(base); await page.fill('#u', 'saleh'); await page.fill('#p', 'saleh'); await page.click('#lb'); await page.waitForSelector('#main');
  await sleep(900); await page.screenshot({ path: `${SH}/${tag}-top.png` });
  // الإعدادات
  await page.click('[data-act=opensettings]'); await sleep(800);
  for (const t of ['ocean', 'emerald', 'amethyst', 'amber', 'night']) { await page.click(`.th6[data-v=${t}]`); await sleep(350); const th = await page.evaluate(() => document.documentElement.dataset.theme); if (th !== t) throw new Error('الثيم لم يُطبَّق ' + t); if (t === 'night') await page.screenshot({ path: `${SH}/${tag}-settings-night.png` }); }
  await page.click('.th6[data-v=ocean]'); await sleep(300);
  await page.click('.sw[data-k=motion]'); const mo = await page.evaluate(() => document.documentElement.dataset.motion); await page.click('.sw[data-k=motion]');
  await page.screenshot({ path: `${SH}/${tag}-settings.png` });
  await page.keyboard.press('Escape'); await page.evaluate(() => document.querySelector('.sheet,.overlay,#sheet')?.click?.()); await sleep(300);
  await page.reload(); await page.waitForSelector('#main'); const kept = await page.evaluate(() => document.documentElement.dataset.theme);
  // API
  await page.evaluate(() => document.querySelector('.sheet-bg,#sheetbg')?.remove());
  await page.click('[data-act=openapi]'); await sleep(900);
  if (!(await page.evaluate(() => document.querySelector('.sw[data-k=apion]').classList.contains('on')))) { await page.click('.sw[data-k=apion]'); await sleep(500); } const on = await page.evaluate(() => document.querySelector('.sw[data-k=apion]').classList.contains('on'));
  await page.click('[data-act=apitest]'); await sleep(800); await page.screenshot({ path: `${SH}/${tag}-api.png` });
  const url = await page.textContent('#apiurl');
  console.log(`${name}: ثيم محفوظ بعد التحديث = ${kept} | الحركات تُطفأ = ${mo} | API مفعّلة = ${on} | الرابط ${url.slice(0, 48)}... | أخطاء = ${errs.length ? errs.join(';') : 'لا يوجد'}`);
  if (kept !== 'ocean' || mo !== 'off' || !on) throw new Error('فشل فحص ' + name);
  await br.close();
}
await run('A-chromium141 سطح مكتب', () => chromium.launch(), { width: 1280, height: 820 }, 'A');
await run('B-chrome131 جوال', () => chromium.launch({ executablePath: '/home/claude/.cache/puppeteer/chrome/linux-131.0.6778.204/chrome-linux64/chrome' }), { width: 390, height: 800 }, 'B');
srv.kill(); panel.close();
