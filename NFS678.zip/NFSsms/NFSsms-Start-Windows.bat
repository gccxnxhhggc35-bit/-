@echo off
setlocal
cd /d "%~dp0"
title NFSsms - Clerk Login
where node >nul 2>nul || (echo Node.js 20.9 or newer is required. & pause & exit /b 1)
where npm >nul 2>nul || (echo npm is required. Reinstall Node.js 20.9 or newer. & pause & exit /b 1)
node -e "const [m,n]=process.versions.node.split('.').map(Number);process.exit(m>20||(m===20&&n>=9)?0:1)" || (echo Please upgrade to Node.js 20.9 or newer. & pause & exit /b 1)
if not exist "node_modules\@clerk\backend" (
  echo Installing NFSsms dependencies for first launch...
  call npm install
  if errorlevel 1 (echo Dependency installation failed. & pause & exit /b 1)
)
start "" powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$u='http://localhost:3000'; for($i=0;$i -lt 45;$i++){try{$r=Invoke-WebRequest -UseBasicParsing -Uri $u -TimeoutSec 1; if($r.StatusCode -ge 200){Start-Process $u; exit}}catch{}; Start-Sleep -Seconds 1}; Start-Process $u"
call npm start
pause
