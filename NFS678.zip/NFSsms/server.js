// NFSsms - خادم Node مع Clerk للتحقق من هوية المستخدم
import http from 'node:http';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createStore } from './lib/store.js';
import { createClerkClient, verifyToken } from '@clerk/backend';
import { hashPassword, verifyPassword, createSession, getSessionUser, destroySession, purgeSessions, loginThrottle, SESSION_DAYS } from './lib/auth.js';
import { APPS, cleanText, detectApp, digitsOnly, extractCode, parseNumbers, tgNumber } from './lib/parse.js';
import { fetchMessages, detectEndpoint, maskKey } from './lib/panels.js';

const ROOT = path.dirname(fileURLToPath(import.meta.url));

// يدعم ملف .env محلياً بدون مكتبة dotenv. لا تضع المفاتيح السرية في ملفات الواجهة.
function loadEnvFile(file) {
  if (!fs.existsSync(file)) return;
  for (const line of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    const m = /^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/.exec(line);
    if (!m || process.env[m[1]] != null) continue;
    let value = m[2] || '';
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1, -1);
    else value = value.replace(/\s+#.*$/, '').trim();
    process.env[m[1]] = value;
  }
}
loadEnvFile(path.join(ROOT, '.env'));

const PUBLIC = path.join(ROOT, 'public');
const config = JSON.parse(fs.readFileSync(path.join(ROOT, 'config.json'), 'utf8'));
const PORT = Number(process.env.PORT || config.port || 3000);
const CLERK_SECRET_KEY = String(process.env.CLERK_SECRET_KEY || '').trim();
const CLERK_PUBLISHABLE_KEY = String(process.env.NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY || process.env.CLERK_PUBLISHABLE_KEY || 'pk_test_cHJlbWl1bS12dWx0dXJlLTk2NzAuY2xlcmsuYWNjb3VudHMuZGV2JA').trim();
const CLERK_AUTHORIZED_PARTIES = String(process.env.CLERK_AUTHORIZED_PARTIES || '').split(',').map((s) => s.trim()).filter(Boolean);
const clerkClient = CLERK_SECRET_KEY ? createClerkClient({ secretKey: CLERK_SECRET_KEY }) : null;
const ADMIN_EMAIL = String(process.env.ADMIN_EMAIL || '').trim().toLowerCase();
const store = createStore(process.env.DATA_DIR || path.join(ROOT, 'data'), config);
const { core } = store;
// عند تفعيل Clerk، أبطل جلسات الدخول المحلي القديمة مرة واحدة حتى لا تتجاوز تسجيل الدخول الجديد.
if (CLERK_SECRET_KEY && Object.keys(core.sessions || {}).length) {
  core.sessions = {};
  store.touch('core');
  store.flush();
}
const MAX_MESSAGES = 5000;

/* ---------------- أدوات ---------------- */
class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}
const bad = (m) => new HttpError(400, m);
const publicUser = (u) => ({ id: u.id, username: u.username, name: u.name, role: u.role, email: u.email || '', authProvider: u.clerkId ? 'clerk' : 'local' });
const isFullAdmin = (u) => u?.role === 'admin';
const isLimitedAdmin = (u) => u?.role === 'limited_admin';
const canManageUsersAndDomains = (u) => isFullAdmin(u) || isLimitedAdmin(u);
const isPrivilegedAccount = (u) => isFullAdmin(u) || isLimitedAdmin(u);
const clampInt = (v, min, max, d) => { if (v == null || v === '') return d; const n = Math.trunc(Number(v)); return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : d; };
const str = (v, max = 200) => String(v ?? '').trim().slice(0, max);

function send(res, status, body, headers = {}) {
  const isObj = typeof body === 'object' && !Buffer.isBuffer(body);
  res.writeHead(status, {
    'Content-Type': isObj ? 'application/json; charset=utf-8' : 'text/plain; charset=utf-8',
    'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', 'X-Rev': String(store.rev), ...headers,
  });
  res.end(isObj ? JSON.stringify(body) : body);
}

function readBody(req, limit = 8 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    const chunks = []; let size = 0;
    req.on('data', (c) => { size += c.length; if (size > limit) { reject(new HttpError(413, 'الملف كبير جداً')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); } catch { reject(bad('طلب غير صالح')); }
    });
    req.on('error', reject);
  });
}

function parseCookies(h) {
  const out = {};
  for (const part of String(h || '').split(';')) { const i = part.indexOf('='); if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim()); }
  return out;
}

/* ---------------- منطق الأرقام والرسائل ---------------- */
const today = () => Date.now();
const dayKey = (t, tz) => Math.floor((t - tz * 60000) / 864e5);

function domainOf(id) { return core.domains.find((d) => d.id === Number(id)); }
function userOf(id) { return core.users.find((u) => u.id === id); }
function canSeeDomain(user, d) { return canManageUsersAndDomains(user) || d.access === '*' || (Array.isArray(d.access) && d.access.includes(user.id)) || store.numbers.some((r) => r.d === d.id && r.u === user.id); }

function domainCounts() {
  const m = new Map();
  for (const r of store.numbers) {
    const c = m.get(r.d) || { total: 0, free: 0, assigned: 0 };
    c.total++; r.u ? c.assigned++ : c.free++;
    m.set(r.d, c);
  }
  return m;
}

function assignNumbers(domainId, userId, app, count) {
  const picked = [];
  const now = Date.now();
  for (const r of store.numbers) {
    if (picked.length >= count) break;
    if (r.d === domainId && !r.u) { r.u = userId; r.a = app; r.t = now; picked.push(r); }
  }
  if (picked.length) store.touch('numbers');
  return picked.length;
}

// الرسائل التي تعود لمستخدم (الملكية تُحسب لحظة الطلب: الرقم موزّع والرسالة وصلت بعد التوزيع)
function messageOwner(m) {
  const r = store.lookupNumber(m.n);
  if (r && r.u && m.t >= r.t - 60000) return r;
  return null;
}

function ownedMessages(userId) {
  const out = [];
  for (let i = store.messages.length - 1; i >= 0; i--) {
    const m = store.messages[i];
    const r = messageOwner(m);
    if (userId == null || (r && r.u === userId)) out.push({ m, r });
  }
  return out;
}

function ingest(panel, items) {
  const seen = ingest.seen ||= new Set(store.messages.map((m) => m.k));
  let added = 0;
  const warm = (ingest.warm ||= new Set(store.messages.map((m) => m.p)));
  const wasWarm = warm.has(panel.id) && panel.id !== 'tg';
  warm.add(panel.id);
  for (const it of items) {
    const k = `${panel.id}:${it.pid}`;
    if (seen.has(k)) continue;
    seen.add(k);
    // رسالة جديدة لم نرها في الدورات السابقة، لكن ختمها الزمني بعيد عن الآن (ساعة/منطقة زمنية مختلفة في اللوحة):
    // نعتمد وقت وصولها عندنا، وإلا سقط الكود لأن وقته يسبق توزيع الرقم فلا يصل لصاحبه.
    const skew = Math.abs(Date.now() - it.time);
    if (wasWarm && skew > 120e3 && skew <= 15 * 3600e3) it.time = Date.now();
    const content = cleanText(it.content).slice(0, 600);
    store.messages.push({
      k, p: panel.id, n: digitsOnly(it.number), s: cleanText(it.sender).slice(0, 60), x: content,
      c: extractCode(content), a: detectApp(it.sender, content), t: it.time, r: Date.now(),
    });
    added++;
  }
  if (added) {
    store.messages.sort((a, b) => a.t - b.t);
    if (store.messages.length > MAX_MESSAGES) store.messages.splice(0, store.messages.length - MAX_MESSAGES);
    store.touch('messages');
  }
  return added;
}

/* ---------------- البوت ---------------- */
const bot = { last: null, newTotal: 0, panels: {}, running: false };
function activePanels() {
  const a = core.settings.activePanel;
  if (a === 'all') return core.panels.filter((p) => p.enabled);
  return core.panels.filter((p) => p.id === a && p.enabled);
}
/* ---------------- مصدر تيليجرام ---------------- */
const tg = { ok: null, error: '', at: 0, got: 0, skipped: 0, bot: '' };
const tgActive = () => !!(core.settings.tgOn && core.settings.tgToken);
async function fetchTelegram() {
  const st = core.settings; if (!tgActive()) return 0;
  const base = 'https://api.telegram.org/bot' + st.tgToken, get = async (p) => (await fetch(base + p, { signal: AbortSignal.timeout(15000) })).json();
  try {
    if (!tg.bot) { const me = await get('/getMe'); if (me.ok) tg.bot = '@' + me.result.username; }
    const q = `?timeout=0&limit=100&offset=${Number(st.tgOffset) || 0}&allowed_updates=${encodeURIComponent('["message","edited_message","channel_post","edited_channel_post"]')}`;
    let j = await get('/getUpdates' + q);
    if (!j.ok && j.error_code === 409 && /webhook/i.test(j.description || '')) { await get('/deleteWebhook'); j = await get('/getUpdates' + q); }
    if (!j.ok) {
      tg.ok = false; tg.at = Date.now();
      tg.error = j.error_code === 401 ? 'توكن البوت غير صحيح' : j.error_code === 409 ? 'البوت يقرأ منه برنامج آخر الآن، استخدم بوتاً مخصصاً لـ NFSsms' : String(j.description || 'خطأ من تيليجرام').slice(0, 120);
      return 0;
    }
    const items = []; let last = Number(st.tgOffset) || 0;
    for (const u of j.result) {
      last = Math.max(last, u.update_id + 1);
      const m = u.message || u.edited_message || u.channel_post || u.edited_channel_post, text = m && (m.text || m.caption);
      if (!text) continue;
      const number = tgNumber(text, extractCode(text));
      if (!number) { tg.skipped++; continue; }
      items.push({ pid: `${m.chat.id}:${m.message_id}`, number, sender: m.forward_from_chat?.title || m.forward_sender_name || m.chat.title || m.from?.first_name || 'Telegram', content: text, time: (m.date || 0) * 1000 || Date.now() });
    }
    if (last !== (Number(st.tgOffset) || 0)) { st.tgOffset = last; store.touch('core', true); }
    const added = ingest({ id: 'tg' }, items);
    tg.ok = true; tg.error = ''; tg.at = Date.now(); tg.got += added; bot.newTotal += added;
    return added;
  } catch { tg.ok = false; tg.error = 'تعذر الوصول لتيليجرام'; tg.at = Date.now(); return 0; }
}
async function runBot(force = false) {
  if (bot.running || (!core.settings.botOn && !force)) return;
  bot.running = true;
  try {
    await fetchTelegram();
    for (const p of activePanels()) {
      try {
        const r = await fetchMessages(p);
        const added = ingest(p, r.items);
        bot.newTotal += added;
        bot.panels[p.id] = { ok: true, ms: r.ms, count: r.items.length, added, at: Date.now() };
      } catch (e) {
        bot.panels[p.id] = { ok: false, error: String(e.message || e).slice(0, 160), ms: e.ms, at: Date.now() };
      }
    }
    bot.last = Date.now();
  } finally { bot.running = false; }
}
function scheduleBot() {
  setTimeout(async () => { await runBot().catch(() => {}); scheduleBot(); }, clampInt(core.settings.pollSeconds, 3, 120, 8) * 1000);
}

/* ---------------- الإحصائيات ---------------- */
function buildStats(user, tz) {
  const isAdmin = canManageUsersAndDomains(user); // المدير الكامل والمشرف المحدود يريان لوحة الإدارة كاملة
  const now = Date.now();
  const owned = ownedMessages(isAdmin ? null : user.id).filter((x) => x.m.c);
  const todayKey = dayKey(now, tz);
  const series = Array.from({ length: 7 }, (_, i) => ({ day: (todayKey - 6 + i) * 864e5 + tz * 60000, n: 0 }));
  const apps = {};
  let todayCount = 0; let mine = 0;
  for (const { m, r } of owned) {
    if (isAdmin && !r) continue; // الإحصائيات تحسب الأكواد الموزعة فقط
    mine++;
    const k = dayKey(m.t, tz);
    if (k === todayKey) todayCount++;
    const idx = k - (todayKey - 6);
    if (idx >= 0 && idx < 7) series[idx].n++;
    apps[m.a] = (apps[m.a] || 0) + 1;
  }
  const price = Number(core.settings.pricePerCode) || 0;
  const base = {
    codes: mine, codesToday: todayCount, series, price, earnings: +(mine * price).toFixed(3),
    apps: Object.entries(apps).map(([k, n]) => ({ k, n })).sort((a, b) => b.n - a.n),
  };
  if (!isAdmin) {
    const mineNums = store.numbers.filter((r) => r.u === user.id);
    return { ...base, numbers: mineNums.length, pending: core.requests.filter((r) => r.userId === user.id && r.status === 'pending').length,
      byApp: Object.entries(mineNums.reduce((a, r) => ((a[r.a] = (a[r.a] || 0) + 1), a), {})).map(([k, n]) => ({ k, n })) };
  }
  const total = store.numbers.length;
  const assigned = store.numbers.reduce((n, r) => n + (r.u ? 1 : 0), 0);
  let unowned = 0;
  for (const m of store.messages) if (m.c && !messageOwner(m)) unowned++;
  const perUser = {};
  for (const { m, r } of owned) if (r) perUser[r.u] = (perUser[r.u] || 0) + 1;
  const active = core.settings.activePanel;
  return {
    ...base, users: core.users.filter((u) => !isPrivilegedAccount(u)).length, domains: core.domains.length,
    numbers: total, assigned, free: total - assigned, unowned, pending: core.requests.filter((r) => r.status === 'pending').length,
    top: Object.entries(perUser).map(([id, n]) => ({ id: +id, name: userOf(+id)?.name || '—', username: userOf(+id)?.username || '', n })).sort((a, b) => b.n - a.n).slice(0, 5),
    bot: botStatus(), activePanel: active,
  };
}

function botStatus() {
  return {
    on: !!core.settings.botOn, last: bot.last, newTotal: bot.newTotal, running: bot.running,
    panels: Object.fromEntries(Object.entries(bot.panels)),
    tg: { on: tgActive(), ok: tg.ok, error: tg.error, at: tg.at, got: tg.got, skipped: tg.skipped, bot: tg.bot },
  };
}

function panelDto(p) {
  return { id: p.id, name: p.name, type: p.type, url: p.url, path: p.path, authHeader: p.authHeader, authScheme: p.authScheme, enabled: p.enabled, keyMask: maskKey(p.key), hasKey: !!p.key, status: bot.panels[p.id] || null };
}

/* ---------------- المسارات ---------------- */
const routes = [];
const route = (method, pattern, opts, handler) => routes.push({ method, re: new RegExp(`^${pattern.replace(/:(\w+)/g, '(?<$1>[^/]+)')}$`), opts, handler });
const AUTH = { auth: true }; const ADMIN = { auth: true, admin: true }; const MANAGER = { auth: true, manager: true }; const OPEN = {};

const lockouts = new Map(); // اسم المستخدم -> { n, t } : قفل الحساب 15 دقيقة بعد 10 محاولات خاطئة
const LOCK_MS = 15 * 60e3;
function lockState(name) {
  const s = lockouts.get(name) || { n: 0, t: 0 };
  if (Date.now() - s.t > LOCK_MS) s.n = 0;
  return s;
}
// دخول باسم مستخدم للحسابين المحليين المصرّح بهما: saleh (المدير المهيّأ) و1Whisper (مشرف محدود).
// جميع الحسابات الأخرى تستعمل Clerk بالبريد؛ لا نسمح بتجربة كلمات سر بقية المستخدمين القدامى عبر هذا المسار.
route('POST', '/api/login', OPEN, async ({ body, ip, secure }) => {
  const username = str(body.username, 24).toLowerCase().replace(/\s+/g, '');
  const password = String(body.password || '');
  const ownerUsername = String(store.adminUsername || config.adminUsername || '').trim().toLowerCase();
  const limitedLogin = username === '1whisper';
  const ownerLogin = !!ownerUsername && username === ownerUsername;
  if (!limitedLogin && !ownerLogin) {
    throw new HttpError(400, 'استخدم البريد الإلكتروني مع كلمة السر لهذا الحساب. اسم المستخدم مسموح لحساب المدير المهيّأ فقط.');
  }
  if (!loginThrottle(ip || 'unknown', null)) throw new HttpError(429, 'محاولات دخول كثيرة. انتظر 10 دقائق ثم حاول مجدداً.');
  const user = core.users.find((u) => String(u.username || '').toLowerCase() === username &&
    (limitedLogin ? u.role === 'limited_admin' : u.role === 'admin'));
  const valid = !!(user && !user.disabled && await verifyPassword(user, password));
  if (!loginThrottle(ip || 'unknown', valid)) throw new HttpError(429, 'محاولات دخول كثيرة. انتظر 10 دقائق ثم حاول مجدداً.');
  if (!valid) throw new HttpError(401, 'اسم المستخدم أو كلمة السر غير صحيحة');
  const token = createSession(store, user.id);
  return { body: { user: publicUser(user), token }, headers: { 'Set-Cookie': `nfs_sid=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${SESSION_DAYS * 86400}${secure ? '; Secure' : ''}` } };
});

route('POST', '/api/clerk/session', OPEN, async ({ body, secure }) => {
  if (!clerkClient || !CLERK_SECRET_KEY) throw new HttpError(503, 'إعداد Clerk غير مكتمل. أضف CLERK_SECRET_KEY إلى ملف .env ثم أعد تشغيل الخادم.');
  const clerkToken = typeof body.token === 'string' ? body.token.trim() : '';
  if (!clerkToken || clerkToken.length > 12000) throw new HttpError(401, 'جلسة Clerk غير صالحة');

  let claims;
  try {
    claims = await verifyToken(clerkToken, {
      secretKey: CLERK_SECRET_KEY,
      ...(CLERK_AUTHORIZED_PARTIES.length ? { authorizedParties: CLERK_AUTHORIZED_PARTIES } : {}),
    });
  } catch {
    throw new HttpError(401, 'تعذر التحقق من جلسة Clerk. سجّل الدخول من جديد.');
  }
  if (!claims?.sub) throw new HttpError(401, 'جلسة Clerk لا تحتوي على معرّف مستخدم');

  let clerkUser;
  try {
    clerkUser = await clerkClient.users.getUser(claims.sub);
  } catch {
    throw new HttpError(401, 'تعذر العثور على حساب Clerk هذا');
  }

  const primaryEmail = (clerkUser.emailAddresses || []).find((e) => e.id === clerkUser.primaryEmailAddressId);
  const email = String(primaryEmail?.emailAddress || '').trim().toLowerCase();
  if (!email || primaryEmail?.verification?.status !== 'verified') {
    throw new HttpError(403, 'يجب تأكيد البريد الإلكتروني في Clerk قبل دخول لوحة التحكم');
  }

  const isOwner = !!ADMIN_EMAIL && email === ADMIN_EMAIL;
  let user = core.users.find((u) => u.clerkId === clerkUser.id)
    || core.users.find((u) => String(u.email || '').toLowerCase() === email);

  // اربط حساب المدير المحلي القديم بحساب Clerk الموثّق المحدد في ADMIN_EMAIL للمحافظة على بياناته.
  if (!user && isOwner) {
    user = core.users.find((u) => u.role === 'admin' && !u.clerkId && (!store.adminUsername || u.username === store.adminUsername));
  }

  if (user?.disabled) throw new HttpError(403, 'هذا الحساب معطّل. تواصل مع مدير النظام.');
  if (isLimitedAdmin(user) && !isOwner) {
    throw new HttpError(403, 'حساب 1Whisper مخصص للدخول الإداري المحدود باستخدام اسم المستخدم وكلمة السر.');
  }
  if (user?.role === 'admin' && !isOwner && user.clerkId !== clerkUser.id) {
    throw new HttpError(403, 'هذا الحساب الإداري غير مرتبط ببريد المدير المحدد في إعدادات الخادم');
  }

  const wasUnlinked = !!user && !user.clerkId;
  if (!user) {
    const rawBase = String(email.split('@')[0] || 'user').toLowerCase().replace(/[^a-z0-9_.]/g, '').slice(0, 20);
    const base = rawBase.length >= 3 ? rawBase : `${rawBase}_user`.slice(0, 24);
    let username = base || 'user_account';
    let suffix = 1;
    while (core.users.some((u) => u.username === username)) {
      const tail = String(suffix++);
      username = `${base.slice(0, Math.max(3, 24 - tail.length))}${tail}`;
    }
    user = {
      id: ++core.seq.user, username, name: String(clerkUser.fullName || email.split('@')[0]).slice(0, 60),
      role: isOwner ? 'admin' : 'user', disabled: false, createdAt: Date.now(),
    };
    core.users.push(user);
  }

  user.email = email;
  user.clerkId = clerkUser.id;
  if (isOwner) user.role = 'admin';
  else if (!isPrivilegedAccount(user)) user.role = 'user';
  if (!user.name || wasUnlinked) user.name = String(clerkUser.fullName || (isOwner ? 'المدير' : email.split('@')[0])).slice(0, 60);
  // تبقى بيانات دخول المدير المهيّأ محلياً متاحة له (saleh/كلمة المرور المضبوطة)؛ بقية حسابات Clerk لا تحتفظ بكلمة سر محلية.
  if (!(user.role === 'admin' && user.username === String(store.adminUsername || '').toLowerCase())) {
    delete user.hash; delete user.salt; delete user.sha256;
  }
  store.touch('core');

  const token = createSession(store, user.id);
  return {
    body: { user: publicUser(user), token },
    headers: { 'Set-Cookie': `nfs_sid=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${SESSION_DAYS * 86400}${secure ? '; Secure' : ''}` },
  };
});
route('POST', '/api/logout', OPEN, ({ token }) => { destroySession(store, token); return { body: { ok: true }, headers: { 'Set-Cookie': 'nfs_sid=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0' } }; });
route('GET', '/api/me', AUTH, ({ user }) => ({ user: publicUser(user), apps: Object.fromEntries(Object.entries(APPS).map(([k, v]) => [k, v.name])), settings: { price: core.settings.pricePerCode } }));
route('POST', '/api/me/password', AUTH, async ({ user, body }) => {
  if (user.clerkId) throw bad('تُدار كلمة سر هذا الحساب عبر Clerk؛ استخدم استعادة كلمة السر من شاشة الدخول.');
  if (!(await verifyPassword(user, String(body.current || '')))) throw bad('كلمة السر الحالية غير صحيحة');
  if (String(body.next || '').length < 6) throw bad('كلمة السر الجديدة 6 أحرف على الأقل');
  Object.assign(user, await hashPassword(String(body.next))); delete user.sha256;
  if (isLimitedAdmin(user)) core.limitedAdminFp = crypto.createHash('sha256').update(`1Whisper\n${String(body.next)}`).digest('hex');
  store.touch('core'); return { ok: true };
});

route('GET', '/api/stats', AUTH, ({ user, query }) => buildStats(user, clampInt(query.get('tz'), -840, 840, 0)));

route('GET', '/api/codes', AUTH, ({ user, query }) => {
  const scope = query.get('scope') || 'all';
  const items = [];
  const mgr = canManageUsersAndDomains(user);
  for (const { m, r } of ownedMessages(mgr ? null : user.id)) {
    if (mgr && scope === 'owned' && !r) continue;
    if (mgr && scope === 'unowned' && r) continue;
    items.push({ id: m.k, n: m.n, a: m.a, c: m.c, x: m.c ? undefined : m.x.slice(0, 120), s: m.s, t: m.t, u: r ? userOf(r.u)?.username || null : null, un: r ? userOf(r.u)?.name || null : null, p: core.panels.find((p) => p.id === m.p)?.name || '' });
    if (items.length >= 150) break;
  }
  return { items, bot: botStatus(), rev: store.rev };
});

/* ---------- التواصل مع الدعم ---------- */
const CHAT_FILES = path.join(process.env.DATA_DIR || path.join(ROOT, 'data'), 'chat-files');
const chatThread = (uid) => ((core.chat ||= {})[uid] ||= []);
route('GET', '/api/chat', AUTH, ({ user, query }) => {
  if (!canManageUsersAndDomains(user)) return { items: chatThread(user.id).slice(-200) };
  const u = Number(query.get('u'));
  if (u) { const x = core.users.find((y) => y.id === u); return { items: chatThread(u).slice(-200), user: x ? { id: x.id, username: x.username, name: x.name } : null }; }
  const threads = Object.entries(core.chat || {}).filter(([, t]) => t.length).map(([uid, t]) => { const x = core.users.find((y) => y.id === Number(uid)), l = t[t.length - 1]; return { uid: Number(uid), username: x?.username || '', name: x?.name || '', last: l.text.slice(0, 80), from: l.from, t: l.t, n: t.length }; }).sort((a, b) => b.t - a.t);
  return { threads };
});
route('POST', '/api/chat', AUTH, ({ user, body }) => {
  const mgr = canManageUsersAndDomains(user), uid = mgr ? Number(body.to) : user.id;
  if (!uid || !core.users.some((x) => x.id === uid)) throw bad('المستخدم غير موجود');
  const text = String(body.text ?? '').trim().slice(0, 2000);
  let file = null;
  if (body.file) {
    const mm = /^data:([\w.+-]+\/[\w.+-]+);base64,([A-Za-z0-9+/=]+)$/.exec(String(body.file.data || '')); if (!mm) throw bad('ملف غير صالح');
    const buf = Buffer.from(mm[2], 'base64'); if (buf.length > 5 * 1024 * 1024) throw bad('الحد الأقصى للملف 5MB');
    const fid = crypto.randomBytes(12).toString('hex'); fs.mkdirSync(CHAT_FILES, { recursive: true }); fs.writeFileSync(path.join(CHAT_FILES, fid), buf);
    file = { id: fid, name: String(body.file.name || 'file').replace(/[\\/\r\n"]/g, '_').slice(0, 120), type: mm[1].slice(0, 80), size: buf.length };
  }
  if (!text && !file) throw bad('اكتب رسالة');
  const item = { id: String(body.id || '').replace(/[^\w-]/g, '').slice(0, 40) || 'c' + Date.now().toString(36), from: mgr ? 's' : 'u', name: user.name || user.username, text, t: Date.now(), ...(file ? { file } : {}) };
  const th = chatThread(uid); if (!th.some((m) => m.id === item.id)) th.push(item);
  if (th.length > 300) th.splice(0, th.length - 300);
  store.touch('core'); return { item };
});

route('GET', '/api/chat/file/:id', AUTH, ({ user, params }) => {
  const id = String(params.id || '').replace(/[^\w]/g, ''); let owner = null, f = null;
  for (const [uid, th] of Object.entries(core.chat || {})) { const m = th.find((x) => x.file && x.file.id === id); if (m) { owner = Number(uid); f = m.file; break; } }
  if (!f) throw new HttpError(404, 'الملف غير موجود');
  if (!canManageUsersAndDomains(user) && owner !== user.id) throw new HttpError(403, 'غير مسموح');
  const inline = /^(image\/(png|jpe?g|gif|webp)|video\/(mp4|webm|quicktime))$/.test(f.type);
  return { raw: fs.readFileSync(path.join(CHAT_FILES, id)), type: inline ? f.type : 'application/octet-stream', headers: { 'Content-Disposition': `${inline ? 'inline' : 'attachment'}; filename*=UTF-8''${encodeURIComponent(f.name)}`, 'Cache-Control': 'private, max-age=3600' } };
});
/* ---------- واجهة API للبوتات (مع الخادم) ---------- */
/* مفتاح API بصيغة nfs_ + 32 حرفاً ورقماً. الموقع يتعرف على أي مفتاح يبدأ بـ nfs ويطابقه مع المخزَّن */
const KEY_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
const NFS_KEY_RE = /^nfs_[A-Za-z0-9]{32}$/;
const genApiKey = () => { const b = crypto.randomBytes(32); let k = ''; for (let i = 0; i < 32; i++) k += KEY_CHARS[b[i] % KEY_CHARS.length]; return 'nfs_' + k; };
const cleanSiteUrl = (v) => { const t = String(v || '').trim().replace(/\/+$/, ''); if (!t) return ''; if (!/^https?:\/\/[^\s/?#]+(\/[^\s?#]*)?$/i.test(t)) throw bad('رابط الموقع غير صالح، مثال: https://example.com'); return t.slice(0, 200); };
const sameKey = (a, b) => { const x = Buffer.from(String(a)), y = Buffer.from(String(b)); return x.length === y.length && crypto.timingSafeEqual(x, y); };
const apiKitOf = (u) => {
  if (!NFS_KEY_RE.test(u.apiKey || '')) {
    // ترحيل: مفتاح النظام القديم يصبح مفتاح المدير الكامل، وبقية الحسابات تنال مفتاحاً خاصاً بها
    u.apiKey = u.role === 'admin' && NFS_KEY_RE.test(core.settings.apiKey || '') ? core.settings.apiKey : genApiKey();
    if (u.apiOn == null && u.role === 'admin' && core.settings.apiOn != null) u.apiOn = !!core.settings.apiOn;
    store.touch('core', true);
  }
  if (u.apiOn == null) u.apiOn = true;
  const mgr = canManageUsersAndDomains(u);
  return { on: !!u.apiOn, mode: 'server', key: u.apiKey, siteUrl: core.settings.siteUrl || '', read: '/api/v1/messages', scope: mgr ? 'all' : 'own', canEditUrl: mgr, last: u.apiLast || 0 };
};
// لكل حساب مفتاح API مستقل: المستخدم يرى أكواده فقط، والمدير/المشرف يريان كل الأكواد
route('GET', '/api/apikit', AUTH, ({ user }) => apiKitOf(user));
route('POST', '/api/apikit', AUTH, ({ user, body }) => {
  if (body.on != null) user.apiOn = !!body.on;
  if (body.siteUrl != null) {
    if (!canManageUsersAndDomains(user)) throw new HttpError(403, 'رابط الموقع يضبطه المدير فقط');
    core.settings.siteUrl = cleanSiteUrl(body.siteUrl);
  }
  if (body.regen) user.apiKey = genApiKey();
  apiKitOf(user); store.touch('core'); return apiKitOf(user);
});
route('POST', '/api/apikit/test', AUTH, ({ user }) => {
  const t0 = Date.now(), n = ownedMessages(canManageUsersAndDomains(user) ? null : user.id).filter(({ m }) => m.c).length;
  return { ok: !!user.apiOn, ms: Date.now() - t0, url: '/api/v1/messages', codes: n };
});
route('GET', '/api/v1/messages', OPEN, ({ req, query }) => {
  const hdr = req.headers['x-api-key'] || (/^Bearer\s+(nfs_\S+)$/i.exec(req.headers.authorization || '') || [])[1] || '';
  const given = String(hdr || query.get('key') || '').trim();
  if (!given.startsWith('nfs') || !NFS_KEY_RE.test(given)) throw new HttpError(403, 'مفتاح API غير صحيح، يجب أن يبدأ بـ nfs_');
  const owner = core.users.find((u) => u.apiKey && sameKey(given, u.apiKey));
  if (!owner || owner.disabled) throw new HttpError(403, 'مفتاح API غير صحيح، يجب أن يبدأ بـ nfs_');
  if (owner.apiOn === false) throw new HttpError(403, 'خدمة API متوقفة لهذا الحساب');
  owner.apiLast = Date.now();
  const since = Number(query.get('since')) || 0, num = digitsOnly(query.get('number') || ''), limit = Math.min(200, Number(query.get('limit')) || 50), items = [];
  for (const { m, r } of ownedMessages(canManageUsersAndDomains(owner) ? null : owner.id)) {
    if (!m.c || m.t <= since || (num && !String(m.n).endsWith(num))) continue;
    const u = r ? core.users.find((x) => x.id === r.u) : null;
    items.push({ id: m.k, number: m.n, app: m.a, code: m.c, sender: m.s, text: m.x, time: m.t, user: u ? u.username : null });
    if (items.length >= limit) break;
  }
  return { ok: true, items: items.reverse() };
});

route('GET', '/api/my/numbers', AUTH, ({ user }) => {
  const last = new Map();
  for (const { m, r } of ownedMessages(user.id)) if (m.c && !last.has(r.id)) last.set(r.id, { c: m.c, t: m.t, a: m.a });
  const items = store.numbers.filter((r) => r.u === user.id).map((r) => ({ id: r.id, n: r.n, a: r.a, d: r.d, dn: domainOf(r.d)?.name || '', t: r.t, last: last.get(r.id) || null }));
  items.sort((a, b) => b.t - a.t);
  return { items };
});

/* النطاقات */
route('GET', '/api/domains', AUTH, ({ user }) => {
  const counts = domainCounts();
  const mine = {};
  for (const r of store.numbers) if (r.u === user.id) (mine[r.d] ||= {})[r.a] = (mine[r.d][r.a] || 0) + 1;
  const items = core.domains.filter((d) => canSeeDomain(user, d)).map((d) => {
    const c = counts.get(d.id) || { total: 0, free: 0, assigned: 0 };
    return { id: d.id, name: d.name, apps: d.apps, access: d.access, createdAt: d.createdAt, ...(canManageUsersAndDomains(user) ? c : { free: c.free > 0 }), mine: mine[d.id] || {} };
  });
  return { items };
});
function cleanDomainInput(body, partial) {
  const out = {};
  if (!partial || body.name != null) {
    const name = str(body.name, 120).toLowerCase();
    if (!/^[a-z0-9\u0600-\u06ff][a-z0-9\u0600-\u06ff._-]{0,118}$/.test(name)) throw bad('اسم النطاق غير صالح');
    out.name = name;
  }
  if (!partial || body.apps != null) {
    const apps = [...new Set((Array.isArray(body.apps) ? body.apps : []).filter((a) => APPS[a] && a !== 'ot'))];
    if (!apps.length) throw bad('اختر تطبيقاً واحداً على الأقل');
    out.apps = apps;
  }
  if (!partial || body.access != null) {
    out.access = body.access === '*' ? '*' : (Array.isArray(body.access) ? body.access.map(Number).filter((id) => userOf(id)) : []);
  }
  return out;
}
route('POST', '/api/domains', MANAGER, ({ body }) => {
  const d = cleanDomainInput(body, false);
  if (core.domains.some((x) => x.name === d.name)) throw bad('هذا النطاق موجود مسبقاً');
  const rec = { id: ++core.seq.domain, createdAt: Date.now(), ...d };
  core.domains.push(rec); store.touch('core'); return { item: rec };
});
route('PATCH', '/api/domains/:id', ADMIN, ({ params, body }) => {
  const d = domainOf(params.id); if (!d) throw new HttpError(404, 'النطاق غير موجود');
  const upd = cleanDomainInput(body, true);
  if (upd.name && core.domains.some((x) => x.name === upd.name && x.id !== d.id)) throw bad('هذا الاسم مستخدم');
  Object.assign(d, upd); store.touch('core'); return { item: d };
});
route('DELETE', '/api/domains/:id', ADMIN, ({ params }) => {
  const d = domainOf(params.id); if (!d) throw new HttpError(404, 'النطاق غير موجود');
  const keep = store.numbers.filter((r) => r.d !== d.id);
  store.numData.items = keep; store.reindex(); store.touch('numbers');
  core.domains = core.domains.filter((x) => x.id !== d.id);
  core.requests = core.requests.filter((r) => r.domainId !== d.id);
  store.touch('core'); return { ok: true };
});
route('GET', '/api/domains/:id/numbers', MANAGER, ({ params, query }) => {
  const d = domainOf(params.id); if (!d) throw new HttpError(404, 'النطاق غير موجود');
  const filter = query.get('filter') || 'all'; const q = digitsOnly(query.get('q') || '');
  const offset = clampInt(query.get('offset'), 0, 1e7, 0); const limit = clampInt(query.get('limit'), 1, 200, 100);
  const list = store.numbers.filter((r) => r.d === d.id && (filter === 'all' || (filter === 'free' ? !r.u : !!r.u)) && (!q || r.n.includes(q)));
  const items = list.slice(offset, offset + limit).map((r) => ({ id: r.id, n: r.n, u: r.u, un: r.u ? userOf(r.u)?.username : null, a: r.a, t: r.t }));
  return { total: list.length, items };
});
route('POST', '/api/domains/:id/numbers/import', MANAGER, ({ params, body }) => {
  const d = domainOf(params.id); if (!d) throw new HttpError(404, 'النطاق غير موجود');
  const { valid, invalid } = parseNumbers(body.text);
  let added = 0; let duplicates = 0; const now = Date.now();
  for (const n of valid) {
    if (store.lookupNumber(n)?.n === n) { duplicates++; continue; }
    store.numbers.push({ id: store.nextNumberId(), d: d.id, n, u: null, a: null, t: 0, c: now });
    added++;
  }
  if (added) { store.reindex(); store.touch('numbers'); }
  return { added, duplicates, invalid, total: valid.length };
});
route('POST', '/api/domains/:id/numbers/replace', ADMIN, ({ params, body }) => {
  const d = domainOf(params.id); if (!d) throw new HttpError(404, 'النطاق غير موجود');
  const ids = new Set((Array.isArray(body.ids) ? body.ids : []).map(Number).filter(Number.isFinite));
  if (!ids.size) throw bad('حدد الأرقام القديمة التي تريد استبدالها');
  const selected = store.numbers.filter((r) => ids.has(r.id));
  if (selected.length !== ids.size || selected.some((r) => r.d !== d.id)) throw bad('بعض الأرقام المحددة لا تتبع هذا النطاق؛ حدّث القائمة ثم أعد الاختيار');
  const { valid, invalid } = parseNumbers(body.text);
  if (!valid.length) throw bad('أدخل رقماً جديداً صالحاً واحداً على الأقل؛ لم يُحذف أي رقم');
  const outside = new Set(store.numbers.filter((r) => !ids.has(r.id)).map((r) => r.n));
  const additions = [], seen = new Set(); let duplicates = 0;
  for (const n of valid) { if (outside.has(n) || seen.has(n)) { duplicates++; continue; } seen.add(n); additions.push(n); }
  if (!additions.length) throw bad('كل الأرقام الجديدة موجودة مسبقاً خارج الاختيار؛ لم يُحذف أي رقم');
  const assignedRemoved = selected.filter((r) => r.u).length, now = Date.now();
  store.numData.items = store.numbers.filter((r) => !ids.has(r.id));
  for (const n of additions) store.numbers.push({ id: store.nextNumberId(), d: d.id, n, u: null, a: null, t: 0, c: now });
  store.reindex(); store.touch('numbers');
  return { replaced: selected.length, added: additions.length, duplicates, invalid, unassigned: assignedRemoved, total: valid.length };
});
route('POST', '/api/domains/:id/numbers/assign', MANAGER, ({ params, body }) => {
  const d = domainOf(params.id); if (!d) throw new HttpError(404, 'النطاق غير موجود');
  const u = userOf(Number(body.userId)); if (!u || isPrivilegedAccount(u)) throw bad('اختر مستخدماً');
  if (u.disabled) throw bad('لا يمكن توزيع أرقام إلى مستخدم معطّل');
  if (!d.apps.includes(body.app)) throw bad('هذا التطبيق غير مفعّل في النطاق');
  const count = clampInt(body.count, 1, 100000, 0); if (!count) throw bad('أدخل عدداً صحيحاً');
  const free = store.numbers.reduce((n, r) => n + (r.d === d.id && !r.u ? 1 : 0), 0);
  if (free < count) throw new HttpError(409, `المتوفر ${free} رقم فقط`);
  return { assigned: assignNumbers(d.id, u.id, body.app, count) };
});
route('POST', '/api/numbers/release', MANAGER, ({ body }) => {
  const ids = new Set((Array.isArray(body.ids) ? body.ids : []).map(Number)); let n = 0;
  for (const r of store.numbers) if (ids.has(r.id) && r.u) { r.u = null; r.a = null; r.t = 0; n++; }
  if (n) store.touch('numbers'); return { released: n };
});
route('POST', '/api/numbers/delete', ADMIN, ({ body }) => {
  const ids = new Set((Array.isArray(body.ids) ? body.ids : []).map(Number));
  const before = store.numbers.length;
  store.numData.items = store.numbers.filter((r) => !ids.has(r.id));
  store.reindex(); store.touch('numbers'); return { deleted: before - store.numbers.length };
});
route('GET', '/api/domains/:id/export', ADMIN, ({ params }) => {
  const d = domainOf(params.id); if (!d) throw new HttpError(404, 'النطاق غير موجود');
  const rows = ['number,status,user,app'].concat(store.numbers.filter((r) => r.d === d.id).map((r) => `${r.n},${r.u ? 'assigned' : 'free'},${r.u ? userOf(r.u)?.username || '' : ''},${r.a || ''}`));
  return { raw: rows.join('\n'), type: 'text/csv; charset=utf-8', headers: { 'Content-Disposition': `attachment; filename="${d.name}.csv"` } };
});

/* الطلبات */
route('GET', '/api/requests', AUTH, ({ user }) => {
  const list = core.requests.filter((r) => canManageUsersAndDomains(user) || r.userId === user.id).sort((a, b) => b.createdAt - a.createdAt).slice(0, 100);
  return { items: list.map((r) => ({ ...r, dn: domainOf(r.domainId)?.name || '—', un: userOf(r.userId)?.name || '—', uu: userOf(r.userId)?.username || '' })) };
});
route('POST', '/api/requests', AUTH, ({ user, body }) => {
  const d = domainOf(body.domainId); if (!d || !canSeeDomain(user, d)) throw bad('النطاق غير متاح');
  if (!d.apps.includes(body.app)) throw bad('التطبيق غير متاح في هذا النطاق');
  const count = clampInt(body.count, 1, 10000, 0); if (!count) throw bad('أدخل عدداً صحيحاً');
  if (core.requests.some((r) => r.userId === user.id && r.domainId === d.id && r.app === body.app && r.status === 'pending')) throw bad('لديك طلب معلّق لهذا التطبيق');
  core.requests.push({ id: ++core.seq.request, userId: user.id, domainId: d.id, app: body.app, count, note: str(body.note, 300), status: 'pending', createdAt: Date.now() });
  store.touch('core'); return { ok: true };
});
route('POST', '/api/requests/:id/decide', MANAGER, ({ params, body }) => {
  const r = core.requests.find((x) => x.id === Number(params.id) && x.status === 'pending'); if (!r) throw new HttpError(404, 'الطلب غير موجود');
  if (body.accept) {
    const count = clampInt(body.count, 1, 100000, r.count);
    const free = store.numbers.reduce((n, x) => n + (x.d === r.domainId && !x.u ? 1 : 0), 0);
    if (free < count) throw new HttpError(409, `المتوفر ${free} رقم فقط`);
    r.assigned = assignNumbers(r.domainId, r.userId, r.app, count); r.status = 'accepted';
  } else r.status = 'rejected';
  r.decidedAt = Date.now(); store.touch('core'); return { ok: true };
});

/* المستخدمون */
/* ---------------- الإعلانات (المدير يرسل، الجميع يقرأ) ---------------- */
route('GET', '/api/announcements', AUTH, () => ({ items: core.announcements.slice(-50).reverse() }));
route('POST', '/api/announcements', ADMIN, ({ user, body }) => {
  const title = str(body.title, 160); const text = String(body.body ?? '').trim().slice(0, 5000);
  if (!title || !text) throw bad('العنوان والنص مطلوبان');
  const item = { id: ++core.seq.announcement, title, body: text, by: user.name || user.username, t: Date.now() };
  core.announcements.push(item);
  if (core.announcements.length > 200) core.announcements.splice(0, core.announcements.length - 200);
  store.touch('core'); return { item };
});
route('DELETE', '/api/announcements/:id', ADMIN, ({ params }) => {
  const i = core.announcements.findIndex((a) => a.id === Number(params.id));
  if (i < 0) throw new HttpError(404, 'الإعلان غير موجود');
  core.announcements.splice(i, 1); store.touch('core'); return { ok: true };
});

route('GET', '/api/users', MANAGER, ({ query }) => {
  const nums = {}; for (const r of store.numbers) if (r.u) nums[r.u] = (nums[r.u] || 0) + 1;
  const codes = {}; for (const { m, r } of ownedMessages(null)) if (r && m.c) codes[r.u] = (codes[r.u] || 0) + 1;
  const email = str(query.get('email'), 254).toLowerCase();
  const users = core.users.filter((u) => !isPrivilegedAccount(u) && (!email || String(u.email || '').toLowerCase() === email));
  return { items: users.map((u) => ({ ...publicUser(u), disabled: !!u.disabled, createdAt: u.createdAt, phone: u.phone || '', numbers: nums[u.id] || 0, codes: codes[u.id] || 0 })) };
});
route('GET', '/api/users/:id/numbers', MANAGER, ({ params }) => {
  const u = userOf(Number(params.id)); if (!u || isPrivilegedAccount(u)) throw new HttpError(404, 'المستخدم غير موجود');
  const items = store.numbers.filter((r) => r.u === u.id).map((r) => ({ id: r.id, n: r.n, a: r.a, d: r.d, dn: domainOf(r.d)?.name || '', t: r.t }));
  items.sort((a, b) => b.t - a.t);
  return { user: { id: u.id, name: u.name, username: u.username, email: u.email || '' }, items };
});
const checkPassword = (p) => { if (p.length < 8 || !/\p{L}/u.test(p) || !/\p{Nd}/u.test(p)) throw bad('كلمة السر 8 أحرف على الأقل وتحتوي حروفاً وأرقاماً'); };
const reservedNames = () => new Set(['admin', store.adminUsername].filter(Boolean));
const phoneOf = (v) => { const raw = str(v, 24); if (!raw) return ''; const d = digitsOnly(raw); if (d.length < 8 || d.length > 15) throw bad('رقم الهاتف غير صحيح (8-15 رقماً)'); return d; };

// التسجيل العام مغلق: الحسابات تُنشأ من لوحة المدير فقط
route('GET', '/api/registration-status', OPEN, () => ({ open: false }));
route('POST', '/api/register', OPEN, () => { throw new HttpError(403, 'التسجيل مغلق. إنشاء الحسابات متاح من لوحة الإدارة فقط.'); });

route('POST', '/api/users', ADMIN, async ({ body }) => {
  if (CLERK_SECRET_KEY) throw new HttpError(403, 'إنشاء الحسابات يتم عبر تسجيل البريد والتحقق في Clerk.');
  const username = str(body.username, 24).toLowerCase().replace(/\s+/g, ''); const name = str(body.name, 60) || username;
  const password = String(body.password || ''); const confirm = body.confirm == null ? password : String(body.confirm);
  if (!/^[a-z0-9_.]{3,24}$/.test(username)) throw bad('اسم المستخدم: حروف إنجليزية وأرقام (3 على الأقل)');
  checkPassword(password);
  if (password !== confirm) throw bad('تأكيد كلمة السر غير مطابق');
  const phone = phoneOf(body.phone);
  if (reservedNames().has(username) || core.users.some((u) => u.username === username)) throw new HttpError(409, 'اسم المستخدم مستخدم');
  if (phone && core.users.some((u) => u.phone === phone)) throw new HttpError(409, 'رقم الهاتف مسجل بالفعل');
  const u = { id: ++core.seq.user, username, name, role: 'user', disabled: false, createdAt: Date.now(), ...(phone ? { phone } : {}), ...(await hashPassword(password)) };
  core.users.push(u); store.touch('core'); return { item: publicUser(u) };
});
route('PATCH', '/api/users/:id', MANAGER, async ({ params, body }) => {
  const u = userOf(Number(params.id)); if (!u || isPrivilegedAccount(u)) throw new HttpError(404, 'المستخدم غير موجود');
  if (body.name != null) u.name = str(body.name, 60) || u.name;
  if (body.password) {
    checkPassword(String(body.password));
    if (u.clerkId) {
      if (!clerkClient) throw new HttpError(503, 'إعداد Clerk غير مكتمل');
      try { await clerkClient.users.updateUser(u.clerkId, { password: String(body.password) }); }
      catch { throw bad('لم يتمكن Clerk من تحديث كلمة السر لهذا المستخدم'); }
      delete u.hash; delete u.salt; delete u.sha256;
    } else {
      Object.assign(u, await hashPassword(String(body.password)));
    }
    purgeSessions(store, u.id);
  }
  if (body.disabled != null) { u.disabled = !!body.disabled; if (u.disabled) purgeSessions(store, u.id); }
  store.touch('core'); return { ok: true };
});
route('DELETE', '/api/users/:id', MANAGER, async ({ params }) => {
  const u = userOf(Number(params.id)); if (!u || isPrivilegedAccount(u)) throw new HttpError(404, 'المستخدم غير موجود');
  if (u.clerkId) {
    if (!clerkClient) throw new HttpError(503, 'إعداد Clerk غير مكتمل');
    try { await clerkClient.users.deleteUser(u.clerkId); }
    catch { throw new HttpError(502, 'تعذر حذف حساب Clerk؛ لم تُحذف بيانات المستخدم من اللوحة'); }
  }
  for (const r of store.numbers) if (r.u === u.id) { r.u = null; r.a = null; r.t = 0; }
  store.touch('numbers'); purgeSessions(store, u.id);
  core.users = core.users.filter((x) => x.id !== u.id); core.requests = core.requests.filter((r) => r.userId !== u.id);
  for (const d of core.domains) if (Array.isArray(d.access)) d.access = d.access.filter((id) => id !== u.id);
  store.touch('core'); return { ok: true };
});

/* اللوحات والبوت */
route('GET', '/api/panels', ADMIN, () => ({ items: core.panels.map(panelDto), settings: core.settings, bot: botStatus() }));
function panelInput(body, p) {
  const url = str(body.url ?? p.url, 300).replace(/\/+$/, '');
  if (!/^https?:\/\/[^\s]+$/i.test(url)) throw bad('رابط اللوحة غير صالح (يبدأ بـ http أو https)');
  p.name = str(body.name ?? p.name, 60) || p.name; p.url = url;
  if (body.key) p.key = str(body.key, 400);
  p.path = str(body.path ?? p.path ?? '', 200); p.authHeader = str(body.authHeader ?? p.authHeader ?? 'Authorization', 60) || 'Authorization';
  p.authScheme = str(body.authScheme ?? p.authScheme ?? '', 20);
  if (body.enabled != null) p.enabled = !!body.enabled;
  if (body.type) p.type = body.type === 'primehub' ? 'primehub' : 'generic';
}
route('POST', '/api/panels', ADMIN, ({ body }) => {
  const p = { id: `p${++core.seq.panel}_${Date.now().toString(36)}`, name: '', url: '', key: '', path: '', authHeader: 'Authorization', authScheme: 'Bearer', enabled: true, type: 'generic' };
  if (!str(body.name)) throw bad('أدخل اسم اللوحة');
  panelInput(body, p); core.panels.push(p); store.touch('core'); return { item: panelDto(p) };
});
route('PUT', '/api/panels/:id', ADMIN, ({ params, body }) => {
  const p = core.panels.find((x) => x.id === params.id); if (!p) throw new HttpError(404, 'اللوحة غير موجودة');
  panelInput(body, p); store.touch('core'); return { item: panelDto(p) };
});
route('DELETE', '/api/panels/:id', ADMIN, ({ params }) => {
  core.panels = core.panels.filter((x) => x.id !== params.id);
  if (core.settings.activePanel === params.id) core.settings.activePanel = null;
  store.touch('core'); return { ok: true };
});
route('POST', '/api/panels/:id/test', ADMIN, async ({ params }) => {
  const p = core.panels.find((x) => x.id === params.id); if (!p) throw new HttpError(404, 'اللوحة غير موجودة');
  try { const r = await fetchMessages(p); return { ok: true, ms: r.ms, count: r.items.length }; } catch (e) { return { ok: false, error: String(e.message).slice(0, 200), ms: e.ms }; }
});
route('POST', '/api/panels/:id/detect', ADMIN, async ({ params }) => {
  const p = core.panels.find((x) => x.id === params.id); if (!p) throw new HttpError(404, 'اللوحة غير موجودة');
  const found = await detectEndpoint(p);
  if (!found) return { ok: false, error: 'لم يُعثر على مسار رسائل يقبل هذا المفتاح. أدخل المسار من توثيق اللوحة يدوياً.' };
  Object.assign(p, found); store.touch('core'); return { ok: true, found };
});
route('POST', '/api/settings', ADMIN, ({ body }) => {
  const s = core.settings;
  if (body.activePanel !== undefined) {
    if (body.activePanel !== 'all' && body.activePanel !== null && !core.panels.some((p) => p.id === body.activePanel)) throw bad('لوحة غير معروفة');
    s.activePanel = body.activePanel;
  }
  if (body.botOn != null) s.botOn = !!body.botOn;
  if (body.tgToken !== undefined) { const t = String(body.tgToken || '').trim().slice(0, 120); if (t && !/^\d{5,}:[\w-]{20,}$/.test(t)) throw new HttpError(400, 'توكن البوت غير صالح'); if (t !== (s.tgToken || '')) { s.tgToken = t; s.tgOffset = 0; tg.bot = ''; tg.ok = null; tg.error = ''; } }
  if (body.tgOn != null) s.tgOn = !!body.tgOn;
  if (body.pollSeconds != null) s.pollSeconds = clampInt(body.pollSeconds, 3, 120, 8);
  if (body.pricePerCode != null) s.pricePerCode = Math.max(0, Math.min(1000, Number(body.pricePerCode) || 0));
  store.touch('core');
  return { settings: s };
});
route('POST', '/api/bot/run', ADMIN, async () => { await runBot(true); return { bot: botStatus() }; });

/* ---------------- الخادم والملفات الثابتة ---------------- */
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.svg': 'image/svg+xml', '.woff2': 'font/woff2', '.png': 'image/png', '.ico': 'image/x-icon', '.webmanifest': 'application/manifest+json' };
function serveStatic(req, res, pathname) {
  let rel = decodeURIComponent(pathname); if (rel === '/') rel = '/index.html';
  const file = path.normalize(path.join(PUBLIC, rel));
  if (!file.startsWith(PUBLIC + path.sep)) return send(res, 403, 'Forbidden');
  fs.readFile(file, (err, fileData) => {
    if (err) return send(res, 404, 'Not found');
    // نشر المفتاح العام فقط من إعدادات البيئة دون تضمين السر في أي ملف واجهة.
    const data = rel === '/config.js'
      ? Buffer.from(`window.NFS_API = '';\nwindow.NFS_CLERK_PUBLISHABLE_KEY = ${JSON.stringify(CLERK_PUBLISHABLE_KEY)};\nwindow.NFS_SUPABASE_KEY = ${JSON.stringify(process.env.NFS_SUPABASE_KEY || 'sb_publishable_vYDZRPlJ8EW4r-xoClsVJQ_mjWPoxEZ')};\nwindow.NFS_SUPABASE_URL = ${JSON.stringify(process.env.NFS_SUPABASE_URL || 'https://ilhmquzuenmslamqzyuw.supabase.co')};\n`)
      : fileData;
    const ext = path.extname(file);
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': ext === '.woff2' ? 'public, max-age=31536000, immutable' : 'no-cache', 'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'same-origin' });
    res.end(data);
  });
}

// CORS: يسمح للواجهة المستضافة على نطاق آخر (استضافة ثابتة) بالاتصال. حدّد النطاقات في config.json: "corsOrigins": ["https://site.example"]
const CORS = String(process.env.CORS_ORIGIN || '').split(',').map((s) => s.trim()).filter(Boolean).concat(config.corsOrigins || []);
function applyCors(req, res) {
  const o = req.headers.origin; if (!o) return;
  if (CORS.length && !CORS.includes(o) && !CORS.includes('*')) return;
  res.setHeader('Access-Control-Allow-Origin', CORS.length && !CORS.includes('*') ? o : '*');
  res.setHeader('Vary', 'Origin');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.setHeader('Access-Control-Expose-Headers', 'X-Rev');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
  res.setHeader('Access-Control-Max-Age', '86400');
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  applyCors(req, res);
  if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
  if (!url.pathname.startsWith('/api/')) return serveStatic(req, res, url.pathname);
  try {
    const r = routes.find((x) => x.method === req.method && x.re.test(url.pathname));
    if (!r) throw new HttpError(404, 'غير موجود');
    const bearer = /^Bearer\s+(\S+)$/i.exec(req.headers.authorization || '');
    const token = (bearer && bearer[1]) || parseCookies(req.headers.cookie).nfs_sid;
    const user = getSessionUser(store, token);
    if (r.opts.auth && !user) throw new HttpError(401, 'سجّل الدخول أولاً');
    if (r.opts.admin && !isFullAdmin(user)) throw new HttpError(403, 'للمدير الكامل فقط');
    if (r.opts.manager && !canManageUsersAndDomains(user)) throw new HttpError(403, 'لا تملك صلاحية إدارة المستخدمين والنطاقات');
    const body = ['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method) ? await readBody(req) : {};
    const ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').toString().split(',')[0].trim();
    const secure = req.headers['x-forwarded-proto'] === 'https';
    const out = await r.handler({ req, res, user, token, body, query: url.searchParams, params: url.pathname.match(r.re).groups || {}, ip, secure });
    if (out && out.raw !== undefined) return send(res, 200, Buffer.from(out.raw), { 'Content-Type': out.type, ...out.headers });
    if (out && out.body) return send(res, 200, out.body, out.headers);
    send(res, 200, out ?? { ok: true });
  } catch (e) {
    if (!(e instanceof HttpError)) console.error(e);
    send(res, e.status || 500, { error: e.status ? e.message : 'خطأ في الخادم' });
  }
});

server.listen(PORT, () => {
  console.log(`\nNFSsms يعمل على: http://localhost:${PORT}`);
  if (store.adminSeeded) console.log(`  حساب المدير من البيئة: ${store.adminUsername}  (كلمة السر من ADMIN_PASSWORD)`);
  if (store.limitedAdminSeeded) console.log('  حساب المشرف المحدود: 1Whisper  (كلمة السر الافتراضية: 1Whisper؛ يمكن ضبط LIMITED_ADMIN_PASSWORD)');
  if (store.adminCreated) {
    console.log(store.adminCreated.envPass
      ? '  حساب المدير: admin  (كلمة السر من متغير ADMIN_PASSWORD)'
      : '  حساب المدير: admin  (كلمة السر هي كلمة سر المدير القديمة التي سُلّمت لك)');
  }
  const ap = core.settings.activePanel;
  console.log(`  اللوحة العاملة: ${ap === 'all' ? 'كل اللوحات' : core.panels.find((p) => p.id === ap)?.name || 'غير محددة'}\n`);
  runBot().catch(() => {}); scheduleBot();
});

