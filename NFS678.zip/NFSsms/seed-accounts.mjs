// إنشاء حسابات جاهزة (مستخدمون + مديرون) بكلمات سر عشوائية وإضافتها إلى data/core.json
// الاستخدام: node seed-accounts.mjs [عدد_المستخدمين=500] [عدد_المديرين=10]
// يتخطى أي اسم مستخدم موجود مسبقاً، ويكتب كلمات السر الجديدة في accounts.txt (احفظه ثم احذفه من الخادم).
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { hashPassword } from './lib/auth.js';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const nUsers = Number(process.argv[2] ?? 500), nAdmins = Number(process.argv[3] ?? 10);
const dir = process.env.DATA_DIR || path.join(ROOT, 'data');
const file = path.join(dir, 'core.json');
const cfg = JSON.parse(fs.readFileSync(path.join(ROOT, 'config.json'), 'utf8'));
fs.mkdirSync(dir, { recursive: true });

const core = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : {
  users: [], domains: [], requests: [], sessions: {}, panels: null,
  settings: { activePanel: cfg.activePanel || null, botOn: true, pollSeconds: 8, pricePerCode: 0 },
  seq: { user: 0, domain: 0, request: 0, panel: 0 },
};
core.seq ||= { user: 0, domain: 0, request: 0, panel: 0 };

const ALPH = 'ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789'; // بدون حروف متشابهة
const pass = (n) => Array.from({ length: n }, () => ALPH[crypto.randomInt(ALPH.length)]).join('');
const out = [];

async function make(prefix, count, width, role, label, passLen) {
  let made = 0;
  for (let i = 1; i <= count; i++) {
    const username = prefix + String(i).padStart(width, '0');
    if (core.users.some((u) => u.username === username)) continue;
    const password = pass(passLen);
    core.users.push({ id: ++core.seq.user, username, name: `${label} ${String(i).padStart(width, '0')}`, role, disabled: false, createdAt: Date.now(), ...(await hashPassword(password)) });
    out.push(`${username}  ${password}  ${role}`);
    made++;
  }
  return made;
}
const a = await make('admin', nAdmins, 2, 'admin', 'مدير', 12);
const u = await make('user', nUsers, 3, 'user', 'مستخدم', 10);
const tmp = `${file}.tmp`;
fs.writeFileSync(tmp, JSON.stringify(core)); fs.renameSync(tmp, file);
fs.writeFileSync('accounts.txt', ['# username  password  role', ...out, ''].join('\n'));
console.log(`تم: ${a} مدير و ${u} مستخدم. كلمات السر في accounts.txt`);
