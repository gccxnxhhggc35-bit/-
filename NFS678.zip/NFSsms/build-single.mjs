// يبني ملفاً واحداً index.html (وضع بدون خادم) يعمل بالنقر المزدوج عليه، بدون أي ملفات أخرى.
// يحتاج esbuild مرة واحدة فقط:  npm i --no-save esbuild   ثم:  node build-single.mjs
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const P = (f) => path.join(ROOT, 'public', f);
// يستخدم esbuild إن وُجد، وإلا يعمل مُجمِّع بسيط مدمج (بدون أي تثبيت).
async function bundleJs() {
  try {
    const { build } = await import('esbuild');
    return (await build({ entryPoints: [P('app.js')], bundle: true, minify: true, format: 'iife', write: false, target: 'es2020', legalComments: 'none' })).outputFiles[0].text;
  } catch (e) { if (e.code !== 'ERR_MODULE_NOT_FOUND') throw e; }
  const order = [], seen = new Set(), src = {};
  const visit = (f) => {
    if (seen.has(f)) return; seen.add(f);
    src[f] = fs.readFileSync(P(f), 'utf8');
    for (const m of src[f].matchAll(/^import\s+(?:[^'"]*?from\s+)?'\.\/([\w.-]+)';/gm)) visit(m[1]);
    order.push(f);
  };
  visit('app.js');
  let out = '(()=>{\n';
  for (const f of order) {
    if (f === 'pwa.js') continue; // التثبيت PWA لا يعمل داخل ملف واحد
    const id = '__' + f.replace(/\W/g, '_'), names = [], liveRe = [];
    let code = src[f]
      .replace(/^import\s+'\.\/pwa\.js';\s*$/m, '')
      .replace(/^import\s*\{([^}]*)\}\s*from\s*'\.\/([\w.-]+)';/gm, (_, list, mod) => {
        const mid = '__' + mod.replace(/\W/g, '_'), keep = [];
        for (const it of list.split(',').map((x) => x.trim()).filter(Boolean)) {
          const [a, b] = it.split(/\s+as\s+/); const local = b || a;
          if (a === 'LOCAL') liveRe.push([local, mid + '.LOCAL']); else keep.push(b ? `${a}: ${b}` : a);
        }
        return keep.length ? `const { ${keep.join(', ')} } = ${mid};` : '';
      })
      .replace(/^export\s+\{([^}]*)\};?\s*$/gm, (_, list) => { list.split(',').forEach((x) => names.push(x.trim())); return ''; })
      .replace(/^export\s+((?:async\s+)?function\s*\*?\s*|const\s+|let\s+)([\w$]+)/gm, (_, kw, n) => { names.push(n); return kw + n; });
    for (const [local, repl] of liveRe) code = code.replace(new RegExp('(?<![\\w$.])' + local + '(?![\\w$])', 'g'), repl);
    out += `const ${id} = (() => {\n${code}\nreturn { ${names.map((n) => `get ${n}() { return ${n}; }`).join(', ')} };\n})();\n`;
  }
  return out + '})();';
}
const js = await bundleJs();
let css = fs.readFileSync(P('app.css'), 'utf8');
css = css.replace(/url\((['"]?)(?:\.\/)?fonts\/([^'")]+)\1\)/g, (_, _q, f) => `url(data:font/woff2;base64,${fs.readFileSync(P('fonts/' + f)).toString('base64')})`);
const icon = 'data:image/png;base64,' + fs.readFileSync(P('icons/icon-192.png')).toString('base64');
let html = fs.readFileSync(P('index.html'), 'utf8');
html = html
  .replace(/<link rel="(?:icon|apple-touch-icon|manifest)"[^>]*>\s*/g, '')
  .replace('<title>', () => `<link rel="icon" href="${icon}" type="image/png">\n<title>`)
  .replace(/<meta name="(?:mobile-web-app-capable|apple-mobile-web-app-capable|apple-mobile-web-app-title|apple-mobile-web-app-status-bar-style)"[^>]*>\s*/g, '')
  .replace('src="icons/icon-192.png"', () => `src="${icon}"`)
  .replace(/<link rel="preload"[^>]*>\s*/g, '')
  .replace(/<link rel="stylesheet" href="app.css">/, () => `<style>${css}</style>`)
  .replace(/<script src="config.js"><\/script>\s*<script type="module" src="app.js"><\/script>/, () => `<meta name="nfs-single" id="nfs-single" content="1">\n<script id="nfs-snapshot" type="application/json">null</script>\n<script>window.NFS_API = 'local';window.NFS_SUPABASE_KEY = ${JSON.stringify(process.env.NFS_SUPABASE_KEY || 'sb_publishable_vYDZRPlJ8EW4r-xoClsVJQ_mjWPoxEZ')};window.NFS_SUPABASE_URL = ${JSON.stringify(process.env.NFS_SUPABASE_URL || 'https://ilhmquzuenmslamqzyuw.supabase.co')};window.NFS_SYNC = ${JSON.stringify(process.env.NFS_SYNC || '')};</script>\n<script>${js.replace(/<\/script/gi, '<\\/script')}</script>`);
if (html.includes('src="app.js"') || html.includes('href="app.css"')) throw new Error('تعذر تضمين الملفات');
const out = path.join(ROOT, 'index.html');
fs.writeFileSync(out, html);
console.log('تم إنشاء', out, (html.length / 1024).toFixed(0) + ' KB');
