# وسيط NFSsms

المتصفح لا يستطيع جلب الرسائل من اللوحات مباشرة (CORS، وحظر HTTP من صفحة HTTPS). هذا الوسيط الصغير يجلبها نيابةً عنه.

## على Vercel (مجاني)
1. ارفع مجلد `relay` كمشروع جديد على Vercel.
2. في Settings ← Environment Variables أضف `RELAY_TOKEN` = كلمة سر طويلة من اختيارك (واختيارياً `ALLOWED_HOSTS` = `169.58.91.190,thirdwave.im,145.239.69.111`).
3. أعد النشر. رابط الوسيط: `https://اسم-مشروعك.vercel.app/api/relay`
4. في NFSsms: "حسابي" ← "وسيط الاتصال" ← الصق الرابط والمفتاح ← حفظ، ثم "فحص" في صفحة اللوحات.

## على أي جهاز Node
`RELAY_TOKEN=كلمة_سر node server.mjs` ثم استخدم رابطه (يلزم HTTPS إن كانت الصفحة على HTTPS).

ملاحظة: Cloudflare Workers لا تصلح لأن لوحة Prime Hub عنوانها IP مباشر.
