// تشغيل الوسيط على أي جهاز/استضافة تدعم Node 18+:   RELAY_TOKEN=كلمة_سر node server.mjs   (المنفذ 8787 أو PORT)
import http from 'node:http';
import handler from './api/relay.js';
http.createServer((req, res) => {
  const chunks = [];
  req.on('data', (c) => chunks.push(c));
  req.on('end', () => {
    try { req.body = JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}'); } catch { req.body = {}; }
    res.status = (c) => { res.statusCode = c; return res; };
    res.json = (o) => { res.setHeader('Content-Type', 'application/json; charset=utf-8'); res.end(JSON.stringify(o)); };
    handler(req, res).catch(() => { res.statusCode = 500; res.end('{}'); });
  });
}).listen(process.env.PORT || 8787, () => console.log('relay on', process.env.PORT || 8787));
