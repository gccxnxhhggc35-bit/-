// وسيط NFSsms: يجلب رسائل اللوحات نيابةً عن المتصفح (لتجاوز CORS وحظر HTTP من صفحة HTTPS).
// ارفعه على Vercel (مجلد relay كمشروع)، أو شغّله بـ node server.mjs. ضع متغير البيئة RELAY_TOKEN (كلمة سر طويلة)
// واختيارياً ALLOWED_HOSTS (مثال: 169.58.91.190,thirdwave.im,145.239.69.111) لتقييد اللوحات المسموحة.
const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'POST, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type' };

export default async function handler(req, res) {
  for (const [k, v] of Object.entries(cors)) res.setHeader(k, v);
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'POST only' });
  let body = req.body;
  if (typeof body === 'string') { try { body = JSON.parse(body); } catch { body = {}; } }
  body ||= {};
  const need = process.env.RELAY_TOKEN;
  if (!need) return res.status(500).json({ error: 'RELAY_TOKEN غير مضبوط على الوسيط' });
  if (body.token !== need) return res.status(401).json({ error: 'مفتاح الوسيط غير صحيح' });
  let u;
  try { u = new URL(String(body.url)); } catch { return res.status(400).json({ error: 'رابط غير صالح' }); }
  if (!/^https?:$/.test(u.protocol)) return res.status(400).json({ error: 'رابط غير صالح' });
  const allowed = String(process.env.ALLOWED_HOSTS || '').split(',').map((x) => x.trim()).filter(Boolean);
  if (allowed.length && !allowed.includes(u.hostname)) return res.status(403).json({ error: 'اللوحة غير مسموحة في الوسيط' });
  const headers = { Accept: 'application/json' };
  for (const [k, v] of Object.entries(body.headers || {})) if (/^[\w-]{1,60}$/.test(k) && !/^(host|content-length|connection)$/i.test(k)) headers[k] = String(v).slice(0, 600);
  try {
    const r = await fetch(u, { headers, redirect: 'manual', signal: AbortSignal.timeout(12000) });
    const text = (await r.text()).slice(0, 5 * 1024 * 1024);
    return res.status(200).json({ status: r.status, body: text });
  } catch (e) {
    return res.status(200).json({ status: 0, error: String(e && e.message || e).slice(0, 160) });
  }
}
