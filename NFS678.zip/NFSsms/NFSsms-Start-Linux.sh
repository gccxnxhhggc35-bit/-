#!/bin/bash
# Start the Node/Clerk version so account creation and email verification work.
DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR" || exit 1
if ! command -v node >/dev/null 2>&1 || ! command -v npm >/dev/null 2>&1; then
  echo "Node.js 20.9 or newer is required. Install it, then run this file again."
  exit 1
fi
node -e 'const [m,n]=process.versions.node.split(".").map(Number);process.exit(m>20||(m===20&&n>=9)?0:1)' || { echo "Please upgrade to Node.js 20.9 or newer."; exit 1; }
if [ ! -d node_modules/@clerk/backend ]; then
  echo "Installing NFSsms dependencies for first launch..."
  npm install || { echo "Dependency installation failed."; exit 1; }
fi
(
  for _ in $(seq 1 45); do
    if curl -fsS -o /dev/null http://localhost:3000/; then
      if command -v xdg-open >/dev/null 2>&1; then xdg-open http://localhost:3000 >/dev/null 2>&1; fi
      exit 0
    fi
    sleep 1
  done
  if command -v xdg-open >/dev/null 2>&1; then xdg-open http://localhost:3000 >/dev/null 2>&1; fi
) &
npm start
