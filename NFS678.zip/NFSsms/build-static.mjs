// يجهّز مجلد الواجهة لرفعه على استضافة ثابتة.
//   node build-static.mjs                         ← وضع بدون خادم (الدخول والبيانات داخل المتصفح)
//   node build-static.mjs https://رابط-الخادم      ← الواجهة فقط، والخادم (node server.js) يعمل في مكان آخر
//   NFS_SYNC=https://اسمك-default-rtdb.firebaseio.com node build-static.mjs   ← بدون خادم مع المزامنة الدائمة
// الناتج: مجلد static-site (ارفع محتواه على الاستضافة).
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
// قراءة قيم .env ما لم تكن متوفرة مسبقاً في البيئة.
const envPath = path.join(ROOT, '.env');
if (fs.existsSync(envPath)) {
  for (const line of fs.readFileSync(envPath, 'utf8').split(/\r?\n/)) {
    const m = /^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/.exec(line);
    if (m && process.env[m[1]] == null) process.env[m[1]] = m[2].replace(/^['"]|['"]$/g, '');
  }
}
const publishableKey = process.env.NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY || process.env.CLERK_PUBLISHABLE_KEY || 'pk_test_ZmlybS1oaXBwby00MTExLmNsZXJrLmFjY291bnRzLmRldiQ';
const api = (process.argv[2] || 'local').replace(/\/+$/, '');
if (api !== 'local' && !/^https?:\/\//.test(api)) { console.error('اكتب الرابط كاملاً، مثال: node build-static.mjs https://api.example.com'); process.exit(1); }
const out = path.join(ROOT, 'static-site');
fs.rmSync(out, { recursive: true, force: true });
fs.cpSync(path.join(ROOT, 'public'), out, { recursive: true });
fs.writeFileSync(path.join(out, 'config.js'), `window.NFS_API = ${JSON.stringify(api)};\nwindow.NFS_CLERK_PUBLISHABLE_KEY = ${JSON.stringify(publishableKey)};\nwindow.NFS_SUPABASE_KEY = ${JSON.stringify(process.env.NFS_SUPABASE_KEY || 'sb_publishable_vYDZRPlJ8EW4r-xoClsVJQ_mjWPoxEZ')};\nwindow.NFS_SUPABASE_URL = ${JSON.stringify(process.env.NFS_SUPABASE_URL || 'https://ilhmquzuenmslamqzyuw.supabase.co')};\nwindow.NFS_SYNC = ${JSON.stringify(process.env.NFS_SYNC || '')};\n`);
console.log(api === 'local' ? 'تم إنشاء static-site (وضع بدون خادم)' : `تم إنشاء static-site (رابط الخادم: ${api})`);
