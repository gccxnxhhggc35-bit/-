// تغيير كلمة سر المدير: node reset-admin.js "كلمة_السر_الجديدة"  (أوقف الخادم أولاً)
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const pass = process.argv[2];
if (!pass || pass.length < 6) { console.error('اكتب كلمة سر من 6 أحرف على الأقل: node reset-admin.js NEWPASS'); process.exit(1); }
const dir = process.env.DATA_DIR || path.join(path.dirname(fileURLToPath(import.meta.url)), 'data');
const file = path.join(dir, 'core.json');
if (!fs.existsSync(file)) { console.error('شغّل الخادم مرة واحدة أولاً لإنشاء البيانات.'); process.exit(1); }
const core = JSON.parse(fs.readFileSync(file, 'utf8'));
const admin = core.users.find((u) => u.role === 'admin');
const salt = crypto.randomBytes(16).toString('hex');
admin.salt = salt; admin.hash = crypto.scryptSync(pass, salt, 32).toString('hex'); delete admin.sha256;
for (const [k, s] of Object.entries(core.sessions || {})) if (s.userId === admin.id) delete core.sessions[k];
fs.writeFileSync(file, JSON.stringify(core));
console.log('تم تغيير كلمة سر المدير (اسم المستخدم: admin).');
