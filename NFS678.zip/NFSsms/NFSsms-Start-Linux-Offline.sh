#!/bin/bash
# NFSsms - تشغيل بدون خادم على لينكس: يفتح نافذة Chrome/Chromium خاصة تتصل باللوحات مباشرة
DIR="$(cd "$(dirname "$0")" && pwd)"
FILE="$DIR/index.html"
[ -f "$FILE" ] || { echo "index.html not found next to this file"; exit 1; }
URL="file://$(printf '%s' "$FILE" | sed 's/ /%20/g')"
PROFILE="${XDG_CONFIG_HOME:-$HOME/.config}/NFSsms-Browser"
for B in google-chrome google-chrome-stable chromium chromium-browser microsoft-edge brave-browser; do
  if command -v "$B" >/dev/null 2>&1; then
    nohup "$B" --user-data-dir="$PROFILE" --disable-web-security --allow-running-insecure-content --disable-background-timer-throttling --disable-renderer-backgrounding --disable-backgrounding-occluded-windows --no-first-run --no-default-browser-check --app="$URL" >/dev/null 2>&1 &
    exit 0
  fi
done
echo "Google Chrome / Chromium not found. Install it and try again."
