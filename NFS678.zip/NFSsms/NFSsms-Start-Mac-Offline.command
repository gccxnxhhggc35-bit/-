#!/bin/bash
# NFSsms - تشغيل بدون خادم على ماك: يفتح نافذة Chrome/Edge خاصة تتصل باللوحات مباشرة
DIR="$(cd "$(dirname "$0")" && pwd)"
FILE="$DIR/index.html"
[ -f "$FILE" ] || { echo "index.html not found next to this file"; read -r; exit 1; }
URL="file://$(printf '%s' "$FILE" | sed 's/ /%20/g')"
PROFILE="$HOME/Library/Application Support/NFSsms-Browser"
FLAGS=(--user-data-dir="$PROFILE" --disable-web-security --allow-running-insecure-content --disable-background-timer-throttling --disable-renderer-backgrounding --disable-backgrounding-occluded-windows --no-first-run --no-default-browser-check --app="$URL")
for APP in "Google Chrome" "Microsoft Edge" "Brave Browser" "Chromium"; do
  if [ -d "/Applications/$APP.app" ] || [ -d "$HOME/Applications/$APP.app" ]; then
    open -na "$APP" --args "${FLAGS[@]}"
    exit 0
  fi
done
echo "Google Chrome / Microsoft Edge not found. Install Google Chrome and try again."
read -r
